export interface OnboardingStepConfig {
  id: string;
  title: string;
  description: string;
  required: boolean;
}

export const ONBOARDING_STEPS: OnboardingStepConfig[] = [
  { id: 'about-you', title: 'About You', description: 'Baseline identity mapping', required: true },
  { id: 'companies', title: 'Your Companies', description: 'Organizational context', required: true },
  { id: 'integrations', title: 'Connect Tools', description: 'OAuth synchronization', required: true },
  { id: 'preferences', title: 'Preferences', description: 'Operational philosophy', required: true },
  { id: 'family', title: 'Your Family', description: 'VIP interrupt protocol', required: false },
  { id: 'autonomy', title: 'AI Autonomy', description: 'Agency & thresholds', required: true },
  { id: 'voice-setup', title: 'Voice Setup', description: 'Biometric vocal profile', required: false },
  { id: 'complete', title: 'Initialize', description: 'Final synchronization', required: true },
];

export const getStepIndex = (id: string) => ONBOARDING_STEPS.findIndex(s => s.id === id);