
export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  quote: string;
  avatar: string;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    role: 'Managing Director',
    company: 'Zenith Ventures',
    quote: 'Atlas has effectively added 15 hours back to my week. It handles the "noise" so I can focus on deals.',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah'
  },
  {
    id: '2',
    name: 'Martijn van Bree',
    role: 'Founder & CEO',
    company: 'Nexus Global',
    quote: 'The vocal sync is uncanny. My team can\'t tell when they\'re talking to Atlas or me for routine logistics.',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Martijn'
  },
  {
    id: '3',
    name: 'Elena Rodriguez',
    role: 'COO',
    company: 'HyperScale Logisics',
    quote: 'Managing three global companies was killing me. Atlas unified my context and saved my sanity.',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Elena'
  }
];
