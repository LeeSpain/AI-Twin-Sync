
import { Mail, Calendar, Mic, Building, Heart, Shield, Github, Zap, Clock } from 'lucide-react';
import React from 'react';

export interface MarketingFeature {
  id: string;
  title: string;
  description: string;
  icon: any;
  details: string[];
}

export const MARKETING_FEATURES: MarketingFeature[] = [
  {
    id: 'email',
    title: 'Email Management',
    description: 'Atlas reads, drafts, and sends emails in your authentic voice.',
    icon: Mail,
    details: ['Natural voice adaptation', 'Priority sorting', 'Automated follow-ups']
  },
  {
    id: 'calendar',
    title: 'Calendar Control',
    description: 'Smart scheduling that protects your deep-work focus time.',
    icon: Calendar,
    details: ['Buffer optimization', 'Conflict resolution', 'Time-zone bridging']
  },
  {
    id: 'code',
    title: 'GitHub Neural Sync',
    description: 'Atlas monitors repositories, reviews PRs, and summarizes commits.',
    icon: Github,
    details: ['Automated PR triage', 'Commit synthesis', 'Codebase context mapping']
  },
  {
    id: 'calls',
    title: 'Vocal Presence',
    description: 'Atlas can screen calls, take messages, or patch through VIPs.',
    icon: Mic,
    details: ['Biometric vocal sync', 'Real-time triage', 'Executive gatekeeping']
  },
  {
    id: 'family',
    title: 'Family VIP Link',
    description: 'The inner circle always gets through, no matter the status.',
    icon: Heart,
    details: ['Interrupt protocol', 'Family-only bypass', 'VIP emergency link']
  },
  {
    id: 'security',
    title: 'Neural Privacy',
    description: 'Your data is encrypted and hosted on your private instance.',
    icon: Shield,
    details: ['End-to-end encryption', 'Privacy by design', 'Audit logging']
  }
];
