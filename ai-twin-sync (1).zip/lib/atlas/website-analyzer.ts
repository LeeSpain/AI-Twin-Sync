import { GoogleGenAI, Type } from "@google/genai";

export async function analyzeCompanyWebsite(url: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // In a real scenario, we would first fetch/scrape the URL content.
  // For this implementation, we ask Gemini to use its internal knowledge or simulated crawl results.
  const prompt = `Perform a high-fidelity business analysis on the following website: ${url}. 
  Extract the core organization identity including its name, industry, and a mission-focused description.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            industry: { type: Type.STRING },
            description: { type: Type.STRING },
            notes: { type: Type.STRING }
          },
          required: ["name", "industry", "description"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
}