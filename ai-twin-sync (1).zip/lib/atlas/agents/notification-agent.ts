
import { BaseAgent } from "./base-agent";
import { AgentResponse } from "@/types/agents";

export class NotificationAgent extends BaseAgent {
  async execute() {
    return { text: "Protocol: Quiet Hours Active. No non-VIP alerts will be synchronized." };
  }
}
