
import { BaseAgent } from "./base-agent";
import { AgentResponse, IntentType } from "@/types/agents";
import { Type } from "@google/genai";

export class EmailAgent extends BaseAgent {
  async execute(message: string, intent: any): Promise<AgentResponse> {
    if (intent.type === IntentType.EMAIL_DRAFT) {
      return await this.draftEmail(message, intent.entities);
    }
    
    // Default fallback
    return { text: "I've accessed your neural inbox. I can see 12 unread items from today. Should I summarize the high-priority ones?" };
  }

  private async draftEmail(instruction: string, entities: any): Promise<AgentResponse> {
    const response = await this.ai.models.generateContent({
      model: this.getModel(),
      contents: instruction,
      config: {
        systemInstruction: `You are Atlas. Draft an email based on the user's instructions. Use their professional voice. 
        Context: ${this.context.preferences}.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            to: { type: Type.STRING },
            subject: { type: Type.STRING },
            body: { type: Type.STRING },
            reasoning: { type: Type.STRING }
          }
        }
      }
    });

    const draft = JSON.parse(response.text);
    return {
      text: `I've drafted a response to ${draft.to || 'your contact'}. Review the contents in your action panel.`,
      actions: [{
        type: 'email_draft',
        description: `Drafting: ${draft.subject}`,
        data: draft,
        confidence: 0.92,
        requiresApproval: true
      }]
    };
  }
}
