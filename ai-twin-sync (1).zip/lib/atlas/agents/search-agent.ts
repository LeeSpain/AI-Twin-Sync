
import { BaseAgent } from "./base-agent";
import { AgentResponse } from "@/types/agents";

export class SearchAgent extends BaseAgent {
  async execute(query: string) {
    return { 
      text: "I've indexed your historical communications. I found 3 references to that topic in last month's strategy emails.",
      metadata: { sources: ['email_sync_q4', 'notion_briefing_oct'] }
    };
  }
}
