
import { GoogleGenAI, Type } from "@google/genai";
import { AgentType, IntentType, AgentContext, AgentResponse } from "@/types/agents";
import { EmailAgent } from "./agents/email-agent";
import { CalendarAgent } from "./agents/calendar-agent";
import { TaskAgent } from "./agents/task-agent";

export class Commander {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async processMessage(userId: string, message: string, context: AgentContext): Promise<AgentResponse> {
    const intent = await this.analyzeIntent(message);
    console.log(`[Commander] Detected intent: ${intent.type} (Confidence: ${intent.confidence})`);

    const agent = this.routeToAgent(intent.type, userId, context);
    if (!agent) {
      return { text: "I'm not sure which protocol to engage for that request. Could you clarify your objective?" };
    }

    return await agent.execute(message, intent);
  }

  private async analyzeIntent(message: string) {
    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze user message for Atlas (Chief of Staff): "${message}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            type: { 
              type: Type.STRING, 
              enum: Object.values(IntentType),
              description: "The primary intent category" 
            },
            confidence: { type: Type.NUMBER, description: "Confidence score 0-1" },
            entities: { 
              type: Type.OBJECT,
              properties: {
                dates: { type: Type.ARRAY, items: { type: Type.STRING } },
                names: { type: Type.ARRAY, items: { type: Type.STRING } },
                topics: { type: Type.ARRAY, items: { type: Type.STRING } }
              }
            }
          },
          required: ["type", "confidence"]
        }
      }
    });

    return JSON.parse(response.text);
  }

  private routeToAgent(intentType: IntentType, userId: string, context: AgentContext) {
    switch (intentType) {
      case IntentType.EMAIL_READ:
      case IntentType.EMAIL_DRAFT:
      case IntentType.EMAIL_SEND:
        return new EmailAgent(userId, context);
      case IntentType.CALENDAR_VIEW:
      case IntentType.CALENDAR_BOOK:
        return new CalendarAgent(userId, context);
      case IntentType.TASK_CREATE:
      case IntentType.TASK_LIST:
        return new TaskAgent(userId, context);
      default:
        return null;
    }
  }
}
