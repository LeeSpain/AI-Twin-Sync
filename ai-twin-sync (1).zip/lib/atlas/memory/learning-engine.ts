
import { GoogleGenAI } from "@google/genai";
import { MemoryManager } from "./memory-manager";
import { MemoryType } from "@/types/memory";

export class LearningEngine {
  static async extractLearnablePatterns(userId: string, interaction: string) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `What did we learn about the user from this? "${interaction}"`,
      config: {
        systemInstruction: "Extract single facts or preferences. Be concise."
      }
    });

    const fact = response.text;
    if (fact && fact.length > 5) {
      await MemoryManager.storeMemory(userId, fact, MemoryType.PATTERN, 3);
    }
  }
}
