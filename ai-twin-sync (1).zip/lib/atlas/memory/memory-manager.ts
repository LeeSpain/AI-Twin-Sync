
import { createClient } from "@/lib/supabase/server";
import { Memory, MemoryType } from "@/types/memory";

export class MemoryManager {
  static async storeMemory(userId: string, fragment: string, type: MemoryType, importance: number = 5) {
    const supabase = createClient();
    const { data, error } = await supabase
      .from('atlas_memories')
      .insert({
        user_id: userId,
        fragment,
        type,
        importance,
        last_recalled_at: new Date().toISOString()
      });
    
    if (error) throw error;
    return data;
  }

  static async getRelevantMemories(userId: string, query: string): Promise<Memory[]> {
    // In a real app, this would use pgvector for semantic search
    const supabase = createClient();
    const { data, error } = await supabase
      .from('atlas_memories')
      .select('*')
      .eq('user_id', userId)
      .order('importance', { ascending: false })
      .limit(5);
    
    return (data || []) as unknown as Memory[];
  }
}
