
import { AgentContext } from "@/types/agents";
import { MemoryManager } from "./memory-manager";

export class ContextBuilder {
  static async buildFullContext(userId: string, message: string, history: any[]): Promise<AgentContext> {
    const memories = await MemoryManager.getRelevantMemories(userId, message);
    const memoryString = memories.map(m => `- ${m.fragment}`).join('\n');

    return {
      userId,
      userName: "Executive", // Fetch from DB
      preferences: `Memory Context:\n${memoryString}\n\nStandard executive throughput focus.`,
      dateTime: new Date().toLocaleString(),
      history
    };
  }
}
