
export class CalendarUtils {
  static checkConflict(event: any, existing: any[]) {
    return existing.some(e => 
      (event.start >= e.start && event.start < e.end) ||
      (event.end > e.start && event.end <= e.end)
    );
  }

  static formatDuration(minutes: number) {
    return `${minutes}m`;
  }
}
