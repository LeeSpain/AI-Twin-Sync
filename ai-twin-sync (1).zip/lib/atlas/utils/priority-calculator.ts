
export class PriorityCalculator {
  static calculate(item: any, context: any) {
    let score = 0;
    if (item.dueDate) score += 40;
    if (item.isVIP) score += 30;
    if (item.isFinancial) score += 20;
    return Math.min(score, 100);
  }
}
