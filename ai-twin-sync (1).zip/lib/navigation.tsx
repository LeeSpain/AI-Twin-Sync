
import React from 'react';
import { useNavigationStore } from '@/stores/navigation-store';

/**
 * AI Twin Sync - Navigation Protocol v12.0 (Relay Handshake)
 * 
 * Escapes sandboxed iframes by initiating a Sovereign Relay.
 * This ensures external redirects for GitHub Auth/Commits never 
 * trigger "Refused to connect".
 */

const SECURE_DOMAINS = [
  'github.com',
  'api.github.com',
  'google.com',
  'accounts.google.com',
  'supabase.com',
  'vercel.com',
  'netlify.com',
  'heroku.com',
  'auth.expo.io',
  'microsoft.com',
  'slack.com'
];

export const isExternalLink = (href: string) => {
  if (!href) return false;
  const lowerHref = href.toLowerCase();
  return lowerHref.startsWith('http') || 
         lowerHref.startsWith('//') || 
         SECURE_DOMAINS.some(domain => lowerHref.includes(domain));
};

/**
 * RELAY HANDSHAKE:
 * The most robust method for top-level navigation. 
 * Prevents "Iframe sandbox" errors.
 */
export const openExternal = (url: string) => {
  if (typeof window === 'undefined') return;

  const finalUrl = url.startsWith('http') ? url : `https://${url.replace(/^\/+/, '')}`;
  
  // 1. Attempt top-level assignment (strongest)
  try {
    if (window.top && window.top !== window) {
      window.top.location.href = finalUrl;
      return;
    }
  } catch (e) {
    // Cross-origin restriction on window.top, proceed to relay
  }

  // 2. Sovereign Relay: Form Submission with target _top
  const form = document.createElement('form');
  form.method = 'GET';
  form.action = finalUrl;
  form.target = '_blank';
  form.rel = 'noopener noreferrer';
  form.style.display = 'none';
  document.body.appendChild(form);
  
  try {
    form.submit();
  } catch (err) {
    // 3. Fallback to direct window open
    window.open(finalUrl, '_blank', 'noopener,noreferrer');
  } finally {
    setTimeout(() => {
      if (document.body.contains(form)) {
        document.body.removeChild(form);
      }
    }, 500);
  }
};

export const useRouter = () => {
  const setPath = useNavigationStore((s) => s.setPath);
  
  return {
    push: (path: string) => {
      if (isExternalLink(path)) {
        openExternal(path);
      } else {
        setPath(path);
        window.scrollTo(0, 0);
      }
    },
    replace: (path: string) => {
      if (isExternalLink(path)) {
        openExternal(path);
      } else {
        setPath(path);
        window.scrollTo(0, 0);
      }
    },
    back: () => window.history.back(),
    forward: () => window.history.forward(),
    refresh: () => window.location.reload(),
  };
};

export const usePathname = () => {
  return useNavigationStore((s) => s.currentPath);
};

export const useSearchParams = () => {
  return new URLSearchParams(typeof window !== 'undefined' ? window.location.search : '');
};

interface LinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  href: string;
  children: React.ReactNode;
}

export const Link: React.FC<LinkProps> = ({ href, children, onClick, ...props }) => {
  const setPath = useNavigationStore((s) => s.setPath);

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (onClick) onClick(e);

    const isExternal = isExternalLink(href);
    
    // Handle primary click (not cmd+click or right click)
    if (!e.defaultPrevented && e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
      if (isExternal) {
        e.preventDefault();
        openExternal(href);
      } else if (href.startsWith('#')) {
        e.preventDefault();
        const element = document.getElementById(href.replace('#', ''));
        element?.scrollIntoView({ behavior: 'smooth' });
      } else if (href.startsWith('/')) {
        e.preventDefault();
        setPath(href);
        window.scrollTo(0, 0);
      }
    }
  };

  return (
    <a 
      href={href} 
      onClick={handleClick} 
      target={isExternalLink(href) ? "_blank" : props.target}
      rel={isExternalLink(href) ? "noopener noreferrer" : props.rel}
      {...props}
    >
      {children}
    </a>
  );
};

export default Link;
