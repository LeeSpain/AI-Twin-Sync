import { useCallback } from 'react';
import { useAtlasStore } from '@/stores/atlas-store';

export const useAtlas = () => {
  const { 
    messages, 
    addMessage, 
    setLoading, 
    currentConversationId, 
    setConversationId 
  } = useAtlasStore();

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim()) return;

    // 1. Add User Message
    const userMsg = {
      id: Math.random().toString(36).substring(7),
      role: 'user' as const,
      content: text,
      timestamp: new Date().toISOString()
    };
    addMessage(userMsg);
    setLoading(true);

    try {
      const response = await fetch('/api/atlas/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: text,
          conversationId: currentConversationId,
          history: messages.map(m => ({ role: m.role, content: m.content }))
        }),
      });

      if (!response.ok) throw new Error('Failed to reach Atlas');

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let assistantContent = '';

      const assistantMsgId = Math.random().toString(36).substring(7);
      
      // Initial empty assistant message for streaming
      addMessage({
        id: assistantMsgId,
        role: 'assistant',
        content: '',
        timestamp: new Date().toISOString()
      });

      while (true) {
        const { done, value } = await reader!.read();
        if (done) break;

        const chunk = decoder.decode(value);
        assistantContent += chunk;
        
        // Update the last message in the store (the assistant one)
        useAtlasStore.setState((state) => ({
          messages: state.messages.map(m => 
            m.id === assistantMsgId ? { ...m, content: assistantContent } : m
          )
        }));
      }
    } catch (error) {
      console.error('Atlas Error:', error);
    } finally {
      setLoading(false);
    }
  }, [messages, addMessage, setLoading, currentConversationId]);

  return {
    messages,
    sendMessage,
    isLoading: useAtlasStore((s) => s.isLoading),
  };
};