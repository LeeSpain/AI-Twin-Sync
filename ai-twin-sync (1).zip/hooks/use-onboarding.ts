import { useCallback } from 'react';
import { useOnboardingStore } from '@/stores/onboarding-store';
import { ONBOARDING_STEPS } from '@/lib/onboarding/steps';

export const useOnboarding = () => {
  const { 
    currentStep, 
    setStep, 
    responses, 
    addResponse, 
    completeStep, 
    completedSteps,
    mode,
    setMode
  } = useOnboardingStore();

  const nextStep = useCallback(async () => {
    if (currentStep < ONBOARDING_STEPS.length - 1) {
      completeStep(currentStep);
      const nextIdx = currentStep + 1;
      setStep(nextIdx);
      
      // Persist progress to API
      await fetch('/api/onboarding/progress', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentStep: nextIdx, completedSteps: [...completedSteps, currentStep] })
      });
    }
  }, [currentStep, setStep, completeStep, completedSteps]);

  const prevStep = useCallback(() => {
    if (currentStep > 0) {
      setStep(currentStep - 1);
    }
  }, [currentStep, setStep]);

  const saveResponse = useCallback(async (stepId: string, data: any) => {
    addResponse(stepId, data);
    await fetch('/api/onboarding/responses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stepId, response: data })
    });
  }, [addResponse]);

  return {
    currentStep,
    stepConfig: ONBOARDING_STEPS[currentStep],
    totalSteps: ONBOARDING_STEPS.length,
    responses,
    nextStep,
    prevStep,
    saveResponse,
    mode,
    setMode,
    isFirst: currentStep === 0,
    isLast: currentStep === ONBOARDING_STEPS.length - 1,
    progress: ((currentStep + 1) / ONBOARDING_STEPS.length) * 100
  };
};