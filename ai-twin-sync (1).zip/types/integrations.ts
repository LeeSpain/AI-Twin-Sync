
export interface BaseIntegration {
  readonly id: string
  readonly isConnected: boolean
  readonly lastSyncedAt?: Date
}

export interface GmailIntegration extends BaseIntegration {
  readonly emailAddress: string
  readonly unreadCount: number
  readonly labels: string[]
}

export interface GoogleCalendarIntegration extends BaseIntegration {
  readonly primaryCalendarId: string
  readonly calendars: {
    id: string
    summary: string
    isPrimary: boolean
  }[]
}

export interface SlackIntegration extends BaseIntegration {
  readonly workspaceName: string
  readonly channels: {
    id: string
    name: string
    isPrivate: boolean
  }[]
}

export type AnyIntegration = 
  | GmailIntegration 
  | GoogleCalendarIntegration 
  | SlackIntegration
