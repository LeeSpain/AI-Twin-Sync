
export enum AgentType {
  COMMANDER = 'commander',
  EMAIL = 'email',
  CALENDAR = 'calendar',
  TASK = 'task',
  CONTACT = 'contact',
  SEARCH = 'search',
  VOICE = 'voice',
  NOTIFICATION = 'notification'
}

export enum IntentType {
  EMAIL_READ = 'email_read',
  EMAIL_DRAFT = 'email_draft',
  EMAIL_SEND = 'email_send',
  CALENDAR_VIEW = 'calendar_view',
  CALENDAR_BOOK = 'calendar_book',
  TASK_CREATE = 'task_create',
  TASK_LIST = 'task_list',
  SEARCH_GLOBAL = 'search_global',
  CONTACT_INFO = 'contact_info',
  VOICE_COMMAND = 'voice_command',
  SMALL_TALK = 'small_talk',
  ACTION_APPROVAL = 'action_approval'
}

export interface AgentContext {
  userId: string;
  userName: string;
  preferences: string;
  dateTime: string;
  history: { role: 'user' | 'assistant', content: string }[];
}

export interface AgentResponse {
  text: string;
  actions?: any[];
  metadata?: Record<string, any>;
}
