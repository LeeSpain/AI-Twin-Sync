import { Json } from './database'

export interface AtlasMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: string
  metadata?: {
    thought_process?: string
    tool_calls?: any[]
  }
}

export interface AtlasConversation {
  id: string
  messages: AtlasMessage[]
  last_updated: string
}

export interface AtlasAction {
  id: string
  type: 'calendar_sync' | 'task_creation' | 'email_draft' | 'search'
  status: 'pending' | 'executing' | 'completed' | 'failed'
  description: string
  confidence: number
  requires_approval: boolean
}

export interface AtlasContext {
  userName: string
  preferences: string
  currentDateTime: string
}

export interface AtlasResponse {
  text: string
  actions?: AtlasAction[]
}

export interface AtlasMemory {
  id: string
  fragment: string
  importance: number
  last_recalled: string
}