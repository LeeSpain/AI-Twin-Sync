
export enum ActionType {
  EMAIL_SEND = 'email_send',
  EMAIL_DRAFT = 'email_draft',
  CALENDAR_CREATE = 'calendar_create',
  CALENDAR_UPDATE = 'calendar_update',
  TASK_CREATE = 'task_create',
  PHONE_CALL = 'phone_call',
  SLACK_MESSAGE = 'slack_message'
}

export enum ActionStatus {
  PENDING = 'pending',
  EXECUTING = 'executing',
  COMPLETED = 'completed',
  FAILED = 'failed',
  ROLLED_BACK = 'rolled_back'
}

export interface AtlasAction {
  id: string;
  userId: string;
  type: ActionType;
  status: ActionStatus;
  description: string;
  inputData: any;
  outputData?: any;
  confidence: number;
  requiresApproval: boolean;
  executedAt?: string;
  createdAt: string;
}
