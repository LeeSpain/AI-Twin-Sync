export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: UserProfile
        Insert: Omit<UserProfile, 'created_at' | 'updated_at'>
        Update: Partial<UserProfile>
      }
      companies: {
        Row: Company
        Insert: Omit<Company, 'id' | 'created_at' | 'updated_at'>
        Update: Partial<Company>
      }
      tasks: {
        Row: Task
        Insert: Omit<Task, 'id' | 'created_at' | 'updated_at'>
        Update: Partial<Task>
      }
      ai_actions: {
        Row: AIAction
        Insert: Omit<AIAction, 'id' | 'created_at' | 'executed_at'>
        Update: Partial<AIAction>
      }
      atlas_memories: {
        Row: AtlasMemory
        Insert: Omit<AtlasMemory, 'id' | 'created_at' | 'updated_at'>
        Update: Partial<AtlasMemory>
      }
      onboarding_progress: {
        Row: OnboardingProgress
        Insert: Omit<OnboardingProgress, 'created_at' | 'updated_at'>
        Update: Partial<OnboardingProgress>
      }
      onboarding_responses: {
        Row: OnboardingResponse
        Insert: Omit<OnboardingResponse, 'id' | 'created_at'>
        Update: Partial<OnboardingResponse>
      }
      conversations: {
        Row: Conversation
        Insert: Omit<Conversation, 'id' | 'created_at' | 'updated_at'>
        Update: Partial<Conversation>
      }
      messages: {
        Row: Message
        Insert: Omit<Message, 'id' | 'created_at'>
        Update: Partial<Message>
      }
    }
  }
}

export interface UserProfile {
  id: string
  email: string
  full_name: string | null
  preferred_name: string | null
  phone: string | null
  timezone: string
  avatar_url: string | null
  role: 'user' | 'admin'
  onboarding_completed: boolean
  settings: Json
  created_at: string
  updated_at: string
}

export interface Company {
  id: string
  user_id: string
  name: string
  website_url: string | null
  industry: string | null
  description: string | null
  is_primary: boolean
  ai_context: Json
  created_at: string
  updated_at: string
}

export interface Task {
  id: string
  user_id: string
  title: string
  description: string | null
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled'
  priority: 'low' | 'medium' | 'high' | 'urgent'
  due_date: string | null
  completed_at: string | null
  created_at: string
  updated_at: string
}

export interface AIAction {
  id: string
  user_id: string
  action_type: string
  description: string | null
  status: 'pending' | 'approved' | 'rejected' | 'executed' | 'failed'
  confidence_score: number | null
  input_data: Json
  output_data: Json
  requires_approval: boolean
  executed_at: string | null
  created_at: string
}

export interface AtlasMemory {
  id: string
  user_id: string
  type: string
  fragment: string
  importance: number
  last_recalled_at: string | null
  created_at: string
  updated_at: string
}

export interface OnboardingProgress {
  user_id: string
  status: 'not_started' | 'in_progress' | 'completed'
  current_step: number
  completed_steps: Json
  started_at: string | null
  completed_at: string | null
  created_at: string
  updated_at: string
}

export interface OnboardingResponse {
  id: string
  user_id: string
  step_id: string
  question_id: string
  response: Json
  created_at: string
}

export interface Conversation {
  id: string
  user_id: string
  title: string | null
  is_active: boolean
  context: Json
  created_at: string
  updated_at: string
}

export interface Message {
  id: string
  conversation_id: string
  role: 'user' | 'atlas'
  content: string
  metadata: Json
  created_at: string
}
