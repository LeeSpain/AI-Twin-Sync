import React, { useState } from 'react';
import AtlasQuestion from './atlas-question';
import CompanyAnalyzer from './company-analyzer';
import { useOnboarding } from '@/hooks/use-onboarding';
import { Building, Plus, Trash2 } from 'lucide-react';

export default function CompaniesStep() {
  const { saveResponse, responses } = useOnboarding();
  const [companies, setCompanies] = useState<any[]>(responses['companies'] || []);

  const handleAddCompany = (company: any) => {
    const newCompanies = [...companies, company];
    setCompanies(newCompanies);
    saveResponse('companies', newCompanies);
  };

  const handleRemove = (idx: number) => {
    const newCompanies = companies.filter((_, i) => i !== idx);
    setCompanies(newCompanies);
    saveResponse('companies', newCompanies);
  };

  return (
    <div className="space-y-12">
      <AtlasQuestion 
        question="Which organizations do you currently command? Provide a URL for any company you want me to analyze." 
        hint="I'll scan their public footprint to learn about their mission, industry, and core values."
      />

      <div className="pl-24 space-y-8">
        <CompanyAnalyzer onAdd={handleAddCompany} />

        {companies.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {companies.map((company, idx) => (
              <div key={idx} className="glass-panel p-6 rounded-[2rem] border-white/10 group animate-in zoom-in-95 duration-500">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400">
                    <Building size={24} />
                  </div>
                  <button 
                    onClick={() => handleRemove(idx)}
                    className="p-2 text-slate-600 hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
                <h4 className="text-xl font-bold text-white mb-1">{company.name}</h4>
                <p className="text-[10px] font-black uppercase tracking-widest text-blue-500 mb-3">{company.industry}</p>
                <p className="text-sm text-slate-400 line-clamp-3 leading-relaxed">{company.description}</p>
              </div>
            ))}
          </div>
        )}

        {companies.length === 0 && (
          <div className="p-12 border-2 border-dashed border-white/5 rounded-[2.5rem] flex flex-col items-center justify-center text-slate-600 text-center space-y-2 opacity-50">
            <Building size={40} className="mb-2" />
            <p className="font-bold uppercase tracking-widest text-xs">No organizations indexed</p>
            <p className="text-sm">Add your primary company website above to begin contextual learning.</p>
          </div>
        )}
      </div>
    </div>
  );
}