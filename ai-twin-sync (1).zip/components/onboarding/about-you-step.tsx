import React, { useState } from 'react';
import AtlasQuestion from './atlas-question';
import { useOnboarding } from '@/hooks/use-onboarding';

export default function AboutYouStep() {
  const { saveResponse, responses } = useOnboarding();
  const [data, setData] = useState(responses['about-you'] || {
    fullName: '',
    preferredName: '',
    phone: '',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    description: ''
  });

  const handleChange = (field: string, value: string) => {
    const newData = { ...data, [field]: value };
    setData(newData);
    saveResponse('about-you', newData);
  };

  return (
    <div className="space-y-12">
      <AtlasQuestion 
        question="First, let's establish your origin identity. What should I call you?" 
        hint="Please provide your full legal name and your preferred handle."
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pl-24 animate-in fade-in slide-in-from-bottom-4 duration-1000">
        <div className="space-y-2">
          <label className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 ml-1">Full Legal Name</label>
          <input
            type="text"
            value={data.fullName}
            onChange={(e) => handleChange('fullName', e.target.value)}
            placeholder="Johnathan Doe"
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all placeholder:text-slate-700"
          />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 ml-1">Preferred Handle</label>
          <input
            type="text"
            value={data.preferredName}
            onChange={(e) => handleChange('preferredName', e.target.value)}
            placeholder="JD / Chief"
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all placeholder:text-slate-700"
          />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 ml-1">Secure Contact No.</label>
          <input
            type="tel"
            value={data.phone}
            onChange={(e) => handleChange('phone', e.target.value)}
            placeholder="+1 (555) 000-0000"
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all placeholder:text-slate-700"
          />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 ml-1">Temporal Zone</label>
          <select
            value={data.timezone}
            onChange={(e) => handleChange('timezone', e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all appearance-none"
          >
            <option value="UTC">UTC (Universal)</option>
            <option value="America/New_York">EST (New York)</option>
            <option value="Europe/London">GMT (London)</option>
            <option value="Asia/Tokyo">JST (Tokyo)</option>
            {/* ... more could be added dynamically */}
          </select>
        </div>
        <div className="md:col-span-2 space-y-2">
          <label className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 ml-1">Mission Briefing (About You)</label>
          <textarea
            rows={4}
            value={data.description}
            onChange={(e) => handleChange('description', e.target.value)}
            placeholder="Tell me about your current objectives and how I can best support your workflow..."
            className="w-full bg-white/5 border border-white/10 rounded-[2rem] px-6 py-6 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all placeholder:text-slate-700 resize-none"
          />
        </div>
      </div>
    </div>
  );
}