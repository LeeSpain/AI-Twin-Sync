import React, { useState } from 'react';
import AtlasQuestion from './atlas-question';
import { useOnboarding } from '@/hooks/use-onboarding';
import { Heart, Plus, User, Trash2 } from 'lucide-react';

export default function FamilyStep() {
  const { saveResponse, responses } = useOnboarding();
  const [family, setFamily] = useState<any[]>(responses['family'] || []);
  const [isAdding, setIsAdding] = useState(false);
  const [newMember, setNewMember] = useState({ name: '', relationship: '', phone: '' });

  const handleAdd = () => {
    if (!newMember.name) return;
    const updated = [...family, newMember];
    setFamily(updated);
    saveResponse('family', updated);
    setNewMember({ name: '', relationship: '', phone: '' });
    setIsAdding(false);
  };

  const remove = (idx: number) => {
    const updated = family.filter((_, i) => i !== idx);
    setFamily(updated);
    saveResponse('family', updated);
  };

  return (
    <div className="space-y-12">
      <AtlasQuestion 
        question="Family members are absolute VIPs. They can interrupt any status except 'Emergency-Only'. Who are they?" 
        hint="I'll grant these contacts special bypass permissions in your notification matrix."
      />

      <div className="pl-24 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-1000">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {family.map((member, idx) => (
            <div key={idx} className="glass-panel p-6 rounded-[2rem] border-white/5 flex items-center gap-4 relative group">
              <div className="w-12 h-12 rounded-xl bg-pink-500/10 flex items-center justify-center text-pink-400">
                <Heart size={24} />
              </div>
              <div>
                <h4 className="font-bold text-white">{member.name}</h4>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">{member.relationship} • {member.phone}</p>
              </div>
              <button 
                onClick={() => remove(idx)}
                className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity text-slate-600 hover:text-red-400"
              >
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>

        {isAdding ? (
          <div className="glass-panel p-8 rounded-[2.5rem] border-white/10 space-y-6 max-w-xl animate-in zoom-in-95">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Name</label>
                  <input 
                    type="text" 
                    value={newMember.name} 
                    onChange={e => setNewMember({...newMember, name: e.target.value})}
                    placeholder="Sarah Doe"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Relationship</label>
                  <input 
                    type="text" 
                    value={newMember.relationship} 
                    onChange={e => setNewMember({...newMember, relationship: e.target.value})}
                    placeholder="Wife / Husband"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white"
                  />
                </div>
             </div>
             <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Phone</label>
                <input 
                  type="tel" 
                  value={newMember.phone} 
                  onChange={e => setNewMember({...newMember, phone: e.target.value})}
                  placeholder="+1 (555) 000-0000"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white"
                />
             </div>
             <div className="flex gap-4">
               <button onClick={() => setIsAdding(false)} className="flex-1 py-3 border border-white/10 rounded-xl text-xs font-bold text-slate-500 hover:bg-white/5 transition-colors">Cancel</button>
               <button onClick={handleAdd} className="flex-1 py-3 bg-blue-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-600/20">Add VIP</button>
             </div>
          </div>
        ) : (
          <button 
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 px-8 py-4 bg-white/5 border border-dashed border-white/10 rounded-[1.5rem] text-slate-400 hover:text-white hover:border-blue-500/50 hover:bg-blue-600/5 transition-all text-sm font-bold"
          >
            <Plus size={18} />
            Append New Family Baseline
          </button>
        )}
      </div>
    </div>
  );
}