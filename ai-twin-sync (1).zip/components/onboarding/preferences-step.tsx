import React, { useState } from 'react';
import AtlasQuestion from './atlas-question';
import { useOnboarding } from '@/hooks/use-onboarding';
import { Clock, MessageSquare, Coffee, Shield } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PreferencesStep() {
  const { saveResponse, responses } = useOnboarding();
  const [prefs, setPrefs] = useState(responses['preferences'] || {
    workStart: '08:00',
    workEnd: '18:00',
    tone: 'professional',
    syncFrequency: 'realtime'
  });

  const update = (key: string, val: string) => {
    const newPrefs = { ...prefs, [key]: val };
    setPrefs(newPrefs);
    saveResponse('preferences', newPrefs);
  };

  return (
    <div className="space-y-12">
      <AtlasQuestion 
        question="How should I interact on your behalf? Define your operational hours and communication tone." 
        hint="I will adapt my drafting style and meeting booking logic based on these parameters."
      />

      <div className="pl-24 grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-1000">
        <div className="glass-panel p-8 rounded-[2.5rem] border-white/5 space-y-6">
          <div className="flex items-center gap-3 text-blue-400">
            <Clock size={20} />
            <h4 className="font-black uppercase tracking-widest text-sm">Active Cycles</h4>
          </div>
          <div className="flex gap-4">
            <div className="flex-1 space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Commence</label>
              <input 
                type="time" 
                value={prefs.workStart} 
                onChange={(e) => update('workStart', e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              />
            </div>
            <div className="flex-1 space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Terminate</label>
              <input 
                type="time" 
                value={prefs.workEnd} 
                onChange={(e) => update('workEnd', e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              />
            </div>
          </div>
        </div>

        <div className="glass-panel p-8 rounded-[2.5rem] border-white/5 space-y-6">
          <div className="flex items-center gap-3 text-purple-400">
            <MessageSquare size={20} />
            <h4 className="font-black uppercase tracking-widest text-sm">Linguistic Tone</h4>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {['formal', 'professional', 'casual', 'concise'].map((tone) => (
              <button
                key={tone}
                onClick={() => update('tone', tone)}
                className={cn(
                  "py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all",
                  prefs.tone === tone 
                    ? "bg-purple-600 text-white border-purple-500" 
                    : "bg-white/5 text-slate-400 border-white/5 hover:border-white/20"
                )}
              >
                {tone}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}