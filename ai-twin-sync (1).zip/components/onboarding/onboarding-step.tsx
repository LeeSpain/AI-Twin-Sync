
import React from 'react';
import { ArrowLeft, ArrowRight, Save } from 'lucide-react';
import { useOnboarding } from '@/hooks/use-onboarding';

interface OnboardingStepProps {
  // Fix: Making children optional to satisfy TS check in TextOnboarding where they are passed dynamically
  children?: React.ReactNode;
  onNext?: () => void;
  canNext?: boolean;
}

export default function OnboardingStep({ children, onNext, canNext = true }: OnboardingStepProps) {
  const { prevStep, nextStep, isFirst, isLast, progress } = useOnboarding();

  const handleNext = () => {
    if (onNext) onNext();
    nextStep();
  };

  return (
    <div className="w-full space-y-12 animate-in fade-in slide-in-from-right-8 duration-700">
      <div className="space-y-12">
        {children}
      </div>

      <div className="pt-8 flex items-center justify-between border-t border-white/5">
        <button
          onClick={prevStep}
          disabled={isFirst}
          className="flex items-center gap-2 px-6 py-3 rounded-2xl text-slate-400 hover:text-white hover:bg-white/5 disabled:opacity-0 transition-all font-bold text-sm"
        >
          <ArrowLeft size={18} />
          Baseline Previous
        </button>

        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <div className="text-[9px] font-black uppercase tracking-widest text-slate-600">Sync Status</div>
            <div className="text-xs font-mono text-blue-400">{Math.round(progress)}% Complete</div>
          </div>
          
          <button
            onClick={handleNext}
            disabled={!canNext}
            className="flex items-center gap-3 px-8 py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-30 text-white rounded-[1.5rem] font-black shadow-xl shadow-blue-600/20 transition-all active:scale-95 text-sm uppercase tracking-widest"
          >
            {isLast ? 'Complete Sync' : 'Next Step'}
            <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
