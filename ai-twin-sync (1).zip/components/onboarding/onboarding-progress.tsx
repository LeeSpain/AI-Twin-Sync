import React from 'react';
import { useOnboardingStore } from '@/stores/onboarding-store';
import { ONBOARDING_STEPS } from '@/lib/onboarding/steps';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function OnboardingProgress() {
  const { currentStep, completedSteps } = useOnboardingStore();

  return (
    <div className="hidden md:flex items-center gap-4">
      {ONBOARDING_STEPS.map((step, idx) => {
        const isActive = currentStep === idx;
        const isCompleted = completedSteps.includes(idx);
        
        return (
          <div key={step.id} className="flex items-center">
            <div className={cn(
              "w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-black transition-all",
              isActive 
                ? "bg-blue-600 text-white shadow-[0_0_15px_rgba(59,130,246,0.4)]" 
                : isCompleted 
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                : "bg-white/5 text-slate-500 border border-white/5"
            )}>
              {isCompleted ? <Check size={14} strokeWidth={3} /> : idx + 1}
            </div>
            {idx < ONBOARDING_STEPS.length - 1 && (
              <div className={cn(
                "w-8 h-[1px] mx-1",
                isCompleted ? "bg-emerald-500/30" : "bg-white/5"
              )} />
            )}
          </div>
        );
      })}
    </div>
  );
}