import React, { useState } from 'react';
import AtlasQuestion from './atlas-question';
import { Mic, Check, Loader2, Play } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function VoiceSetupStep() {
  const [phrases, setPhrases] = useState([
    { text: "Hey Atlas, what's on my calendar today?", recorded: false },
    { text: "Send an email to Sarah about the budget meeting.", recorded: false },
    { text: "Book a flight to London for next Tuesday.", recorded: false },
  ]);
  const [isRecording, setIsRecording] = useState<number | null>(null);

  const startRecord = (idx: number) => {
    setIsRecording(idx);
    setTimeout(() => {
      setPhrases(prev => prev.map((p, i) => i === idx ? { ...p, recorded: true } : p));
      setIsRecording(null);
    }, 2000);
  };

  return (
    <div className="space-y-12">
      <AtlasQuestion 
        question="Let's calibrate your biometric vocal profile. Read the following phrases clearly." 
        hint="This enables secure voice-auth and allows me to synthesize your preferred communication style."
      />

      <div className="pl-24 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-1000 max-w-2xl">
        {phrases.map((phrase, idx) => (
          <div key={idx} className="glass-panel p-6 rounded-[2rem] border-white/5 flex items-center justify-between group">
            <div className="flex-1">
              <p className="text-lg font-bold text-white mb-1">"{phrase.text}"</p>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-600">Sample {idx + 1}</p>
            </div>
            
            <button
              onClick={() => startRecord(idx)}
              disabled={isRecording !== null}
              className={cn(
                "w-12 h-12 rounded-xl flex items-center justify-center transition-all",
                phrase.recorded 
                  ? "bg-emerald-500/10 text-emerald-400" 
                  : isRecording === idx
                  ? "bg-red-500 text-white animate-pulse"
                  : "bg-white/5 text-slate-500 hover:bg-blue-600 hover:text-white"
              )}
            >
              {isRecording === idx ? <Loader2 size={20} className="animate-spin" /> : phrase.recorded ? <Check size={20} /> : <Mic size={20} />}
            </button>
          </div>
        ))}

        <div className="pt-8 grid grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">Atlas Vocal Engine</label>
            <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm">
              <option>Zephyr (Neutral Professional)</option>
              <option>Puck (Warm / Friendly)</option>
              <option>Fenrir (Serious / Command)</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">Secure Neural PIN</label>
            <input 
              type="password" 
              maxLength={4} 
              placeholder="0000"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-center font-black tracking-widest"
            />
          </div>
        </div>
      </div>
    </div>
  );
}