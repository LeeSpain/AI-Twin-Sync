import React, { useState, useEffect } from 'react';
import { Bot, Terminal } from 'lucide-react';

interface AtlasQuestionProps {
  question: string;
  hint?: string;
}

export default function AtlasQuestion({ question, hint }: AtlasQuestionProps) {
  const [displayedText, setDisplayedText] = useState('');
  
  useEffect(() => {
    let i = 0;
    setDisplayedText('');
    const timer = setInterval(() => {
      setDisplayedText((prev) => question.slice(0, prev.length + 1));
      if (displayedText.length >= question.length) clearInterval(timer);
    }, 20);
    return () => clearInterval(timer);
  }, [question]);

  return (
    <div className="flex gap-6 items-start">
      <div className="relative group">
        <div className="w-16 h-16 rounded-[2rem] bg-gradient-to-br from-blue-600 to-purple-600 p-[2px] shadow-2xl shadow-blue-600/20 group-hover:rotate-3 transition-transform">
          <div className="w-full h-full bg-[#030712] rounded-[1.8rem] flex items-center justify-center">
            <Bot className="w-8 h-8 text-blue-400" />
          </div>
        </div>
        <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-4 border-[#030712] animate-pulse"></div>
      </div>
      
      <div className="flex-1 space-y-3 pt-1">
        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-blue-400">
          <Terminal size={10} />
          Atlas Intelligence
        </div>
        <div className="glass-panel p-8 rounded-[2rem] rounded-tl-none border-white/10 shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-blue-600 opacity-20"></div>
          <p className="text-2xl md:text-3xl font-bold text-white leading-tight tracking-tight">
            {displayedText}
            {displayedText.length < question.length && <span className="inline-block w-2 h-6 bg-blue-500 ml-1 animate-pulse">|</span>}
          </p>
          {hint && displayedText.length >= question.length && (
            <p className="mt-4 text-sm text-slate-500 font-medium animate-in fade-in slide-in-from-top-2">
              {hint}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}