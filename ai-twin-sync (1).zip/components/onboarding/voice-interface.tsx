
import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Terminal, Bot, Sparkles, Keyboard } from 'lucide-react';
import { Link } from '@/lib/navigation';
import { useOnboarding } from '@/hooks/use-onboarding';
import { cn } from '@/lib/utils';

export default function VoiceInterface() {
  const { currentStep, stepConfig, nextStep } = useOnboarding();
  const [isListening, setIsListening] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [status, setStatus] = useState('Standby');

  const toggleListen = () => {
    if (isListening) {
      setIsListening(false);
      setStatus('Processing...');
      setTimeout(() => {
        setTranscription("Confirmed. Commencing next baseline synchronization.");
        setTimeout(() => {
          nextStep();
          setTranscription('');
          setStatus('Ready');
        }, 1500);
      }, 1000);
    } else {
      setIsListening(true);
      setStatus('Listening...');
    }
  };

  return (
    <div className="w-full max-w-2xl space-y-12 text-center animate-in fade-in zoom-in duration-700">
      <div className="space-y-2">
        <p className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-500">Step {currentStep + 1} / 8</p>
        <h2 className="text-3xl font-black text-white">{stepConfig.title}</h2>
      </div>

      <div className="relative flex items-center justify-center">
        {/* Animated Orbs */}
        <div className={cn(
          "absolute w-80 h-80 bg-blue-600/10 blur-[100px] rounded-full transition-all duration-1000",
          isListening ? "scale-150 opacity-100" : "scale-100 opacity-50"
        )}></div>
        
        <button
          onClick={toggleListen}
          className={cn(
            "relative w-48 h-48 rounded-[4rem] flex flex-col items-center justify-center transition-all duration-500 active:scale-90 group",
            isListening 
              ? "bg-red-500 text-white shadow-[0_0_80px_rgba(239,68,68,0.4)]" 
              : "bg-blue-600 text-white shadow-[0_0_80px_rgba(59,130,246,0.4)]"
          )}
        >
          {isListening ? (
            <div className="flex gap-1.5 items-end h-12 mb-2">
              {[1, 2, 3, 4, 3, 2, 1].map((h, i) => (
                <div 
                  key={i} 
                  className="w-1.5 bg-white rounded-full animate-[bounce_1s_infinite]" 
                  style={{ height: `${h * 10}px`, animationDelay: `${i * 100}ms` }}
                />
              ))}
            </div>
          ) : (
            <Mic size={48} className="mb-2 group-hover:scale-110 transition-transform" />
          )}
          <span className="text-[10px] font-black uppercase tracking-widest">{isListening ? 'Stop' : 'Speak'}</span>
        </button>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-center gap-3 text-xs font-mono text-slate-500 uppercase tracking-widest">
          <Terminal size={14} />
          {status}
        </div>
        
        <div className="glass-panel p-10 rounded-[2.5rem] border-white/5 min-h-[160px] flex items-center justify-center text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>
          {transcription ? (
            <p className="text-xl font-bold text-white italic animate-in fade-in duration-500">"{transcription}"</p>
          ) : (
            <p className="text-xl text-slate-500 font-medium italic">
              "Atlas is listening... tell me about your {stepConfig.id.replace('-', ' ')}."
            </p>
          )}
        </div>
      </div>

      <div className="pt-8 flex items-center justify-center gap-8">
        <Link 
          href="/onboarding/text" 
          className="text-xs font-black uppercase tracking-widest text-slate-600 hover:text-blue-400 transition-colors flex items-center gap-2"
        >
          <Keyboard size={16} />
          Switch to Text Link
        </Link>
      </div>
    </div>
  );
}
