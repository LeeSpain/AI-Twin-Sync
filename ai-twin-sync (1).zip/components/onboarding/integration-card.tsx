
import React, { useState } from 'react';
import { ShieldCheck, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { openExternal } from '@/lib/navigation';

interface IntegrationCardProps {
  id: string;
  name: string;
  icon: React.ReactNode;
  provider: string;
  key?: React.Key;
}

export default function IntegrationCard({ id, name, icon, provider }: IntegrationCardProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    
    // Simulate external OAuth URL
    const oauthUrls: Record<string, string> = {
      github: 'https://github.com/login/oauth/authorize',
      google: 'https://accounts.google.com/o/oauth2/auth',
      slack: 'https://slack.com/oauth/v2/authorize',
      microsoft: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize'
    };

    const targetUrl = oauthUrls[provider] || '#';
    
    if (targetUrl !== '#') {
      openExternal(targetUrl);
    }

    // Simulate callback completion
    setTimeout(() => {
      setIsConnected(true);
      setIsConnecting(false);
    }, 2000);
  };

  return (
    <div className={cn(
      "glass-panel p-6 rounded-[2rem] border-white/5 hover:border-white/20 transition-all group relative overflow-hidden",
      isConnected && "bg-emerald-500/5 border-emerald-500/20"
    )}>
      <div className="flex items-center justify-between mb-6">
        <div className={cn(
          "w-12 h-12 rounded-xl flex items-center justify-center transition-all",
          isConnected ? "bg-emerald-500/10 text-emerald-400" : "bg-white/5 text-slate-400 group-hover:text-blue-400"
        )}>
          {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<{ size?: number }>, { size: 24 }) : icon}
        </div>
        {isConnected && <ShieldCheck className="text-emerald-400" size={20} />}
      </div>
      
      <div className="space-y-1">
        <h4 className="text-lg font-bold text-white">{name}</h4>
        <p className="text-[10px] font-black uppercase tracking-widest text-slate-600">Secure Protocol</p>
      </div>

      <button
        onClick={handleConnect}
        disabled={isConnecting || isConnected}
        className={cn(
          "w-full mt-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2",
          isConnected 
            ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
            : "bg-white/5 hover:bg-white/10 text-white border border-white/10"
        )}
      >
        {isConnecting ? (
          <Loader2 size={14} className="animate-spin" />
        ) : isConnected ? (
          'Linked'
        ) : (
          'Connect'
        )}
      </button>
    </div>
  );
}
