import React, { useState } from 'react';
import AtlasQuestion from './atlas-question';
import { useOnboarding } from '@/hooks/use-onboarding';
import { Zap, Shield, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function AutonomyStep() {
  const { saveResponse, responses } = useOnboarding();
  const [autonomy, setAutonomy] = useState(responses['autonomy'] || {
    email: 'moderate',
    calendar: 'auto',
    threshold: 85
  });

  const update = (key: string, val: any) => {
    const next = { ...autonomy, [key]: val };
    setAutonomy(next);
    saveResponse('autonomy', next);
  };

  return (
    <div className="space-y-12">
      <AtlasQuestion 
        question="What is my agency threshold? How much autonomous action should I take without your direct approval?" 
        hint="I will always prompt for approval on high-risk actions below your confidence threshold."
      />

      <div className="pl-24 space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-1000 max-w-3xl">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
              <Zap size={16} className="text-amber-400" />
              Confidence Threshold
            </h4>
            <span className="text-xl font-black text-blue-400 font-mono">{autonomy.threshold}%</span>
          </div>
          <input 
            type="range" 
            min="50" 
            max="99" 
            value={autonomy.threshold}
            onChange={(e) => update('threshold', parseInt(e.target.value))}
            className="w-full h-2 bg-white/5 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />
          <div className="flex justify-between text-[9px] font-mono text-slate-600 uppercase tracking-widest">
            <span>High Agency (50%)</span>
            <span>Strict Oversight (99%)</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
           <div className="glass-panel p-8 rounded-[2.5rem] border-white/5 space-y-6">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500">Email Autonomy</h4>
              <div className="space-y-3">
                {[
                  { id: 'low', label: 'Manual Approval Only', desc: 'Ask before sending anything' },
                  { id: 'moderate', label: 'Hybrid Agency', desc: 'Auto-reply routine, ask for strategic' },
                  { id: 'high', label: 'Full Agency', desc: 'Manage all communication channels' }
                ].map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => update('email', opt.id)}
                    className={cn(
                      "w-full text-left p-4 rounded-2xl border transition-all space-y-1",
                      autonomy.email === opt.id 
                        ? "bg-blue-600/10 border-blue-500/50" 
                        : "bg-white/5 border-white/5 hover:border-white/10"
                    )}
                  >
                    <p className="text-xs font-bold text-white">{opt.label}</p>
                    <p className="text-[10px] text-slate-500">{opt.desc}</p>
                  </button>
                ))}
              </div>
           </div>

           <div className="glass-panel p-8 rounded-[2.5rem] border-white/5 space-y-6">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500">Calendar Agency</h4>
              <div className="space-y-3">
                {[
                  { id: 'manual', label: 'Ask to Book', desc: 'Never modify schedule without prompt' },
                  { id: 'auto', label: 'Smart Booking', desc: 'Internal auto-book, external via prompt' },
                  { id: 'full', label: 'Schedule Master', desc: 'Full control of time allocation' }
                ].map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => update('calendar', opt.id)}
                    className={cn(
                      "w-full text-left p-4 rounded-2xl border transition-all space-y-1",
                      autonomy.calendar === opt.id 
                        ? "bg-blue-600/10 border-blue-500/50" 
                        : "bg-white/5 border-white/5 hover:border-white/10"
                    )}
                  >
                    <p className="text-xs font-bold text-white">{opt.label}</p>
                    <p className="text-[10px] text-slate-500">{opt.desc}</p>
                  </button>
                ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}