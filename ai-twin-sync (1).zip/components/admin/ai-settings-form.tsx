import React, { useState } from 'react';
import { Cpu, Thermometer, ShieldCheck, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function AISettingsForm() {
  const [config, setConfig] = useState({
    primaryModel: 'gemini-3-pro-preview',
    temperature: 0.7,
    maxTokens: 2048,
    guardrails: {
      undoWindow: true,
      auditLog: true,
      approvalLegal: true,
      videoCalls: false,
      escalation: true
    }
  });

  const toggleGuardrail = (key: keyof typeof config.guardrails) => {
    setConfig(prev => ({
      ...prev,
      guardrails: { ...prev.guardrails, [key]: !prev.guardrails[key] }
    }));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="glass-panel rounded-[2.5rem] p-8 border-white/5 space-y-10">
        <h3 className="text-lg font-bold flex items-center gap-3">
          <Cpu className="text-rose-500" />
          Intelligence Calibration
        </h3>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">Primary Neural Model</label>
            <select 
              value={config.primaryModel}
              onChange={(e) => setConfig({...config, primaryModel: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white appearance-none focus:outline-none focus:ring-2 focus:ring-rose-500/30"
            >
              <option value="gemini-3-pro-preview">Gemini 3 Pro (Recommended)</option>
              <option value="gemini-3-flash-preview">Gemini 3 Flash (Performant)</option>
              <option value="gemini-2.5-pro">Gemini 2.5 Pro (Legacy)</option>
            </select>
          </div>

          <div className="space-y-6">
            <div className="flex justify-between items-center">
               <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
                <Thermometer size={14} className="text-rose-500" />
                Temperature (Creativity)
               </label>
               <span className="text-sm font-mono text-rose-500 font-bold">{config.temperature}</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="1" 
              step="0.1" 
              value={config.temperature}
              onChange={(e) => setConfig({...config, temperature: parseFloat(e.target.value)})}
              className="w-full h-2 bg-white/5 rounded-lg appearance-none cursor-pointer accent-rose-600"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">Max Output Tokens</label>
            <input 
              type="number"
              value={config.maxTokens}
              onChange={(e) => setConfig({...config, maxTokens: parseInt(e.target.value)})}
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-rose-500/30"
            />
          </div>
        </div>
      </div>

      <div className="glass-panel rounded-[2.5rem] p-8 border-white/5 space-y-10 bg-rose-500/[0.02]">
        <h3 className="text-lg font-bold flex items-center gap-3">
          <ShieldCheck className="text-rose-500" />
          Safety & Guardrails
        </h3>

        <div className="space-y-4">
          {[
            { id: 'undoWindow', label: '20-second Undo Window', desc: 'Allows user to intercept any autonomous action' },
            { id: 'auditLog', label: 'Compulsory Audit Logging', desc: 'All neural interactions are recorded permanently' },
            { id: 'approvalLegal', label: 'Legal Topic Escalate', desc: 'Require approval for any legally binding topics' },
            { id: 'videoCalls', label: 'Video Call Persona', desc: 'Allow AI to participate in visual syncs (BETA)' },
            { id: 'escalation', label: 'Critical Silence Alert', desc: 'Escalate if user is unreachable for >24hrs' }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => toggleGuardrail(item.id as any)}
              className={cn(
                "w-full p-5 rounded-2xl border flex items-start gap-4 text-left transition-all",
                config.guardrails[item.id as keyof typeof config.guardrails]
                  ? "bg-rose-500/10 border-rose-500/30 ring-1 ring-rose-500/10"
                  : "bg-white/5 border-white/5 hover:border-white/10"
              )}
            >
              <div className={cn(
                "w-5 h-5 rounded-md border-2 mt-0.5 flex items-center justify-center transition-colors",
                config.guardrails[item.id as keyof typeof config.guardrails] ? "bg-rose-500 border-rose-500" : "border-slate-700"
              )}>
                {config.guardrails[item.id as keyof typeof config.guardrails] && <Zap size={12} className="text-white fill-current" />}
              </div>
              <div>
                <p className="text-sm font-bold text-white">{item.label}</p>
                <p className="text-[10px] text-slate-500 leading-relaxed uppercase tracking-widest mt-0.5">{item.desc}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}