
import React from 'react';
import { Link, usePathname } from '@/lib/navigation';
import { 
  ShieldAlert, 
  LayoutDashboard, 
  Users, 
  Settings2, 
  Activity, 
  BarChart3, 
  Flag, 
  Settings, 
  ArrowLeft,
  UserCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function AdminSidebar() {
  const pathname = usePathname();

  const menuItems = [
    { icon: <LayoutDashboard size={20} />, label: "Overview", href: "/admin" },
    { icon: <Users size={20} />, label: "User Management", href: "/users" },
    { icon: <Settings2 size={20} />, label: "AI Configuration", href: "/ai-settings" },
    { icon: <Activity size={20} />, label: "Activity Logs", href: "/activity" },
    { icon: <BarChart3 size={20} />, label: "Analytics", href: "/analytics" },
    { icon: <Flag size={20} />, label: "Feature Flags", href: "/feature-flags" },
    { icon: <Settings size={20} />, label: "System Settings", href: "/settings" },
  ];

  return (
    <aside className="w-80 bg-[#030712] border-r border-rose-500/10 flex flex-col hidden lg:flex relative">
      <div className="p-8">
        <Link href="/admin" className="flex items-center gap-3 group">
          <div className="w-10 h-10 bg-gradient-to-br from-rose-600 to-orange-600 rounded-xl flex items-center justify-center shadow-lg shadow-rose-600/20 group-hover:rotate-6 transition-transform">
            <ShieldAlert className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-black tracking-tighter">
            Admin <span className="text-rose-500 font-black">Sync</span>
          </span>
        </Link>
      </div>

      <nav className="flex-1 px-4 py-2 space-y-1 overflow-y-auto custom-scrollbar">
        <div className="mb-6 px-4">
          <div className="text-[10px] font-black uppercase tracking-[0.2em] text-rose-500/60 mb-4">Command Center</div>
        </div>

        {menuItems.map((item) => {
          const isActive = pathname === item.href || (item.href !== '/admin' && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center justify-between px-4 py-3.5 rounded-2xl transition-all group",
                isActive 
                  ? "bg-rose-500/10 text-white font-bold border border-rose-500/20" 
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              )}
            >
              <div className="flex items-center gap-3">
                <span className={cn("transition-colors", isActive ? "text-rose-500" : "group-hover:text-rose-500")}>
                  {item.icon}
                </span>
                <span className="text-sm">{item.label}</span>
              </div>
              {isActive && <div className="w-1.5 h-1.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.8)]"></div>}
            </Link>
          );
        })}
      </nav>

      <div className="p-6 mt-auto space-y-4">
        <Link 
          href="/dashboard"
          className="flex items-center gap-3 px-4 py-3 text-xs font-bold text-slate-500 hover:text-white transition-colors group"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          Return to Client View
        </Link>
        <div className="glass-panel p-4 rounded-2xl border-rose-500/10 flex items-center gap-4 bg-rose-500/5">
          <div className="w-10 h-10 rounded-xl overflow-hidden ring-2 ring-rose-500/20 bg-slate-800 flex items-center justify-center">
            <UserCircle className="text-rose-500" size={24} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold truncate">Lee Wakeman</p>
            <p className="text-[10px] text-rose-500 font-black uppercase tracking-widest">Super Admin</p>
          </div>
        </div>
      </div>
    </aside>
  );
}

// Added UserCircle import fix
import { UserCircle as LucideUserCircle } from 'lucide-react';
