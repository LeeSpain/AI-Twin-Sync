import React from 'react';
import { TrendingUp, TrendingDown, LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AdminStatsCardProps {
  label: string;
  value: string | number;
  trend: string;
  icon: LucideIcon;
  color?: 'rose' | 'orange' | 'blue' | 'emerald';
}

export default function AdminStatsCard({ label, value, trend, icon: Icon, color = 'rose' }: AdminStatsCardProps) {
  const isPositive = trend.startsWith('+') || trend.includes('%');
  
  const colorMap = {
    rose: "text-rose-400 bg-rose-400/10 border-rose-500/20",
    orange: "text-orange-400 bg-orange-400/10 border-orange-500/20",
    blue: "text-blue-400 bg-blue-400/10 border-blue-500/20",
    emerald: "text-emerald-400 bg-emerald-400/10 border-emerald-500/20",
  };

  return (
    <div className="glass-panel p-6 rounded-[2rem] border-white/5 hover:border-rose-500/20 transition-all group relative overflow-hidden bg-white/5">
      <div className="flex items-center justify-between mb-4">
        <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center border", colorMap[color])}>
          <Icon size={22} />
        </div>
        <div className={cn(
          "flex items-center gap-1 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
          isPositive ? "bg-emerald-400/10 text-emerald-400" : "bg-rose-400/10 text-rose-400"
        )}>
          {isPositive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
          {trend}
        </div>
      </div>

      <div className="space-y-1">
        <p className="text-xs font-bold text-slate-500 uppercase tracking-[0.2em]">{label}</p>
        <h4 className="text-4xl font-black text-white tracking-tighter">{value}</h4>
      </div>
    </div>
  );
}