
import React from 'react';
import { Bell, Search, Command, ShieldCheck, Zap } from 'lucide-react';
import { usePathname } from '@/lib/navigation';

export default function AdminHeader() {
  const pathname = usePathname();
  
  const getPageTitle = () => {
    const parts = pathname.split('/').filter(Boolean);
    if (parts.length === 0) return 'Overview';
    const last = parts[parts.length - 1];
    return last.charAt(0).toUpperCase() + last.slice(1).replace('-', ' ');
  };

  return (
    <header className="h-20 border-b border-rose-500/10 bg-[#030712]/50 backdrop-blur-xl flex items-center justify-between px-8 sticky top-0 z-40">
      <div className="flex items-center gap-6">
        <div className="hidden md:flex flex-col">
          <div className="flex items-center gap-2 mb-1">
            <ShieldCheck className="w-3 h-3 text-rose-500" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-rose-500/60">Platform Authority</span>
          </div>
          <h2 className="text-lg font-bold text-white tracking-tight">{getPageTitle()}</h2>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="hidden lg:flex items-center gap-6 px-6 py-2 bg-white/5 rounded-2xl border border-white/5">
          <div className="flex flex-col items-center">
             <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">System Load</span>
             <span className="text-xs font-mono text-emerald-400">12%</span>
          </div>
          <div className="w-px h-6 bg-white/10"></div>
          <div className="flex flex-col items-center">
             <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">API Health</span>
             <span className="text-xs font-mono text-rose-400">99.9%</span>
          </div>
        </div>

        <div className="relative hidden xl:block">
          <div className="absolute inset-y-0 left-4 flex items-center text-slate-500">
            <Search size={16} />
          </div>
          <input 
            type="text" 
            placeholder="Search platform audits..." 
            className="bg-white/5 border border-white/5 rounded-2xl py-2.5 pl-11 pr-16 w-80 text-sm focus:outline-none focus:ring-2 focus:ring-rose-500/20 transition-all text-slate-200"
          />
          <div className="absolute right-3 top-2 px-1.5 py-0.5 rounded border border-white/10 bg-white/5 text-[10px] text-slate-500 font-mono flex items-center gap-1">
            <Command size={10} />
            <span>S</span>
          </div>
        </div>

        <button className="relative p-2.5 rounded-xl hover:bg-white/5 transition-all group">
          <Bell className="w-5 h-5 text-slate-400 group-hover:text-rose-500 transition-colors" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-rose-600 border-2 border-[#030712] rounded-full"></span>
        </button>

        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-rose-500 to-orange-600 p-[1px]">
          <div className="w-full h-full rounded-full bg-[#030712] flex items-center justify-center p-0.5 overflow-hidden">
             <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=AdminLee" className="w-full h-full rounded-full" alt="Admin" />
          </div>
        </div>
      </div>
    </header>
  );
}
