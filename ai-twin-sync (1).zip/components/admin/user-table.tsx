
import React from 'react';
import { MoreHorizontal, ShieldCheck, Clock, ExternalLink, UserCog } from 'lucide-react';
import { Link } from '@/lib/navigation';
import { cn } from '@/lib/utils';

const USERS = [
  { id: '1', name: "Martijn van Bree", email: "martijn@example.com", status: "Active", phase: "Shadow Mode (Wk 2)", sync: 98, last: "2m ago" },
  { id: '2', name: "Sarah Jenkins", email: "sarah@design-corp.io", status: "Onboarding", phase: "Baseline mapping", sync: 42, last: "14m ago" },
  { id: '3', name: "Dave Chen", email: "dave@tech-start.com", status: "Active", phase: "Autonomous", sync: 100, last: "1h ago" },
  { id: '4', name: "Elena Rossi", email: "elena@global-logistics.it", status: "Inactive", phase: "Paused", sync: 88, last: "3d ago" },
];

export default function UserTable() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="border-b border-white/5 bg-white/5">
            <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Identity</th>
            <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Status</th>
            <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Neural Phase</th>
            <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Sync Level</th>
            <th className="px-6 py-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Last Pulse</th>
            <th className="px-8 py-5 text-right text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {USERS.map((user) => (
            <tr key={user.id} className="group hover:bg-white/[0.02] transition-colors">
              <td className="px-8 py-6">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 ring-2 ring-white/5 overflow-hidden flex-shrink-0">
                    <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`} alt={user.name} />
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-white truncate">{user.name}</p>
                    <p className="text-xs text-slate-500 truncate">{user.email}</p>
                  </div>
                </div>
              </td>
              <td className="px-6 py-6">
                <span className={cn(
                  "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border",
                  user.status === 'Active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                  user.status === 'Onboarding' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' : 'bg-slate-500/10 text-slate-400 border-slate-500/20'
                )}>
                  {user.status === 'Active' && <ShieldCheck size={10} />}
                  {user.status}
                </span>
              </td>
              <td className="px-6 py-6">
                <span className="text-xs font-medium text-slate-300">{user.phase}</span>
              </td>
              <td className="px-6 py-6">
                <div className="flex items-center gap-3">
                   <div className="flex-1 w-24 h-1.5 bg-white/5 rounded-full overflow-hidden">
                      <div className={cn(
                        "h-full rounded-full transition-all duration-1000",
                        user.sync > 90 ? "bg-emerald-500" : user.sync > 50 ? "bg-blue-500" : "bg-orange-500"
                      )} style={{ width: `${user.sync}%` }}></div>
                   </div>
                   <span className="text-xs font-mono text-slate-400">{user.sync}%</span>
                </div>
              </td>
              <td className="px-6 py-6 text-xs text-slate-500 font-mono">
                <div className="flex items-center gap-2">
                  <Clock size={12} className="opacity-40" />
                  {user.last}
                </div>
              </td>
              <td className="px-8 py-6 text-right">
                <div className="flex items-center justify-end gap-2">
                  <Link 
                    href={`/users/${user.id}`}
                    className="p-2.5 rounded-xl hover:bg-rose-500/10 hover:text-rose-500 text-slate-500 transition-all"
                    title="Edit Controls"
                  >
                    <UserCog size={18} />
                  </Link>
                  <button className="p-2.5 rounded-xl hover:bg-white/10 text-slate-500 transition-all">
                    <MoreHorizontal size={18} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
