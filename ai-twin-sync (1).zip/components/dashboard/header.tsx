
import React from 'react';
import { Bell, Search, Menu, Command } from 'lucide-react';
import { usePathname } from '@/lib/navigation';

export default function Header() {
  const pathname = usePathname();
  
  // Simple breadcrumb logic
  const getPageTitle = () => {
    const part = pathname.split('/').pop() || 'Dashboard';
    return part.charAt(0).toUpperCase() + part.slice(1);
  };

  return (
    <header className="h-20 border-b border-white/5 bg-[#030712]/50 backdrop-blur-xl flex items-center justify-between px-8 sticky top-0 z-40">
      <div className="flex items-center gap-6">
        <Menu className="lg:hidden text-slate-400 hover:text-white cursor-pointer" />
        <div className="hidden md:flex flex-col">
          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500/60 mb-1">Central Intelligence</span>
          <h2 className="text-lg font-bold text-white tracking-tight">{getPageTitle()}</h2>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="relative hidden lg:block">
          <div className="absolute inset-y-0 left-4 flex items-center text-slate-500">
            <Search size={16} />
          </div>
          <input 
            type="text" 
            placeholder="Search Atlas knowledge..." 
            className="bg-white/5 border border-white/5 rounded-2xl py-2.5 pl-11 pr-16 w-80 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-200 placeholder:text-slate-600"
          />
          <div className="absolute right-3 top-2 px-1.5 py-0.5 rounded border border-white/10 bg-white/5 text-[10px] text-slate-500 font-mono flex items-center gap-1">
            <Command size={10} />
            <span>K</span>
          </div>
        </div>

        <button className="relative p-2.5 rounded-xl hover:bg-white/5 transition-all group">
          <Bell className="w-5 h-5 text-slate-400 group-hover:text-blue-400 transition-colors" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-blue-600 border-2 border-[#030712] rounded-full"></span>
        </button>

        <div className="flex items-center gap-3 pl-4 border-l border-white/10 h-10">
          <div className="text-right hidden sm:block">
            <p className="text-xs font-bold text-white">Alex Johnson</p>
            <p className="text-[10px] text-emerald-400 font-mono">Synchronized</p>
          </div>
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 p-[1px]">
            <div className="w-full h-full rounded-full bg-[#030712] flex items-center justify-center p-0.5">
               <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Executive" className="w-full h-full rounded-full" alt="Avatar" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
