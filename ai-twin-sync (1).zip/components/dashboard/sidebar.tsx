
import React from 'react';
import { usePathname, Link } from '@/lib/navigation';
import { 
  Bot, 
  Home, 
  MessageSquare, 
  Mail, 
  Calendar, 
  CheckSquare, 
  Users, 
  Building, 
  Settings, 
  LogOut, 
  Mic,
  ChevronRight
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Sidebar() {
  const pathname = usePathname();

  const menuItems = [
    { icon: <Home size={20} />, label: "Dashboard", href: "/dashboard" },
    { icon: <MessageSquare size={20} />, label: "Talk to Atlas", href: "/chat" },
    { icon: <Mail size={20} />, label: "Neural Inbox", href: "/inbox" },
    { icon: <Calendar size={20} />, label: "Calendar", href: "/calendar" },
    { icon: <CheckSquare size={20} />, label: "Task Board", href: "/tasks" },
    { icon: <Users size={20} />, label: "Intelligence Contacts", href: "/contacts" },
    { icon: <Building size={20} />, label: "Organizations", href: "/companies" },
    { icon: <Settings size={20} />, label: "Sync Settings", href: "/settings" },
  ];

  return (
    <aside className="w-80 bg-[#030712] border-r border-white/5 flex flex-col hidden lg:flex">
      <div className="p-8">
        <Link href="/dashboard" className="flex items-center gap-3 group">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-600/20 group-hover:rotate-6 transition-transform">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-black tracking-tighter text-white">
            AI Twin <span className="gradient-text">Sync</span>
          </span>
        </Link>
      </div>

      <nav className="flex-1 px-4 py-2 space-y-1 overflow-y-auto custom-scrollbar">
        <div className="mb-6">
          <button className="w-full py-4 bg-blue-600/10 border border-blue-500/20 text-blue-400 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-blue-600/20 transition-all shadow-[0_0_20px_rgba(59,130,246,0.1)]">
            <Mic className="w-4 h-4" />
            Vocalize Protocol
          </button>
        </div>

        {menuItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center justify-between px-4 py-3.5 rounded-2xl transition-all group",
                isActive 
                  ? "bg-white/10 text-white font-bold" 
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              )}
            >
              <div className="flex items-center gap-3">
                <span className={cn("transition-colors", isActive ? "text-blue-400" : "group-hover:text-blue-400")}>
                  {item.icon}
                </span>
                <span className="text-sm">{item.label}</span>
              </div>
              {isActive && <div className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)]"></div>}
            </Link>
          );
        })}
      </nav>

      <div className="p-6 mt-auto">
        <div className="glass-panel p-4 rounded-2xl border-white/5 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl overflow-hidden ring-2 ring-blue-500/20">
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Executive" alt="User" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold truncate">Alex Johnson</p>
            <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Alpha License</p>
          </div>
          <button className="text-slate-500 hover:text-red-400 transition-colors">
            <LogOut size={18} />
          </button>
        </div>
      </div>
    </aside>
  );
}
