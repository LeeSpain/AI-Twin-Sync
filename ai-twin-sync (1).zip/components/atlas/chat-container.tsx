import React, { useRef, useEffect } from 'react';
import ChatMessage from './chat-message';
import ChatInput from './chat-input';
import TypingIndicator from './typing-indicator';
import { useAtlas } from '@/hooks/use-atlas';
import { useAtlasStore } from '@/stores/atlas-store';

export default function ChatContainer() {
  const { messages, sendMessage, isLoading } = useAtlas();
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#020617]/40 relative">
      {/* Message Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 md:p-10 space-y-10 custom-scrollbar scroll-smooth"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-40 grayscale hover:grayscale-0 transition-all">
             <div className="w-20 h-20 rounded-3xl bg-blue-600/10 flex items-center justify-center border border-blue-500/20">
               <img src="/logo.svg" alt="Atlas" className="w-10 h-10 animate-pulse" />
             </div>
             <div className="space-y-1">
               <h3 className="text-xl font-bold">Neural Link Ready</h3>
               <p className="text-sm max-w-xs mx-auto">Ask me to summarize your inbox, draft a strategy, or schedule your week.</p>
             </div>
          </div>
        )}

        {messages.map((msg, idx) => (
          <ChatMessage 
            key={msg.id} 
            message={msg} 
            isLast={idx === messages.length - 1} 
          />
        ))}

        {isLoading && <TypingIndicator />}
      </div>

      {/* Input Overlay */}
      <div className="p-6 md:p-8 pt-0">
        <ChatInput onSend={sendMessage} disabled={isLoading} />
      </div>
    </div>
  );
}