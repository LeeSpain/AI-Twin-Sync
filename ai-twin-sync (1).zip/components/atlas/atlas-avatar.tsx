
import React from 'react';
import { Bot, Terminal, Cpu } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface AtlasAvatarProps {
  state?: 'idle' | 'thinking' | 'speaking';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export default function AtlasAvatar({ state = 'idle', size = 'md', className }: AtlasAvatarProps) {
  const sizeMap = {
    sm: 'w-8 h-8 rounded-lg p-1',
    md: 'w-12 h-12 rounded-xl p-2',
    lg: 'w-24 h-24 rounded-3xl p-4'
  };

  const iconSize = {
    sm: 14,
    md: 20,
    lg: 40
  };

  return (
    <div className={cn("relative group", className)}>
      <motion.div 
        animate={state === 'thinking' ? { rotate: [0, 5, -5, 0], scale: [1, 1.05, 1] } : {}}
        transition={{ repeat: Infinity, duration: 2 }}
        className={cn(
          "bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-white shadow-lg transition-all",
          sizeMap[size],
          state === 'thinking' ? 'shadow-blue-500/50' : 'shadow-blue-500/20'
        )}
      >
        <Bot size={iconSize[size]} />
      </motion.div>
      
      {state === 'thinking' && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute -top-1 -right-1"
        >
          <div className="w-3 h-3 bg-blue-500 rounded-full border-2 border-[#030712] animate-ping" />
        </motion.div>
      )}

      {state === 'speaking' && (
        <div className="absolute -bottom-2 -right-2 flex gap-0.5">
           <motion.div animate={{ height: [4, 12, 4] }} transition={{ repeat: Infinity, duration: 0.5 }} className="w-1 bg-white rounded-full" />
           <motion.div animate={{ height: [8, 16, 8] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.1 }} className="w-1 bg-white rounded-full" />
           <motion.div animate={{ height: [4, 12, 4] }} transition={{ repeat: Infinity, duration: 0.5, delay: 0.2 }} className="w-1 bg-white rounded-full" />
        </div>
      )}
    </div>
  );
}
