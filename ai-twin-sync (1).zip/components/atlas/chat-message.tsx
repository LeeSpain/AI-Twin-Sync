
import React from 'react';
import { AtlasMessage } from '@/types/atlas';
import { Terminal, User, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ChatMessageProps {
  message: AtlasMessage;
  isLast?: boolean;
  // Fix: Explicitly allow key for mapping in ChatContainer to satisfy strict TS check
  key?: React.Key;
}

export default function ChatMessage({ message, isLast }: ChatMessageProps) {
  const isAtlas = message.role === 'assistant';
  const timestamp = new Date(message.timestamp).toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  return (
    <div className={cn(
      "flex flex-col gap-2 max-w-[85%] md:max-w-[75%] animate-in fade-in slide-in-from-bottom-2 duration-300",
      isAtlas ? "self-start" : "self-end items-end"
    )}>
      <div className={cn(
        "flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-500",
        isAtlas ? "flex-row" : "flex-row-reverse"
      )}>
        {isAtlas ? (
          <div className="flex items-center gap-1.5 text-blue-400">
            <Terminal size={10} />
            Atlas Intelligence
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-slate-400">
            You (Executive)
            <User size={10} />
          </div>
        )}
        <div className="w-1 h-1 rounded-full bg-slate-800"></div>
        <div className="flex items-center gap-1 text-[9px] font-mono">
          <Clock size={8} />
          {timestamp}
        </div>
      </div>

      <div className={cn(
        "relative p-5 rounded-[2rem] text-sm md:text-base leading-relaxed transition-all shadow-sm",
        isAtlas 
          ? "bg-white/5 border border-white/10 text-slate-100 rounded-tl-none" 
          : "bg-blue-600 text-white rounded-tr-none shadow-xl shadow-blue-600/10"
      )}>
        {message.content || (
          <div className="flex gap-1 py-1">
            <div className="w-1 h-1 bg-white/40 rounded-full animate-bounce"></div>
            <div className="w-1 h-1 bg-white/40 rounded-full animate-bounce delay-100"></div>
            <div className="w-1 h-1 bg-white/40 rounded-full animate-bounce delay-200"></div>
          </div>
        )}
      </div>
    </div>
  );
}
