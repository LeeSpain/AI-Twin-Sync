
import React from 'react';
import { Quote } from 'lucide-react';

interface TestimonialCardProps {
  quote: string;
  name: string;
  role: string;
  company: string;
  avatar: string;
  // Fix: Allow extra props from spread in MarketingPage to satisfy strict TS check
  id?: string;
  key?: React.Key;
}

export default function TestimonialCard({ quote, name, role, company, avatar }: TestimonialCardProps) {
  return (
    <div className="glass p-8 rounded-[2rem] border-white/5 relative group">
      <Quote className="absolute top-8 right-8 text-blue-500/10 w-12 h-12 group-hover:text-blue-500/20 transition-colors" />
      
      <p className="text-lg text-slate-200 leading-relaxed italic mb-8 relative z-10">
        "{quote}"
      </p>
      
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl overflow-hidden ring-2 ring-blue-500/20">
          <img src={avatar} alt={name} className="w-full h-full object-cover" />
        </div>
        <div>
          <h4 className="font-bold text-white">{name}</h4>
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">
            {role} • {company}
          </p>
        </div>
      </div>
    </div>
  );
}
