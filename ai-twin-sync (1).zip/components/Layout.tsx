
import React from 'react';
import { ViewState } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeView: ViewState;
  onNavigate: (view: ViewState) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeView, onNavigate }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <nav className="glass sticky top-0 z-50 px-6 py-4 flex items-center justify-between border-b border-white/10">
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={() => onNavigate('dashboard')}
        >
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center group-hover:rotate-12 transition-transform">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <span className="text-xl font-bold tracking-tight">AI Twin <span className="gradient-text">Sync</span></span>
        </div>

        <div className="flex items-center gap-6">
          <button 
            onClick={() => onNavigate('dashboard')}
            className={`text-sm font-medium transition-colors ${activeView === 'dashboard' ? 'text-blue-400' : 'text-gray-400 hover:text-white'}`}
          >
            Dashboard
          </button>
          <button 
             onClick={() => onNavigate('sync')}
            className={`text-sm font-medium transition-colors ${activeView === 'sync' ? 'text-blue-400' : 'text-gray-400 hover:text-white'}`}
          >
            New Sync
          </button>
          <div className="w-8 h-8 rounded-full bg-gray-800 border border-white/10 flex items-center justify-center overflow-hidden">
            <img src="https://picsum.photos/seed/user/32/32" alt="User" />
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-7xl mx-auto w-full p-6">
        {children}
      </main>

      <footer className="p-6 text-center text-gray-500 text-xs border-t border-white/5">
        &copy; 2024 AI Twin Sync • Powered by Google Gemini 3
      </footer>
    </div>
  );
};

export default Layout;
