
import React from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  label?: string;
  center?: boolean;
}

export default function LoadingSpinner({ 
  size = 'md', 
  className, 
  label, 
  center = false 
}: LoadingSpinnerProps) {
  const sizeMap = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-10 h-10',
    xl: 'w-16 h-16'
  };

  const content = (
    <div className={cn("flex flex-col items-center justify-center gap-3", className)}>
      <Loader2 className={cn("animate-spin text-blue-500", sizeMap[size])} />
      {label && (
        <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 animate-pulse">
          {label}
        </p>
      )}
    </div>
  );

  if (center) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-[200px]">
        {content}
      </div>
    );
  }

  return content;
}
