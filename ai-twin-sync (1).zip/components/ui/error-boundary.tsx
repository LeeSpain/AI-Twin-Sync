import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RotateCcw, Home } from 'lucide-react';
import { Link } from '@/lib/navigation';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

/**
 * AI Twin Sync - Error Boundary
 * 
 * Provides graceful fallback for neural sync failures and runtime exceptions.
 * Uses shimmed Link to prevent connection errors.
 */
// Fix: Explicitly extend Component from 'react' to ensure this.setState and this.props are recognized by the TypeScript compiler
export default class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  // Use arrow function to ensure 'this' refers to the class instance
  private handleReset = () => {
    // Fix: Access setState from the inherited Component class
    this.setState({ hasError: false });
  };

  public render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="min-h-[400px] flex items-center justify-center p-8 text-center">
          <div className="max-w-md space-y-6">
            <div className="w-20 h-20 bg-rose-500/10 rounded-[2rem] flex items-center justify-center text-rose-500 mx-auto">
              <AlertCircle size={40} />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-black text-white">Neural Desync Detected</h2>
              <p className="text-slate-400">
                A non-critical fault occurred in the render process. Atlas is attempting to stabilize.
              </p>
            </div>
            <div className="flex gap-4">
              <button 
                onClick={this.handleReset}
                className="flex-1 py-4 bg-white/5 hover:bg-white/10 text-white rounded-2xl font-bold flex items-center justify-center gap-2 transition-all"
              >
                <RotateCcw size={18} />
                Try Again
              </button>
              <Link 
                href="/dashboard"
                className="flex-1 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold flex items-center justify-center gap-2 transition-all"
              >
                <Home size={18} />
                Dashboard
              </Link>
            </div>
          </div>
        </div>
      );
    }

    // Fix: Access props from the inherited Component class
    return this.props.children;
  }
}
