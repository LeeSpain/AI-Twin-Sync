# ⚙️ AI Twin Sync Admin Guide

## Management Portal
Access the portal at `/admin`. Only users with the `admin` role can engage.

## Common Tasks
- **AI Calibration**: Update temperature and max tokens.
- **Feature Flags**: Toggle experimental vocal features.
- **Monitoring**: Check the Cluster Vitality graphs for latency spikes.
