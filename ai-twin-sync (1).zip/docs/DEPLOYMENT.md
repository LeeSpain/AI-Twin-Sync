# 🚀 Deploying AI Twin Sync

Follow these steps to deploy a production instance of the platform.

## Prerequisites
1. **Supabase**: Create a project and run `supabase/migrations/`.
2. **Google AI Studio**: Obtain an `API_KEY`.
3. **Vercel**: Install Vercel CLI.

## Step-by-Step
1. **Clone**: `git clone git@github.com:yourorg/aitwinsync.git`
2. **Config**: Update `.env.local` with your keys.
3. **DB**: Run `./scripts/db-migrate.sh`.
4. **Deploy**: Run `./scripts/deploy.sh`.

## Security Notes
- Ensure `SUPABASE_SERVICE_ROLE_KEY` is kept secret.
- Rotate Gemini API keys every 90 days.
