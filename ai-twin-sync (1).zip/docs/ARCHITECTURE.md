# 🏗️ AI Twin Sync Architecture

## Intelligence Layer
- **Commander Agent**: Triage and routing engine.
- **Specialized Agents**: Domain-specific logic (Email, Calendar).
- **Gemini 3 Pro**: Primary reasoning engine.

## Infrastructure
- **Next.js 15**: Edge-ready SSR and API routes.
- **Supabase**: Real-time DB, Auth, and Storage.
- **Sonner**: Toast notification orchestration.

## Action Pipeline
- Intent -> Analysis -> Draft -> Approval -> Execution -> Audit
