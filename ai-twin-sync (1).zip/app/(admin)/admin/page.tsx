
import React from 'react';
import AdminStatsCard from '@/components/admin/stats-card';
import { 
  Users, 
  Activity, 
  Zap, 
  ShieldAlert, 
  Server, 
  AlertCircle,
  ArrowUpRight,
  RefreshCw,
  Plus
} from 'lucide-react';
// Added missing import for 'cn' utility from @/lib/utils
import { cn } from '@/lib/utils';

export default function AdminDashboardPage() {
  return (
    <div className="space-y-10">
      {/* Header section */}
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black tracking-tight text-white mb-2">
            Systems <span className="text-rose-500">Overview</span>
          </h1>
          <p className="text-slate-400 text-lg">Central control for AI Twin Sync Platform. Monitoring 428 instances.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-5 py-2.5 glass border-rose-500/10 hover:bg-rose-500/5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 text-rose-500">
            <RefreshCw className="w-4 h-4" />
            Re-sync Nodes
          </button>
          <button className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-sm font-bold shadow-lg shadow-rose-600/20 flex items-center gap-2 transition-all">
            <Plus className="w-4 h-4" />
            Provision Instance
          </button>
        </div>
      </section>

      {/* Grid of Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <AdminStatsCard label="Total Identities" value="1,284" trend="+24" icon={Users} color="blue" />
        <AdminStatsCard label="Sync Active" value="412" trend="+12%" icon={Activity} color="emerald" />
        <AdminStatsCard label="Neural Tasks" value="8,492" trend="+1.2k" icon={Zap} color="orange" />
        <AdminStatsCard label="System Alerts" value="2" trend="-40%" icon={ShieldAlert} color="rose" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* System Health */}
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-panel rounded-3xl p-8 border-rose-500/10 bg-rose-500/5">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-bold flex items-center gap-3">
                <Server className="text-rose-500" />
                Cluster Vitality
              </h2>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">All Clusters Operational</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Compute Availability</span>
                    <span className="text-sm font-mono text-white">88%</span>
                  </div>
                  <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 w-[88%]"></div>
                  </div>
               </div>
               <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Neural Latency (Avg)</span>
                    <span className="text-sm font-mono text-white">124ms</span>
                  </div>
                  <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-rose-500 w-[14%]"></div>
                  </div>
               </div>
               <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Storage Utilization</span>
                    <span className="text-sm font-mono text-white">42.8 TB</span>
                  </div>
                  <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-orange-500 w-[65%]"></div>
                  </div>
               </div>
               <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Security Link Integrity</span>
                    <span className="text-sm font-mono text-white">99.99%</span>
                  </div>
                  <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 w-[99.99%]"></div>
                  </div>
               </div>
            </div>
          </div>

          <div className="glass-panel rounded-3xl p-8 border-white/5">
             <h2 className="text-xl font-bold mb-8">Recent Global Activity</h2>
             <div className="space-y-6">
                {[
                  { user: "Martijn van Bree", action: "Completed onboarding sync", time: "2m ago", status: "success" },
                  { user: "Sarah Jenkins", action: "Connected Slack integration", time: "14m ago", status: "success" },
                  { user: "System", action: "Automatic model rotation performed", time: "1h ago", status: "system" },
                  { user: "Unknown Identity", action: "Failed login attempt detected", time: "2h ago", status: "alert" }
                ].map((log, i) => (
                  <div key={i} className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5">
                    <div className="flex items-center gap-4">
                      {/* Fixed: Using the imported 'cn' utility to manage conditional classes */}
                      <div className={cn(
                        "w-2 h-2 rounded-full",
                        log.status === 'success' ? 'bg-emerald-500' : 
                        log.status === 'alert' ? 'bg-rose-500 animate-pulse' : 'bg-blue-500'
                      )}></div>
                      <div>
                        <p className="text-sm font-bold text-white">{log.user}</p>
                        <p className="text-xs text-slate-500">{log.action}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-slate-600 uppercase tracking-widest">{log.time}</span>
                  </div>
                ))}
             </div>
          </div>
        </div>

        {/* Right Sidebar: Quick Admin Actions */}
        <div className="space-y-8">
           <div className="glass-panel rounded-3xl p-8 border-rose-500/10 bg-gradient-to-br from-rose-500/10 to-transparent">
              <h3 className="text-lg font-bold mb-6">Commander Actions</h3>
              <div className="space-y-3">
                 {[
                   { label: "Invite Client", icon: <Users size={16} /> },
                   { label: "AI Model Config", icon: <Zap size={16} /> },
                   { label: "Emergency Lock", icon: <AlertCircle size={16} />, danger: true },
                   { label: "Full Export", icon: <ArrowUpRight size={16} /> }
                 ].map((btn, i) => (
                   <button 
                    key={i} 
                    className={cn(
                      "w-full p-4 rounded-2xl flex items-center justify-between transition-all font-bold text-sm",
                      btn.danger 
                        ? "bg-rose-600/10 text-rose-500 border border-rose-600/20 hover:bg-rose-600 hover:text-white" 
                        : "bg-white/5 text-slate-300 border border-white/5 hover:bg-white/10"
                    )}
                   >
                     <span className="flex items-center gap-3">{btn.icon}{btn.label}</span>
                     <ArrowUpRight size={14} className="opacity-40" />
                   </button>
                 ))}
              </div>
           </div>

           <div className="glass-panel rounded-3xl p-8 border-white/5">
              <h3 className="text-lg font-bold mb-6">Resource Allocation</h3>
              <div className="space-y-6">
                 <div>
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3">
                       <span>Gemini API Credits</span>
                       <span>82% Remaining</span>
                    </div>
                    <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                       <div className="h-full bg-blue-500 w-[82%]"></div>
                    </div>
                 </div>
                 <div>
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3">
                       <span>Supabase Realtime</span>
                       <span>4.2k Connected</span>
                    </div>
                    <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                       <div className="h-full bg-purple-500 w-[45%]"></div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
