import React from 'react';
import UserTable from '@/components/admin/user-table';
import { Plus, Search, Filter, Download } from 'lucide-react';

export default function AdminUsersPage() {
  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-white mb-1">Users & <span className="text-rose-500">Identities</span></h1>
          <p className="text-slate-400">Manage all high-performance executive instances.</p>
        </div>
        <button className="px-6 py-3 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-rose-600/20 flex items-center gap-2">
          <Plus size={18} />
          Invite Executive
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1 group">
          <div className="absolute inset-y-0 left-4 flex items-center text-slate-500 group-focus-within:text-rose-500 transition-colors">
            <Search size={18} />
          </div>
          <input 
            type="text" 
            placeholder="Search by name, email, or company..." 
            className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-12 pr-6 text-sm focus:outline-none focus:ring-2 focus:ring-rose-500/30 transition-all"
          />
        </div>
        <button className="px-6 py-4 glass border-white/5 rounded-2xl text-sm font-bold flex items-center gap-2 text-slate-300 hover:bg-white/5">
          <Filter size={18} />
          Filters
        </button>
        <button className="px-6 py-4 glass border-white/5 rounded-2xl text-sm font-bold flex items-center gap-2 text-slate-300 hover:bg-white/5">
          <Download size={18} />
          Export
        </button>
      </div>

      <div className="glass-panel rounded-[2.5rem] border-white/5 overflow-hidden">
        <UserTable />
      </div>
    </div>
  );
}