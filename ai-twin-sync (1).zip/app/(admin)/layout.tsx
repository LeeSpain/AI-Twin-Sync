import React from 'react';
import AdminSidebar from '@/components/admin/admin-sidebar';
import AdminHeader from '@/components/admin/admin-header';

// AI Twin Sync - Admin Layout
// Fixed: children is now optional to prevent 'missing in type {}' errors in root router
export default function AdminLayout({
  children,
}: {
  children?: React.ReactNode;
}) {
  return (
    <div className="flex h-screen bg-[#020617] text-white overflow-hidden font-sans selection:bg-rose-500/30">
      <AdminSidebar />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <AdminHeader />
        <main className="flex-1 overflow-y-auto bg-gradient-to-b from-transparent to-rose-950/10 p-4 md:p-8 scroll-smooth custom-scrollbar">
          <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
