
'use client';

import React, { useState } from 'react';
import { getGreeting } from '@/lib/utils/greeting';
import StatsCard from '@/components/dashboard/stats-card';
import GithubSyncModal from '@/components/dashboard/github-sync-modal';
import NeuralTerminal from '@/components/dashboard/neural-terminal';
import { 
  Mail, 
  Calendar, 
  CheckSquare, 
  Zap, 
  ArrowRight, 
  Plus, 
  Clock,
  ShieldCheck,
  Github
} from 'lucide-react';
import { Link } from '@/lib/navigation';

export default function DashboardPage() {
  const [isGithubModalOpen, setIsGithubModalOpen] = useState(false);
  const userName = "Executive"; 

  const dashboardStats = {
    emailsHandled: "42",
    meetingsScheduled: "8",
    tasksPending: "15",
    aiActions: "128"
  };
  
  return (
    <div className="space-y-10 relative">
      {/* Welcome Header */}
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black tracking-tight text-white mb-2">
            {getGreeting()}, <span className="gradient-text">{userName}</span>
          </h1>
          <p className="text-slate-400 text-lg">Atlas is currently monitoring 12 neural streams for your attention.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setIsGithubModalOpen(true)}
            className="px-5 py-2.5 glass border-white/5 hover:bg-white/5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 group"
          >
            <Github className="w-4 h-4 text-white group-hover:scale-110 transition-transform" />
            GitHub Sync
          </button>
          <Link 
            href="/chat"
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-bold shadow-lg shadow-blue-600/20 flex items-center gap-2 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4" />
            Ask Atlas
          </Link>
        </div>
      </section>

      {/* Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard 
          label="Emails Handled" 
          value={dashboardStats.emailsHandled} 
          trend="+12%" 
          icon={<Mail className="w-5 h-5" />} 
          color="blue"
        />
        <StatsCard 
          label="Meetings Set" 
          value={dashboardStats.meetingsScheduled} 
          trend="+4" 
          icon={<Calendar className="w-5 h-5" />} 
          color="purple"
        />
        <StatsCard 
          label="Tasks Pending" 
          value={dashboardStats.tasksPending} 
          trend="-2" 
          icon={<CheckSquare className="w-5 h-5" />} 
          color="emerald"
        />
        <StatsCard 
          label="AI Sync Steps" 
          value={dashboardStats.aiActions} 
          trend="99.9%" 
          icon={<Zap className="w-5 h-5" />} 
          color="amber"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Approvals & Activity */}
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-panel rounded-3xl p-6 border-white/5">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                Pending Approvals
              </h2>
              <span className="text-xs font-mono text-emerald-400/60 uppercase tracking-widest font-black">3 Items Awaiting</span>
            </div>
            
            <div className="space-y-4">
              {[
                { title: "Draft: Response to Q4 Strategy", type: "Email", priority: "High" },
                { title: "Schedule: Weekly Board Sync", type: "Calendar", priority: "Medium" },
                { title: "Delegate: Invoice #809 Processing", type: "Task", priority: "Low" }
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 group hover:border-white/10 transition-all">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      item.type === 'Email' ? 'bg-blue-500/10 text-blue-400' : 
                      item.type === 'Calendar' ? 'bg-purple-500/10 text-purple-400' : 'bg-emerald-500/10 text-emerald-400'
                    }`}>
                      {item.type === 'Email' ? <Mail className="w-5 h-5" /> : item.type === 'Calendar' ? <Calendar className="w-5 h-5" /> : <CheckSquare className="w-5 h-5" />}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-200">{item.title}</h4>
                      <p className="text-xs text-slate-500 uppercase tracking-wider font-black">{item.type} • {item.priority} Urgency</p>
                    </div>
                  </div>
                  <button className="p-2 rounded-lg bg-white/5 opacity-0 group-hover:opacity-100 transition-all hover:bg-blue-600 hover:text-white">
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-panel rounded-3xl p-6 border-white/5">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-400" />
              Recent Neural Activity
            </h2>
            <div className="space-y-6">
              {[
                { time: "10m ago", action: "Summarized 14 unread Slack messages from #strategy" },
                { time: "1h ago", action: "Rescheduled 'Coffee with Jane' due to conflict" },
                { time: "3h ago", action: "Completed daily briefing compilation" }
              ].map((activity, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                    {i < 2 && <div className="w-px flex-1 bg-white/10 my-1"></div>}
                  </div>
                  <div className="pb-6">
                    <p className="text-sm text-slate-200">{activity.action}</p>
                    <span className="text-[10px] text-slate-500 font-mono uppercase tracking-widest">{activity.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Quick Actions & Upcoming */}
        <div className="space-y-8">
          <div className="glass-panel rounded-3xl p-6 border-white/5 bg-gradient-to-br from-blue-600/10 to-transparent">
            <h2 className="text-xl font-bold mb-6">Quick Actions</h2>
            <div className="grid grid-cols-2 gap-3">
              {[
                { icon: <Mail />, label: "Email" },
                { icon: <Calendar />, label: "Meeting" },
                { icon: <CheckSquare />, label: "Task" },
                { icon: <Github />, label: "GitHub Sync" }
              ].map((btn, i) => (
                <button 
                  key={i} 
                  onClick={() => btn.label === 'GitHub Sync' ? setIsGithubModalOpen(true) : null}
                  className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 hover:border-white/20 transition-all space-y-2 group"
                >
                  <div className="text-slate-400 group-hover:text-blue-400 transition-colors">
                    {React.cloneElement(btn.icon as React.ReactElement<{ size?: number }>, { size: 20 })}
                  </div>
                  <span className="text-xs font-bold text-slate-400">{btn.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="glass-panel rounded-3xl p-6 border-white/5">
            <h2 className="text-xl font-bold mb-6">Upcoming Syncs</h2>
            <div className="space-y-4">
              {[
                { time: "11:00 AM", title: "Product Sync", host: "Sarah L." },
                { time: "02:30 PM", title: "Investor Call", host: "Zen Capital" },
                { time: "04:00 PM", title: "Internal Retro", host: "Dev Team" }
              ].map((ev, i) => (
                <div key={i} className="p-4 bg-white/5 rounded-2xl border-l-4 border-blue-500">
                  <div className="flex justify-between items-start mb-1">
                    <span className="text-xs font-mono text-blue-400 font-black">{ev.time}</span>
                  </div>
                  <h4 className="font-bold text-white">{ev.title}</h4>
                  <p className="text-xs text-slate-500">With {ev.host}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <GithubSyncModal 
        isOpen={isGithubModalOpen} 
        onClose={() => setIsGithubModalOpen(false)} 
        stats={dashboardStats}
      />

      {/* Manual Override Terminal */}
      <NeuralTerminal />
    </div>
  );
}
