
import React from 'react';
import { Link } from '@/lib/navigation';
import { MessageSquare, Mic, Shield, Sparkles } from 'lucide-react';

export default function OnboardingPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-8 duration-1000">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-black uppercase tracking-[0.2em]">
          <Shield className="w-3 h-3" />
          Neural Link Protocol v4.0
        </div>
        <h1 className="text-5xl md:text-7xl font-black tracking-tighter text-white">
          Initialize <span className="gradient-text">Sync</span>
        </h1>
        <p className="text-xl text-slate-400 max-w-2xl mx-auto font-light leading-relaxed">
          To begin synchronization, Atlas needs to baseline your identity. 
          Choose your preferred neural interface to continue.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
        <Link 
          href="/onboarding/text"
          className="glass-panel p-10 rounded-[2.5rem] group hover:border-blue-500/50 hover:bg-blue-600/5 transition-all text-left space-y-6"
        >
          <div className="w-16 h-16 rounded-2xl bg-blue-600/10 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
            <MessageSquare className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-bold text-white">Linguistic Sync</h3>
            <p className="text-slate-400 leading-relaxed">
              Baseline via text interface. Ideal for precision data entry and structured responses.
            </p>
          </div>
          <div className="pt-4 flex items-center gap-2 text-xs font-black uppercase tracking-widest text-blue-400 opacity-0 group-hover:opacity-100 transition-all">
            Engage Text Link
            <Sparkles size={12} className="animate-pulse" />
          </div>
        </Link>

        <Link 
          href="/onboarding/voice"
          className="glass-panel p-10 rounded-[2.5rem] group hover:border-purple-500/50 hover:bg-purple-600/5 transition-all text-left space-y-6"
        >
          <div className="w-16 h-16 rounded-2xl bg-purple-600/10 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
            <Mic className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-bold text-white">Vocal Sync</h3>
            <p className="text-slate-400 leading-relaxed">
              Baseline via voice commands. More natural conversational flow. Atlas will listen and learn.
            </p>
          </div>
          <div className="pt-4 flex items-center gap-2 text-xs font-black uppercase tracking-widest text-purple-400 opacity-0 group-hover:opacity-100 transition-all">
            Engage Vocal Link
            <Sparkles size={12} className="animate-pulse" />
          </div>
        </Link>
      </div>
    </div>
  );
}
