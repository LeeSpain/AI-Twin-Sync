
import React from 'react';
import { Link } from '@/lib/navigation';
import { Bot, LogOut } from 'lucide-react';
import OnboardingProgress from '@/components/onboarding/onboarding-progress';

// AI Twin Sync - Onboarding Layout
export default function OnboardingLayout({
  children,
}: {
  children?: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-[#030712] flex flex-col font-sans">
      {/* Header */}
      <header className="h-20 border-b border-white/5 flex items-center justify-between px-8 bg-[#030712]/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-600/20">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-black tracking-tighter">
            AI Twin <span className="gradient-text">Sync</span>
          </span>
        </div>

        <OnboardingProgress />

        <Link 
          href="/login" 
          className="text-xs font-black uppercase tracking-widest text-slate-500 hover:text-white transition-colors flex items-center gap-2"
        >
          <LogOut size={14} />
          Exit
        </Link>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 relative overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-600/5 blur-[150px] rounded-full -z-10 animate-pulse"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-purple-600/5 blur-[150px] rounded-full -z-10 animate-pulse delay-700"></div>

        <div className="w-full max-w-5xl">
          {children}
        </div>
      </main>
    </div>
  );
}
