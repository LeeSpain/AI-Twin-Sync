import React from 'react';
import OnboardingStep from '@/components/onboarding/onboarding-step';
import AboutYouStep from '@/components/onboarding/about-you-step';
import CompaniesStep from '@/components/onboarding/companies-step';
import IntegrationsStep from '@/components/onboarding/integrations-step';
import PreferencesStep from '@/components/onboarding/preferences-step';
import FamilyStep from '@/components/onboarding/family-step';
import AutonomyStep from '@/components/onboarding/autonomy-step';
import VoiceSetupStep from '@/components/onboarding/voice-setup-step';
import CompleteStep from '@/components/onboarding/complete-step';
import { useOnboarding } from '@/hooks/use-onboarding';

export default function TextOnboarding() {
  const { currentStep } = useOnboarding();

  const renderStep = () => {
    switch (currentStep) {
      case 0: return <AboutYouStep />;
      case 1: return <CompaniesStep />;
      case 2: return <IntegrationsStep />;
      case 3: return <PreferencesStep />;
      case 4: return <FamilyStep />;
      case 5: return <AutonomyStep />;
      case 6: return <VoiceSetupStep />;
      case 7: return <CompleteStep />;
      default: return <AboutYouStep />;
    }
  };

  return (
    <div className="py-12">
      <OnboardingStep>
        {renderStep()}
      </OnboardingStep>
    </div>
  );
}