import React from 'react';
import VoiceInterface from '@/components/onboarding/voice-interface';

export default function VoiceOnboarding() {
  return (
    <div className="h-[calc(100vh-160px)] flex flex-col items-center justify-center p-6">
      <VoiceInterface />
    </div>
  );
}