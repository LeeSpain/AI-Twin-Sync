
'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { 
  Bot, ArrowRight, Zap, Shield, Sparkles, 
  Cpu, Check, Play, Globe, ChevronRight 
} from 'lucide-react';
import { Link } from '@/lib/navigation';
import MarketingHeader from '@/components/marketing/marketing-header';
import FeatureCard from '@/components/marketing/feature-card';
import TestimonialCard from '@/components/marketing/testimonial-card';
import FAQItem from '@/components/marketing/faq-item';
import { MARKETING_FEATURES } from '@/lib/marketing/features';
import { TESTIMONIALS } from '@/lib/marketing/testimonials';
import { FAQS } from '@/lib/marketing/faqs';

interface MarketingPageProps {
  onGetStarted?: () => void;
}

export default function MarketingPage({ onGetStarted }: MarketingPageProps) {
  return (
    <div className="min-h-screen bg-[#030712] selection:bg-blue-500/30">
      <MarketingHeader onGetStarted={onGetStarted} />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-6 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/10 blur-[150px] rounded-full -z-10 animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/10 blur-[150px] rounded-full -z-10 animate-pulse delay-700"></div>

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-black uppercase tracking-[0.2em]">
              <Cpu className="w-3.5 h-3.5" />
              Neural Link Protocol v4.2 Active
            </div>
            
            <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.9] text-white">
              Your AI <br />
              <span className="gradient-text">Chief of Staff</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-slate-400 font-light leading-relaxed max-w-xl">
              Atlas manages your emails, calendar, calls, and tasks—so you can focus on high-leverage decisions.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button 
                onClick={onGetStarted}
                className="px-8 py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-[2rem] font-black uppercase tracking-[0.2em] shadow-2xl shadow-blue-600/30 transition-all flex items-center justify-center gap-3 group text-sm"
              >
                Initialize Atlas
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="px-8 py-5 glass hover:bg-white/5 border border-white/10 text-white rounded-[2rem] font-bold transition-all flex items-center justify-center gap-3 text-sm">
                <Play size={18} className="fill-current" />
                Watch Neural Demo
              </button>
            </div>

            <div className="flex items-center gap-8 pt-8 opacity-50 grayscale hover:grayscale-0 transition-all duration-700">
              <div className="flex flex-col items-center gap-1">
                <span className="text-xs font-black uppercase tracking-widest text-slate-500">Enterprise Grade</span>
                <Shield size={20} className="text-white" />
              </div>
              <div className="w-px h-10 bg-white/10"></div>
              <div className="flex flex-col items-center gap-1">
                <span className="text-xs font-black uppercase tracking-widest text-slate-500">GDPR Compliant</span>
                <Globe size={20} className="text-white" />
              </div>
              <div className="w-px h-10 bg-white/10"></div>
              <div className="flex flex-col items-center gap-1">
                <span className="text-xs font-black uppercase tracking-widest text-slate-500">24/7 Monitoring</span>
                <Zap size={20} className="text-white" />
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-blue-600/20 blur-[100px] rounded-full animate-pulse"></div>
            <div className="glass p-4 rounded-[3rem] border-white/10 shadow-2xl relative z-10">
              <img 
                src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=1000" 
                alt="Dashboard Preview" 
                className="rounded-[2.5rem] w-full h-auto shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 glass p-6 rounded-[2rem] border-blue-500/20 shadow-xl animate-bounce duration-[4s]">
                <div className="flex items-center gap-3 mb-2">
                   <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                     <Check size={16} strokeWidth={3} />
                   </div>
                   <span className="text-xs font-black uppercase tracking-widest text-white">Task Resolved</span>
                </div>
                <p className="text-xs text-slate-400 font-medium italic">"Atlas rescheduled the Q4 Sync."</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Feature Grid */}
      <section id="features" className="py-24 px-6 bg-[#020617]">
        <div className="max-w-7xl mx-auto space-y-20">
          <div className="text-center space-y-4">
            <h2 className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-500">Platform Capabilities</h2>
            <h3 className="text-4xl md:text-6xl font-black text-white tracking-tighter">Everything Atlas Can <span className="gradient-text">Execute</span></h3>
            <p className="text-slate-400 max-w-2xl mx-auto text-lg">From routine gatekeeping to complex logistics, Atlas is your digital twin on the front line.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {MARKETING_FEATURES.map((feature) => (
              <FeatureCard key={feature.id} {...feature} />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-32 px-6 relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row gap-20 items-center">
            <div className="lg:w-1/2 space-y-12">
               <div className="space-y-4">
                  <h2 className="text-[10px] font-black uppercase tracking-[0.4em] text-purple-500">Operational Timeline</h2>
                  <h3 className="text-4xl md:text-6xl font-black text-white tracking-tighter">Zero-Touch <br />Initialization</h3>
               </div>
               
               <div className="space-y-12">
                  {[
                    { step: '01', title: 'Neural Baseline', desc: 'Connect your tools. Answer a few core philosophy questions. Atlas maps your mental models in 10 minutes.' },
                    { step: '02', title: 'Shadow Sync', desc: 'For 4 weeks, Atlas watches your communication flow. It learns your tone, your VIPs, and your decision logic.' },
                    { step: '03', title: 'Absolute Agency', desc: 'You reclaim your time. Atlas handles the noise, drafts the strategy, and only alerts you when it matters.' }
                  ].map((item, i) => (
                    <div key={i} className="flex gap-8 group">
                      <div className="text-4xl font-black text-white/10 group-hover:text-blue-500 transition-colors duration-500">{item.step}</div>
                      <div className="space-y-2">
                         <h4 className="text-xl font-bold text-white">{item.title}</h4>
                         <p className="text-slate-400 leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  ))}
               </div>
            </div>

            <div className="lg:w-1/2">
              <div className="glass-panel p-12 rounded-[3rem] border-white/5 bg-gradient-to-br from-blue-600/5 to-transparent relative">
                <div className="absolute top-0 right-0 p-8">
                   <Sparkles className="text-blue-500 w-10 h-10 animate-pulse" />
                </div>
                <div className="space-y-8">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white">
                        <Bot size={24} />
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Atlas Command</p>
                        <p className="text-sm font-bold text-white">Learning your voice...</p>
                      </div>
                   </div>
                   <div className="space-y-4">
                      <div className="p-5 bg-white/5 rounded-2xl border border-white/10 text-sm text-slate-300 italic">
                        "Drafting response to Board Meeting request. Mapping tone to: Professional but concise."
                      </div>
                      <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          whileInView={{ width: '75%' }}
                          transition={{ duration: 2, repeat: Infinity }}
                          className="h-full bg-blue-500"
                        />
                      </div>
                   </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-32 px-6 bg-[#020617]">
        <div className="max-w-4xl mx-auto space-y-16">
          <div className="text-center space-y-4">
            <h2 className="text-[10px] font-black uppercase tracking-[0.4em] text-emerald-500">Executive Investment</h2>
            <h3 className="text-4xl md:text-6xl font-black text-white tracking-tighter">Your Time, <span className="gradient-text">Recovered</span></h3>
          </div>

          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="glass-panel p-12 md:p-16 rounded-[3rem] border-blue-500/20 bg-gradient-to-br from-blue-600/10 to-purple-600/10 shadow-2xl relative"
          >
            <div className="absolute -top-6 left-1/2 -translate-x-1/2 px-6 py-2 bg-blue-600 text-white text-xs font-black uppercase tracking-widest rounded-full">
              Full Alpha Access
            </div>

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-12">
               <div className="space-y-2">
                  <h4 className="text-3xl font-black text-white">AI Twin Sync Pro</h4>
                  <p className="text-slate-400">The complete executive OS powered by Atlas.</p>
               </div>
               <div className="text-left md:text-right">
                  <div className="text-5xl font-black text-white">€499<span className="text-xl text-slate-500">/mo</span></div>
                  <p className="text-xs font-bold text-blue-400 uppercase tracking-widest mt-1">Billed Annually</p>
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6 mb-12">
               {[
                 'Unlimited AI Twin Sync',
                 'Full Voice & Call Handling',
                 'Strategic Decision Support',
                 'Multi-Company Contexts (Up to 5)',
                 'Family VIP Interrupt protocol',
                 'Secure Neural Privacy Link',
                 'Personalized Identity Baseline',
                 'Priority Developer Support'
               ].map((feat, i) => (
                 <div key={i} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400">
                      <Check size={12} strokeWidth={4} />
                    </div>
                    <span className="text-sm font-medium text-slate-200">{feat}</span>
                 </div>
               ))}
            </div>

            <button 
              onClick={onGetStarted}
              className="w-full py-6 bg-white hover:bg-slate-100 text-[#030712] rounded-[2rem] font-black uppercase tracking-[0.2em] transition-all text-sm shadow-xl"
            >
              Initialize Free Trial
            </button>
            <p className="text-center mt-6 text-xs text-slate-500 font-bold uppercase tracking-widest">
              14-Day Free Baseline • No Credit Card Required
            </p>
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-32 px-6">
        <div className="max-w-7xl mx-auto space-y-20">
          <div className="text-center space-y-4">
             <h2 className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-500">Executive Feedback</h2>
             <h3 className="text-4xl md:text-5xl font-black text-white tracking-tighter">Trusted by Decision Makers</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((t) => (
              <TestimonialCard key={t.id} {...t} />
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-32 px-6 border-t border-white/5">
        <div className="max-w-4xl mx-auto space-y-16">
          <div className="text-center space-y-4">
            <h2 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">Baseline Questions</h2>
            <h3 className="text-4xl font-black text-white tracking-tighter">Everything You Need to Know</h3>
          </div>

          <div className="space-y-2">
            {FAQS.map((faq, i) => (
              <FAQItem key={i} {...faq} />
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-32 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-blue-600/10 blur-[150px] rounded-full -z-10 animate-pulse"></div>
        <div className="max-w-5xl mx-auto text-center space-y-12">
          <div className="space-y-4">
             <h2 className="text-5xl md:text-7xl font-black text-white tracking-tighter leading-none">
               Reclaim Your <span className="gradient-text">Freedom</span>
             </h2>
             <p className="text-xl text-slate-400 max-w-2xl mx-auto">
               Join hundreds of high-performance leaders who have delegated the noise to Atlas.
             </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
             <button 
              onClick={onGetStarted}
              className="px-12 py-6 bg-blue-600 hover:bg-blue-500 text-white rounded-[2rem] font-black uppercase tracking-[0.2em] shadow-2xl shadow-blue-600/30 transition-all flex items-center gap-3 text-lg"
             >
               Start Your Sync
               <ArrowRight size={24} />
             </button>
             <div className="text-left">
               <p className="text-xs font-black uppercase tracking-widest text-slate-500">Active Instances</p>
               <p className="text-2xl font-black text-white">1,284 Executives</p>
             </div>
          </div>
          <p className="text-xs text-slate-600 uppercase font-bold tracking-widest">
            Free 14-day trial • Cancel anytime • Zero risk
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-6 border-t border-white/5 bg-[#010309]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-1 space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-black text-white">AI Twin Sync</span>
            </div>
            <p className="text-sm text-slate-500 leading-relaxed">
              The world's first true AI Digital Chief of Staff. Engineered for excellence.
            </p>
          </div>

          <div className="space-y-6">
             <h4 className="text-xs font-black uppercase tracking-widest text-white">Product</h4>
             <ul className="space-y-4 text-sm text-slate-500">
               <li><Link href="#features" className="hover:text-blue-400 transition-colors">Features</Link></li>
               <li><Link href="#how-it-works" className="hover:text-blue-400 transition-colors">Neural Sync</Link></li>
               <li><Link href="#pricing" className="hover:text-blue-400 transition-colors">Voice Link</Link></li>
               <li><Link href="#faq" className="hover:text-blue-400 transition-colors">Security</Link></li>
             </ul>
          </div>

          <div className="space-y-6">
             <h4 className="text-xs font-black uppercase tracking-widest text-white">Company</h4>
             <ul className="space-y-4 text-sm text-slate-500">
               <li><Link href="#" className="hover:text-blue-400 transition-colors">About</Link></li>
               <li><Link href="#" className="hover:text-blue-400 transition-colors">Manifesto</Link></li>
               <li><Link href="#" className="hover:text-blue-400 transition-colors">Ethics</Link></li>
               <li><Link href="#" className="hover:text-blue-400 transition-colors">Contact</Link></li>
             </ul>
          </div>

          <div className="space-y-6">
             <h4 className="text-xs font-black uppercase tracking-widest text-white">Connect</h4>
             <div className="flex items-center gap-4">
               <Link 
                 href="https://aistudio.google.com" 
                 className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all cursor-pointer"
               >
                 <Globe size={20} />
               </Link>
               <Link 
                 href="https://ai.google.dev" 
                 className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all cursor-pointer"
               >
                 <Zap size={20} />
               </Link>
             </div>
             <p className="text-[10px] text-slate-600 font-bold uppercase tracking-[0.2em]">© 2024 AI Twin Sync Global</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
