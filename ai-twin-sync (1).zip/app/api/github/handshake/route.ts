import { NextRequest, NextResponse } from 'next/server';

/**
 * AI Twin Sync - GitHub Handshake Proxy
 * Used to verify PAT tokens without CORS issues.
 */
export async function POST(req: NextRequest) {
  try {
    const { token, repo } = await req.json();

    if (!token) {
      return NextResponse.json({ success: false, message: "Token missing" }, { status: 400 });
    }

    // 1. Verify Token and User Identity
    const userResponse = await fetch('https://api.github.com/user', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'AI-Twin-Sync-Atlas-v12.8'
      }
    });

    if (!userResponse.ok) {
      const errorData = await userResponse.json().catch(() => ({ message: 'GitHub rejected credentials' }));
      return NextResponse.json({ 
        success: false, 
        message: `Authentication Failed: ${errorData.message || 'Invalid PAT'}. Ensure your token is not expired.`
      }, { status: 401 });
    }

    const userData = await userResponse.json();

    // 2. Verify Repo Access (if provided)
    if (repo && repo.includes('/')) {
      const repoResponse = await fetch(`https://api.github.com/repos/${repo}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github.v3+json',
          'User-Agent': 'AI-Twin-Sync-Atlas-v12.8'
        }
      });
      
      if (!repoResponse.ok) {
        return NextResponse.json({ 
          success: false, 
          message: `Verified as @${userData.login}, but repo '${repo}' is inaccessible or does not exist. Ensure the token has 'repo' scopes and the repository name is correct (owner/repo).` 
        });
      }
    }

    return NextResponse.json({ 
      success: true, 
      message: `Neural link established with @${userData.login}. Ready for Sovereign Relay.` 
    });

  } catch (error: any) {
    console.error('[GitHub Handshake Error]', error);
    return NextResponse.json({ 
      success: false, 
      message: "Internal Relay Error. The outbound bridge is experiencing latency." 
    }, { status: 500 });
  }
}