
import { NextRequest } from 'next/server';
import { generateChatStream } from '@/lib/gemini/client';
import { ATLAS_SYSTEM_PROMPT } from '@/lib/gemini/prompts';
import { createClient } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  try {
    const { message, history } = await req.json();
    const supabase = createClient();
    
    // Get user session for context
    const { data: { session } } = await supabase.auth.getSession();
    const userName = session?.user?.user_metadata?.full_name || 'Executive';
    const preferences = "Standard high-performance defaults. Prefers concise updates.";
    const currentDateTime = new Date().toLocaleString();

    const systemInstruction = ATLAS_SYSTEM_PROMPT(userName, preferences, currentDateTime);

    const stream = await generateChatStream({
      contents: [
        ...history.map((h: any) => ({
          role: h.role === 'user' ? 'user' : 'model',
          parts: [{ text: h.content }]
        })),
        { role: 'user', parts: [{ text: message }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    const encoder = new TextEncoder();
    const readableStream = new ReadableStream({
      async start(controller) {
        // Fixed: generateContentStream response is an async iterator of chunks
        for await (const chunk of stream) {
          const text = chunk.text;
          if (text) {
            controller.enqueue(encoder.encode(text));
          }
        }
        controller.close();
      },
    });

    return new Response(readableStream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  } catch (error) {
    console.error('API Chat Error:', error);
    return new Response(JSON.stringify({ error: 'Failed to generate response' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
