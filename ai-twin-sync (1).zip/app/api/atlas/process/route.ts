
import { NextRequest, NextResponse } from 'next/server';
import { Commander } from '@/lib/atlas/commander';
import { ContextBuilder } from '@/lib/atlas/memory/context-builder';
import { createClient } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  try {
    const { message, history } = await req.json();
    const supabase = createClient();
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const context = await ContextBuilder.buildFullContext(session.user.id, message, history);
    const commander = new Commander();
    
    const response = await commander.processMessage(session.user.id, message, context);
    
    return NextResponse.json(response);
  } catch (error: any) {
    console.error('[Atlas Process Error]', error);
    return NextResponse.json({ error: 'Internal Neural Error' }, { status: 500 });
  }
}
