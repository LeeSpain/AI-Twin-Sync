import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { requireAdmin } from '@/lib/admin/auth';

export async function GET() {
  try {
    await requireAdmin();
    // This would fetch real stats from DB
    return NextResponse.json({
      activeUsers: 1284,
      aiActionsToday: 8492,
      latencyMs: 112,
      errorRate: '0.08%'
    });
  } catch (e) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }
}
