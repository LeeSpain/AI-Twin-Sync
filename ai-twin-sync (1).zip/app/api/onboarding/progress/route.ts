import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function GET() {
  const supabase = createClient();
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { data, error } = await supabase
    .from('onboarding_progress')
    .select('*')
    .eq('user_id', session.user.id)
    .single();

  return NextResponse.json(data || { current_step: 0, completed_steps: [] });
}

export async function PUT(req: NextRequest) {
  const supabase = createClient();
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const { data, error } = await supabase
    .from('onboarding_progress')
    .upsert({
      user_id: session.user.id,
      current_step: body.currentStep,
      completed_steps: body.completedSteps,
      status: 'in_progress'
    })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}