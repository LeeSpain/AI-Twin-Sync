import { NextRequest, NextResponse } from 'next/server';

export async function GET(
  req: NextRequest,
  { params }: { params: { provider: string } }
) {
  const provider = params.provider;
  // This would normally construct a redirect URL for Google/Slack/etc.
  // For now, we simulate a successful redirect back to the app.
  return NextResponse.redirect(new URL(`/onboarding/text?success=true&provider=${provider}`, req.url));
}