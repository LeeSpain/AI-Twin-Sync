
import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function GET() {
  const supabase = createClient();
  let dbStatus = 'unhealthy';
  
  try {
    const { error } = await supabase.from('user_profiles').select('count', { count: 'exact', head: true });
    if (!error) dbStatus = 'healthy';
  } catch (e) {
    dbStatus = 'error';
  }

  return NextResponse.json({
    status: dbStatus === 'healthy' ? 'healthy' : 'degraded',
    version: '4.2.0-stable',
    // Fix: Use type assertion for process to handle cases where the environment types (e.g. Edge) might lack the uptime method.
    uptime: typeof (process as any).uptime === 'function' ? (process as any).uptime() : 0,
    services: {
      database: dbStatus,
      gemini: 'operational'
    }
  });
}
