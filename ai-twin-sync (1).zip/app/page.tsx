
'use client';

import React from 'react';
import MarketingPage from '@/app/(marketing)/page';
import { useRouter } from '@/lib/navigation';

/**
 * AI Twin Sync - Surface Entry Point
 */
export default function Home() {
  const router = useRouter();

  const handleGetStarted = () => {
    router.push('/signup');
  };

  return <MarketingPage onGetStarted={handleGetStarted} />;
}
