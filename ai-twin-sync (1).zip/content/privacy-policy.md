# Privacy Policy

**Effective Date**: January 1, 2024

At AI Twin Sync, we take executive privacy seriously.

1. **Data Ownership**: You own your neural data. We act as a processor.
2. **Encryption**: All communication with Atlas is encrypted in transit and at rest.
3. **Gemini Data**: We do not use your private communications to train global AI models.
4. **Your Rights**: You can request a full export or absolute deletion of your neural instance at any time.
