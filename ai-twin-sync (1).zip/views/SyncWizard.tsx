import React, { useState } from 'react';
import { generateSyncData } from '../services/geminiService';
import { AITwin } from '../types';
import { Loader2, Zap, Shield, Cpu } from 'lucide-react';

interface SyncWizardProps {
  onComplete: (twin: AITwin) => void;
  onCancel: () => void;
}

const SyncWizard: React.FC<SyncWizardProps> = ({ onComplete, onCancel }) => {
  const [step, setStep] = useState(1);
  const [userName, setUserName] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [generatedData, setGeneratedData] = useState<any>(null);

  const startSync = async () => {
    setIsSyncing(true);
    setStep(2);
    
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 95) return prev;
        return prev + Math.floor(Math.random() * 5);
      });
    }, 150);

    try {
      const data = await generateSyncData(userName || "User");
      setGeneratedData(data);
      clearInterval(interval);
      setProgress(100);
      setTimeout(() => setStep(3), 1000);
    } catch (error) {
      console.error("Sync failed", error);
      onCancel();
    }
  };

  const handleFinalize = () => {
    const newTwin: AITwin = {
      id: Math.random().toString(36).substr(2, 9),
      name: generatedData.twinName,
      personality: generatedData.personality,
      traits: generatedData.traits,
      syncLevel: 100,
      lastActive: 'Just now',
      avatar: `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${generatedData.twinName}&backgroundColor=030712,1e1b4b`
    };
    onComplete(newTwin);
  };

  return (
    <div className="max-w-2xl mx-auto py-12 px-4">
      {step === 1 && (
        <div className="glass p-8 md:p-12 rounded-[2rem] space-y-8 border-white/5 shadow-2xl">
          <div className="space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-600/20 flex items-center justify-center text-blue-400">
              <Cpu className="w-6 h-6" />
            </div>
            <h2 className="text-4xl font-black text-white tracking-tight">Neural Baseline</h2>
            <p className="text-gray-400 text-lg leading-relaxed">
              To initialize your digital counterpart, we must baseline your identity matrix.
            </p>
          </div>

          <div className="space-y-4">
            <label className="block text-sm font-bold text-gray-400 uppercase tracking-widest">Origin Identity</label>
            <input 
              type="text"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              placeholder="Enter full name or callsign..."
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white text-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all placeholder:text-gray-600"
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <button 
              onClick={onCancel}
              className="flex-1 py-4 border border-white/10 rounded-2xl text-gray-400 font-bold hover:bg-white/5 transition-colors"
            >
              Abort Sync
            </button>
            <button 
              onClick={startSync}
              disabled={!userName || isSyncing}
              className="flex-1 py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-2xl font-bold transition-all shadow-xl shadow-blue-600/30 flex items-center justify-center gap-2"
            >
              {isSyncing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5" />}
              Begin Initialization
            </button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="glass p-12 rounded-[2rem] text-center space-y-8 border-white/5 shadow-2xl overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-1 bg-white/5">
            <div 
              className="h-full bg-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.5)] transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          
          <div className="relative w-48 h-48 mx-auto">
            <div className="absolute inset-0 rounded-full border-4 border-blue-500/10 animate-[ping_3s_linear_infinite]"></div>
            <div className="absolute inset-4 rounded-full border-2 border-blue-400/20 animate-[pulse_2s_ease-in-out_infinite]"></div>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-black text-white">{progress}%</span>
              <span className="text-[10px] text-blue-400 uppercase font-black tracking-[0.3em] mt-2">Syncing Matrix</span>
            </div>
          </div>
          
          <div className="space-y-3">
            <h3 className="text-2xl font-bold text-white tracking-tight">Mapping Neural Pathways</h3>
            <div className="flex items-center justify-center gap-2 text-blue-400/60 font-mono text-xs uppercase tracking-tighter">
              <Loader2 className="w-3 h-3 animate-spin" />
              <span>Analyzing linguistic patterns...</span>
            </div>
          </div>
        </div>
      )}

      {step === 3 && generatedData && (
        <div className="glass p-8 md:p-12 rounded-[2rem] space-y-8 border-white/5 shadow-2xl animate-in fade-in zoom-in duration-500">
          <div className="text-center space-y-4">
            <div className="w-32 h-32 rounded-3xl mx-auto border-4 border-blue-500/30 overflow-hidden mb-4 shadow-2xl rotate-3 hover:rotate-0 transition-transform bg-gray-900 p-2">
               <img 
                 src={`https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${generatedData.twinName}&backgroundColor=030712,1e1b4b`} 
                 alt="Preview" 
                 className="w-full h-full object-contain"
               />
            </div>
            <div className="space-y-1">
              <h2 className="text-4xl font-black text-white tracking-tighter">Sync Complete</h2>
              <p className="text-gray-400 text-lg">Neural Instance: <span className="text-blue-400 font-bold">{generatedData.twinName}</span></p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white/5 p-6 rounded-2xl border border-white/10 space-y-2">
              <div className="flex items-center gap-2 text-[10px] text-blue-400 uppercase font-black tracking-widest">
                <Shield className="w-3 h-3" />
                <span>Operational Core</span>
              </div>
              <p className="text-sm text-gray-200 leading-relaxed font-medium">{generatedData.personality}</p>
            </div>
            <div className="bg-white/5 p-6 rounded-2xl border border-white/10 space-y-4">
               <div className="flex items-center gap-2 text-[10px] text-purple-400 uppercase font-black tracking-widest">
                <Zap className="w-3 h-3" />
                <span>Neural Signatures</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {generatedData.traits.map((t: string, i: number) => (
                  <span key={i} className="px-3 py-1.5 rounded-lg bg-blue-500/10 text-blue-400 text-[10px] font-bold border border-blue-500/20 uppercase tracking-tighter">{t}</span>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white/5 p-6 rounded-2xl border border-white/10 space-y-2">
            <span className="text-[10px] text-gray-500 uppercase font-black tracking-widest">Temporal Origin</span>
            <p className="text-sm text-gray-400 italic leading-relaxed">"{generatedData.background}"</p>
          </div>

          <button 
            onClick={handleFinalize}
            className="w-full py-5 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white rounded-2xl font-black text-lg transition-all shadow-2xl shadow-blue-600/40 uppercase tracking-widest flex items-center justify-center gap-3"
          >
            Engage Neural Link
            <Zap className="w-5 h-5 fill-current" />
          </button>
        </div>
      )}
    </div>
  );
};

export default SyncWizard;