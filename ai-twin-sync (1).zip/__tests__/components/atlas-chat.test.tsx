import { render, screen, fireEvent } from '@testing-library/react';
import ChatContainer from '@/components/atlas/chat-container';
import { describe, it, expect, vi } from 'vitest';

describe('ChatContainer', () => {
  it('renders typing placeholder when no messages', () => {
    render(<ChatContainer />);
    expect(screen.getByText(/Neural Link Ready/i)).toBeDefined();
  });

  it('updates text on input change', () => {
    render(<ChatContainer />);
    const input = screen.getByPlaceholderText(/Issue a direct instruction/i) as HTMLTextAreaElement;
    fireEvent.change(input, { target: { value: 'Hello Atlas' } });
    expect(input.value).toBe('Hello Atlas');
  });
});
