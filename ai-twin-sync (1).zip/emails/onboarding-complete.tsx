import React from 'react';

export default function OnboardingCompleteEmail({ twinName }: { twinName: string }) {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '40px', backgroundColor: '#030712', color: '#fff' }}>
      <h1 style={{ color: '#60a5fa' }}>Synchronization Absolute.</h1>
      <p>Your digital twin, <strong>{twinName}</strong>, is now active and monitoring your operational nodes.</p>
      <p style={{ color: '#94a3b8', fontSize: '14px' }}>Log in to your dashboard to see your first briefing.</p>
    </div>
  );
}
