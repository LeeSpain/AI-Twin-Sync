import React from 'react';

export default function WelcomeEmail({ userName }: { userName: string }) {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '40px', backgroundColor: '#030712', color: '#fff' }}>
      <h1 style={{ fontSize: '24px', fontWeight: 'bold' }}>Welcome to the Neural Network, {userName}.</h1>
      <p style={{ color: '#94a3b8' }}>Atlas is ready to begin your digital baseline.</p>
      <div style={{ marginTop: '30px' }}>
        <a href="https://aitwinsync.com/onboarding" style={{ backgroundColor: '#2563eb', color: '#fff', padding: '12px 24px', borderRadius: '8px', textDecoration: 'none', fontWeight: 'bold' }}>
          Begin Sync Protocol
        </a>
      </div>
    </div>
  );
}
