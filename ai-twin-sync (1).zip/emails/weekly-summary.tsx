import React from 'react';

export default function WeeklySummaryEmail({ emails, meetings, tasks }: any) {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '40px', backgroundColor: '#030712', color: '#fff' }}>
      <h2 style={{ fontSize: '20px' }}>Weekly Neural Digest</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px', margin: '30px 0' }}>
        <div style={{ textAlign: 'center' }}>
          <p style={{ fontSize: '24px', fontWeight: 'bold' }}>{emails}</p>
          <p style={{ fontSize: '10px', color: '#94a3b8' }}>EMAILS HANDLED</p>
        </div>
        <div style={{ textAlign: 'center' }}>
          <p style={{ fontSize: '24px', fontWeight: 'bold' }}>{meetings}</p>
          <p style={{ fontSize: '10px', color: '#94a3b8' }}>MEETINGS SET</p>
        </div>
        <div style={{ textAlign: 'center' }}>
          <p style={{ fontSize: '24px', fontWeight: 'bold' }}>{tasks}</p>
          <p style={{ fontSize: '10px', color: '#94a3b8' }}>TASKS RESOLVED</p>
        </div>
      </div>
      <p style={{ borderTop: '1px solid #1e293b', paddingTop: '20px', fontSize: '12px', color: '#64748b' }}>
        Atlas is optimizing your Q4 throughput. Ready for next week.
      </p>
    </div>
  );
}
