
# AI Twin Sync | Your Digital Chief of Staff

AI Twin Sync is a futuristic executive operating system powered by Google Gemini. It synchronizes your consciousness with **Atlas**, a digital twin that manages your emails, calendar, and strategic tasks.

## 🚀 Features

- **Atlas AI Brain**: Multi-agent system (Commander, Email, Calendar, Task agents).
- **Executive Dashboard**: Real-time monitoring of handled emails, meetings, and neural throughput.
- **Synchronized Chat**: High-fidelity interface to issue instructions to your twin.
- **Deep Onboarding**: Baseline your identity via linguistic or vocal synchronization.
- **Admin Center**: Platform-wide control for scaling instances and managing neural configurations.
- **Secure by Design**: Private Supabase instances with end-to-end encryption.

## 🛠 Tech Stack

- **Framework**: Next.js 15 (App Router)
- **AI**: Google Gemini 3 Pro / 2.5 Flash
- **Backend**: Supabase (Auth, DB, Storage)
- **Styling**: Tailwind CSS + Framer Motion
- **State**: Zustand
- **Icons**: Lucide React

## 📦 Getting Started

1. **Environment**: Copy `.env.example` to `.env` and fill in your Supabase and Gemini API keys.
2. **Database**: Run the migrations in `supabase/migrations/` in your Supabase SQL editor.
3. **Install**: `npm install`
4. **Run**: `npm run dev`

## 🧩 Architecture

- `lib/atlas`: The "Neural Core" containing agent logic and memory management.
- `app/api/atlas`: Secure endpoints for processing intelligence requests.
- `components/marketing`: Premium landing page components.
- `components/dashboard`: High-performance UI for executive oversight.

---
© 2024 AI Twin Sync Global. Built for high-performance leadership.
