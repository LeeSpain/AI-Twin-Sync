
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";

/**
 * AI Twin Sync - Gemini Service
 * 
 * High-performance logic for generating twin responses and neural identities.
 */

export const generateTwinResponse = async (
  prompt: string, 
  personality: string,
  history: { role: 'user' | 'model', parts: { text: string }[] }[]
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [
        ...history.map(h => ({ role: h.role, parts: h.parts })),
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction: `You are Atlas, a world-class AI Digital Chief of Staff. Personality Matrix: ${personality}. Your mission is to maximize the user's executive throughput. Be precise, strategic, and proactive. Always maintain the "Synchronized Twin" persona.`,
        temperature: 0.7,
        topP: 0.9,
        thinkingConfig: { thinkingBudget: 32768 }
      }
    });

    return response.text || "Neural connection unstable. Please re-transmit.";
  } catch (error) {
    console.error("Gemini Response Error:", error);
    return "Neural connection interrupted. The link is experiencing high latency. Please retry your instruction.";
  }
};

export const generateSyncData = async (userName: string): Promise<any> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Initialize a high-fidelity AI Twin profile for a user named ${userName}. This twin will act as their digital Chief of Staff.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            twinName: { type: Type.STRING, description: "A sophisticated, futuristic name (e.g., Atlas, Zenith, Kinetix)" },
            traits: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "Exactly 4 high-performance personality traits" 
            },
            background: { type: Type.STRING, description: "A one-sentence origin story for this neural instance" },
            personality: { type: Type.STRING, description: "Detailed description of their operational philosophy" }
          },
          required: ["twinName", "traits", "background", "personality"]
        },
        thinkingConfig: { thinkingBudget: 16000 }
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from AI engine");
    
    return JSON.parse(text);
  } catch (e) {
    console.error("Failed to generate sync data, falling back to safe profile", e);
    return {
      twinName: "Atlas-Alpha",
      traits: ["Analytical", "Strategic", "Proactive", "Resilient"],
      background: "A core neural fragment recovered during the initial sync protocol fallback.",
      personality: "Highly efficient and focused on executive optimization. Always reliable and precise."
    };
  }
};
