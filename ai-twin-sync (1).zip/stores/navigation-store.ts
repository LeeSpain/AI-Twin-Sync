
import { create } from 'zustand';

interface NavigationState {
  currentPath: string;
  setPath: (path: string) => void;
  reset: () => void;
}

export const useNavigationStore = create<NavigationState>((set) => ({
  currentPath: '/',
  setPath: (path: string) => set({ currentPath: path }),
  reset: () => set({ currentPath: '/' }),
}));
