
import React, { useState } from 'react';
import { usePathname } from '@/lib/navigation';
import DashboardLayout from './app/(dashboard)/layout';
import DashboardPage from './app/(dashboard)/dashboard/page';
import ChatPage from './app/(dashboard)/chat/page';
import InboxPage from './app/(dashboard)/inbox/page';
import CalendarPage from './app/(dashboard)/calendar/page';
import TasksPage from './app/(dashboard)/tasks/page';
import SettingsPage from './app/(dashboard)/settings/page';
import SyncWizard from './views/Dashboard'; // Using dashboard as base for sync initialization
import { AITwin } from './types';

const INITIAL_TWINS: AITwin[] = [
  {
    id: '1',
    name: 'Atlas Prime',
    personality: 'Highly analytical, calm, and focuses on efficiency. A perfect digital assistant for complex tasks.',
    traits: ['Analytical', 'Stoic', 'Precise'],
    syncLevel: 98,
    lastActive: '2m ago',
    avatar: 'https://picsum.photos/seed/atlas/200/200'
  }
];

const App: React.FC = () => {
  const pathname = usePathname();
  const [twins] = useState<AITwin[]>(INITIAL_TWINS);

  // Sub-routing for the Dashboard area
  const renderDashboardView = () => {
    switch (pathname) {
      case '/dashboard':
        return <DashboardPage />;
      case '/chat':
        return <ChatPage />;
      case '/inbox':
        return <InboxPage />;
      case '/calendar':
        return <CalendarPage />;
      case '/tasks':
        return <TasksPage />;
      case '/settings':
        return <SettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <DashboardLayout>
      <div className="animate-in fade-in duration-700 h-full">
        {renderDashboardView()}
      </div>
    </DashboardLayout>
  );
};

export default App;
