# Terms of Service

By engaging AI Twin Sync, you agree to:

1. **Authorized Use**: Use the platform only for legitimate executive management.
2. **Neural Responsibility**: You are responsible for any actions executed by Atlas that you have approved.
3. **Liability**: We provide the AI "Chief of Staff" service as-is. Check high-stakes drafts manually.
