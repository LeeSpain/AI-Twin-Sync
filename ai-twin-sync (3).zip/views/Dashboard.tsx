
import React from 'react';
import TwinCard from '../components/TwinCard';
import { AITwin } from '../types';

interface DashboardProps {
  twins: AITwin[];
  onSelectTwin: (twin: AITwin) => void;
  onStartSync: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ twins, onSelectTwin, onStartSync }) => {
  return (
    <div className="space-y-12 py-6">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight text-white mb-2">Welcome Back, <span className="gradient-text">Sync Alpha</span></h1>
          <p className="text-gray-400 text-lg">Your digital neural network is currently operating at 94% efficiency.</p>
        </div>
        <button 
          onClick={onStartSync}
          className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-blue-600/20 flex items-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Initialize New Twin
        </button>
      </header>

      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            Active Neural Links
          </h2>
          <span className="text-sm text-gray-500">{twins.length} Synchronized Units</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {twins.map(twin => (
            <TwinCard key={twin.id} twin={twin} onSelect={onSelectTwin} />
          ))}

          <div 
            onClick={onStartSync}
            className="border-2 border-dashed border-white/10 rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:border-blue-500/40 hover:bg-blue-500/5 transition-all cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center group-hover:scale-110 transition-transform">
              <svg className="w-6 h-6 text-gray-400 group-hover:text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
            </div>
            <span className="text-gray-400 font-medium group-hover:text-blue-400">Add New Twin</span>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Neural Throughput', value: '2.4 GB/s', trend: '+12%' },
          { label: 'Sync Fidelity', value: '99.2%', trend: '+0.4%' },
          { label: 'Cloud Storage', value: '14/50 GB', trend: '28%' }
        ].map((stat, idx) => (
          <div key={idx} className="glass p-6 rounded-2xl">
            <p className="text-sm text-gray-500 font-medium mb-1">{stat.label}</p>
            <div className="flex items-end justify-between">
              <h4 className="text-2xl font-bold text-white">{stat.value}</h4>
              <span className="text-xs font-bold text-green-400">{stat.trend}</span>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
};

export default Dashboard;
