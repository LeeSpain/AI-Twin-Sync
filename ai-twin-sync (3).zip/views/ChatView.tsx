
import React, { useState, useRef, useEffect } from 'react';
import { generateTwinResponse } from '../services/geminiService';
import { AITwin, ChatMessage } from '../types';
import { Send, Terminal, Loader2, ArrowLeft } from 'lucide-react';

interface ChatViewProps {
  twin: AITwin;
}

const ChatView: React.FC<ChatViewProps> = ({ twin }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  useEffect(() => {
    // Initial greeting if no messages exist
    if (messages.length === 0) {
      setMessages([{
        id: 'init-' + Date.now(),
        role: 'model',
        text: `Link established. I am ${twin.name}. My core matrix is fully synchronized with your preferences. How can I assist you today?`,
        timestamp: new Date()
      }]);
    }
  }, [twin]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const currentInput = input;
    const userMsg: ChatMessage = {
      id: 'user-' + Date.now(),
      role: 'user',
      text: currentInput,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      
      const responseText = await generateTwinResponse(currentInput, twin.personality, history);
      
      const modelMsg: ChatMessage = {
        id: 'model-' + Date.now(),
        role: 'model',
        text: responseText,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, modelMsg]);
    } catch (error) {
      console.error('Sync error:', error);
      const errorMsg: ChatMessage = {
        id: 'error-' + Date.now(),
        role: 'model',
        text: "Neural connection error. I've encountered a temporary desync. Please retry your transmission.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto flex flex-col h-[calc(100vh-160px)] animate-in slide-in-from-right-4 duration-500">
      <div className="flex items-center justify-between mb-6 pb-6 border-b border-white/10">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-blue-500/50 ring-4 ring-blue-500/10 shadow-lg shadow-blue-500/20">
            <img src={twin.avatar} alt={twin.name} className="w-full h-full object-cover" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-white">{twin.name}</h2>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              <span className="text-[10px] text-green-400 font-bold uppercase tracking-widest">Neural Link: 100% Fidelity</span>
            </div>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-3">
          <div className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-[10px] font-mono text-blue-400">
            SECURE_SYNC_v4.2
          </div>
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto space-y-6 pr-4 mb-6 scroll-smooth custom-scrollbar"
      >
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-3xl px-6 py-4 shadow-sm ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white rounded-tr-none' 
                : 'glass text-gray-100 rounded-tl-none border border-white/10'
            }`}>
              <p className="text-[15px] leading-relaxed whitespace-pre-wrap">{msg.text}</p>
              <div className={`text-[9px] mt-2 font-mono flex items-center gap-1.5 opacity-40 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.role === 'model' && <Terminal className="w-2.5 h-2.5" />}
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="glass rounded-3xl rounded-tl-none px-6 py-4 flex gap-2 items-center border border-white/5">
              <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />
              <span className="text-xs font-mono text-gray-400 uppercase tracking-tighter">Processing Neural Input...</span>
            </div>
          </div>
        )}
      </div>

      <div className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-3xl blur opacity-0 group-focus-within:opacity-100 transition duration-500"></div>
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={`Instruct ${twin.name}...`}
            className="w-full glass rounded-2xl px-6 py-5 pr-16 focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none h-16 min-h-[64px] max-h-40 text-white placeholder-gray-500 text-[15px] transition-all"
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="absolute right-4 top-3.5 w-10 h-10 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:bg-gray-700 text-white rounded-xl flex items-center justify-center transition-all shadow-lg shadow-blue-600/20 active:scale-95"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
      <p className="text-[10px] text-center text-gray-500 mt-4 font-mono uppercase tracking-widest">
        Sync Protocol v4 • Gemini 3.0 Pro Intelligence Engine
      </p>
    </div>
  );
};

export default ChatView;
