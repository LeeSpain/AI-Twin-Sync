
export enum MemoryType {
  FACT = 'fact',
  PREFERENCE = 'preference',
  RELATIONSHIP = 'relationship',
  EVENT = 'event',
  PATTERN = 'pattern'
}

export interface Memory {
  id: string;
  userId: string;
  fragment: string;
  type: MemoryType;
  importance: number;
  lastRecalledAt: string;
  createdAt: string;
  metadata?: Record<string, any>;
}

export interface LearningEvent {
  userId: string;
  source: 'email' | 'interaction' | 'correction' | 'approval';
  content: string;
  metadata?: Record<string, any>;
}
