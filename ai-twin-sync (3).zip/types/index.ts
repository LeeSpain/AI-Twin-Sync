
export * from './database'
export * from './api'
// Explicitly export members of atlas.ts to resolve the AtlasMemory naming conflict with database.ts
export { 
  type AtlasMessage, 
  type AtlasConversation, 
  type AtlasAction, 
  type AtlasContext, 
  type AtlasResponse 
} from './atlas'
export * from './integrations'

// Changed ViewState to a union of string literals to support the string-based navigation used in components
export type ViewState = 'dashboard' | 'sync' | 'chat' | 'onboarding'

// Added missing interface AITwin required by Dashboard, SyncWizard and App components
export interface AITwin {
  id: string;
  name: string;
  personality: string;
  traits: string[];
  syncLevel: number;
  lastActive: string;
  avatar: string;
}

// Added missing interface ChatMessage required by ChatView component
export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export type Priority = 'low' | 'medium' | 'high' | 'urgent'
export type TaskStatus = 'todo' | 'in_progress' | 'completed' | 'blocked' | 'cancelled'
