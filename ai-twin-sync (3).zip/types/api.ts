
import { Database, Json } from './database'
import { AtlasMessage } from './atlas'

/**
 * AI Twin Sync - API Response Types
 */

export type ApiResponse<T> = {
  data: T | null
  error: {
    message: string
    code?: string
  } | null
}

export interface ChatRequest {
  conversationId?: string
  message: string
}

export interface ChatResponse {
  conversationId: string
  // Fixed: Used AtlasMessage as the 'messages' table is not defined in the Database schema
  message: AtlasMessage
  // Fixed: Database['public']['Tables'] does not contain 'ai_actions'
  actions?: Json[]
}

export interface SyncRequest {
  provider: string
  code: string
}

export interface OnboardingSubmitRequest {
  responses: Record<string, any>
}
