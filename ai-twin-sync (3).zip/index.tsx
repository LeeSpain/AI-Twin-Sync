
import React, { useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import Home from './app/page';
import App from './App';
import LoginPage from './app/(auth)/login/page';
import SignupPage from './app/(auth)/signup/page';
import OnboardingPage from './app/(auth)/onboarding/page';
import TextOnboarding from './app/(auth)/onboarding/text/page';
import AdminDashboardPage from './app/(admin)/admin/page';
import AdminLayout from './app/(admin)/layout';
import AuthLayout from './app/(auth)/layout';
import OnboardingLayout from './app/(auth)/onboarding/layout';
import { useNavigationStore } from './stores/navigation-store';
import './app/globals.css';

/**
 * AI Twin Sync - Application Router
 * 
 * Orchestrates high-level route switching based on internal state.
 */

const Root = () => {
  const currentPath = useNavigationStore((s) => s.currentPath);

  useEffect(() => {
    console.debug(`[Neural Router] Path changed: ${currentPath}`);
  }, [currentPath]);

  // Top-level routing logic
  const renderContent = () => {
    if (currentPath === '/') return <Home />;
    
    // Auth Routes
    if (currentPath === '/login') return <AuthLayout><LoginPage /></AuthLayout>;
    if (currentPath === '/signup') return <AuthLayout><SignupPage /></AuthLayout>;
    
    // Onboarding Routes
    if (currentPath === '/onboarding') return <OnboardingLayout><OnboardingPage /></OnboardingLayout>;
    if (currentPath.startsWith('/onboarding/')) return <OnboardingLayout><TextOnboarding /></OnboardingLayout>;

    // Admin Routes
    if (currentPath.startsWith('/admin')) {
      return (
        <AdminLayout>
          <AdminDashboardPage />
        </AdminLayout>
      );
    }

    // Dashboard/Main App Routes (Internal routing handled by App.tsx)
    return <App />;
  };

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-blue-500/30">
      {renderContent()}
    </div>
  );
};

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <Root />
    </React.StrictMode>
  );
}
