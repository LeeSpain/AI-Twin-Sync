import { create } from 'zustand';

export type OnboardingMode = 'text' | 'voice';

interface OnboardingState {
  currentStep: number;
  completedSteps: number[];
  responses: Record<string, any>;
  mode: OnboardingMode | null;
  isAnalyzing: boolean;
  
  setStep: (step: number) => void;
  addResponse: (stepId: string, response: any) => void;
  setMode: (mode: OnboardingMode) => void;
  setAnalyzing: (isAnalyzing: boolean) => void;
  completeStep: (stepIndex: number) => void;
  reset: () => void;
}

export const useOnboardingStore = create<OnboardingState>((set) => ({
  currentStep: 0,
  completedSteps: [],
  responses: {},
  mode: null,
  isAnalyzing: false,

  setStep: (currentStep) => set({ currentStep }),
  addResponse: (stepId, response) => 
    set((state) => ({ 
      responses: { ...state.responses, [stepId]: response } 
    })),
  setMode: (mode) => set({ mode }),
  setAnalyzing: (isAnalyzing) => set({ isAnalyzing }),
  completeStep: (stepIndex) => 
    set((state) => ({ 
      completedSteps: Array.from(new Set([...state.completedSteps, stepIndex])) 
    })),
  reset: () => set({ currentStep: 0, completedSteps: [], responses: {}, mode: null, isAnalyzing: false }),
}));