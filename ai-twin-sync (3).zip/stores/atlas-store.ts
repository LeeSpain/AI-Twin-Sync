import { create } from 'zustand';
import { AtlasMessage } from '@/types/atlas';

interface AtlasState {
  messages: AtlasMessage[];
  isLoading: boolean;
  isListening: boolean;
  currentConversationId: string | null;
  addMessage: (message: AtlasMessage) => void;
  setMessages: (messages: AtlasMessage[]) => void;
  setLoading: (loading: boolean) => void;
  setListening: (listening: boolean) => void;
  setConversationId: (id: string | null) => void;
  clearMessages: () => void;
}

export const useAtlasStore = create<AtlasState>((set) => ({
  messages: [],
  isLoading: false,
  isListening: false,
  currentConversationId: null,
  addMessage: (message) => set((state) => ({ messages: [...state.messages, message] })),
  setMessages: (messages) => set({ messages }),
  setLoading: (isLoading) => set({ isLoading }),
  setListening: (isListening) => set({ isListening }),
  setConversationId: (currentConversationId) => set({ currentConversationId }),
  clearMessages: () => set({ messages: [] }),
}));