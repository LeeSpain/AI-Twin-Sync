import { create } from 'zustand';

interface AdminState {
  isSidebarCollapsed: boolean;
  selectedUserId: string | null;
  platformStats: any;
  auditFilters: {
    type: string[];
    status: string[];
    dateRange: [Date, Date] | null;
  };
  
  toggleSidebar: () => void;
  setSelectedUser: (id: string | null) => void;
  setPlatformStats: (stats: any) => void;
  setAuditFilters: (filters: Partial<AdminState['auditFilters']>) => void;
}

export const useAdminStore = create<AdminState>((set) => ({
  isSidebarCollapsed: false,
  selectedUserId: null,
  platformStats: null,
  auditFilters: {
    type: [],
    status: [],
    dateRange: null,
  },

  toggleSidebar: () => set((state) => ({ isSidebarCollapsed: !state.isSidebarCollapsed })),
  setSelectedUser: (selectedUserId) => set({ selectedUserId }),
  setPlatformStats: (platformStats) => set({ platformStats }),
  setAuditFilters: (filters) => 
    set((state) => ({ 
      auditFilters: { ...state.auditFilters, ...filters } 
    })),
}));