
/**
 * Legacy types.ts - Now proxying to the new structured types/ directory
 */
export * from './types/index'

// Preserving legacy naming if strictly required by components during transition
export type { Database as SupabaseDatabase } from './types/database'
