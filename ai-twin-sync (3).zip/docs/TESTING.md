# 🧪 Testing AI Twin Sync

We prioritize high-fidelity unit and integration tests.

## Running Tests
- Unit tests: `npm run test`
- E2E tests: `npm run test:e2e`

## Manual QA Checklist
1. Onboarding flow completes with valid sync data.
2. Chat UI handles streaming tokens without flickering.
3. Admin dashboard accurately reflects system load.
4. Action pipeline requires manual approval below threshold.
