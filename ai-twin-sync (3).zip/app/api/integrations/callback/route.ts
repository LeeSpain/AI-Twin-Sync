import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  const searchParams = req.nextUrl.searchParams;
  const code = searchParams.get('code');
  
  // Logic to exchange code for tokens and store in Supabase...
  
  return NextResponse.redirect(new URL('/onboarding/text', req.url));
}