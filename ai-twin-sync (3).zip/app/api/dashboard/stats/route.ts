import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export async function GET() {
  try {
    const supabase = createClient();
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // In a real app, these would be complex queries across multiple tables
    // For this prototype, we return high-fidelity mock data consistent with user interaction
    const stats = {
      emailsHandled: 42,
      meetingsScheduled: 8,
      tasksPending: 15,
      aiActionsToday: 128
    };

    return NextResponse.json(stats);
  } catch (error) {
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}