
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { MemoryManager } from '@/lib/atlas/memory/memory-manager';

export async function GET(req: NextRequest) {
  const supabase = createClient();
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const memories = await MemoryManager.getRelevantMemories(session.user.id, "");
  return NextResponse.json(memories);
}
