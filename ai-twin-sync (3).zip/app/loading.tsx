
import React from 'react';
import LoadingSpinner from '@/components/ui/loading-spinner';

export default function RootLoading() {
  return (
    <div className="fixed inset-0 bg-[#030712] flex items-center justify-center z-[9999]">
      <div className="space-y-8 flex flex-col items-center">
        <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-[2rem] flex items-center justify-center shadow-2xl shadow-blue-600/30">
          <svg className="w-10 h-10 text-white animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </div>
        <LoadingSpinner label="Initializing Neural Link" />
      </div>
    </div>
  );
}
