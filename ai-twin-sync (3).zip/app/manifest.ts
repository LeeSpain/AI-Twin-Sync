
import { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'AI Twin Sync',
    short_name: 'AI Twin',
    description: 'Your Digital AI Chief of Staff',
    start_url: '/dashboard',
    display: 'standalone',
    background_color: '#030712',
    theme_color: '#030712',
    icons: [
      {
        src: '/favicon.ico',
        sizes: 'any',
        type: 'image/x-icon',
      },
      {
        src: 'https://api.dicebear.com/7.x/bottts-neutral/svg?seed=Atlas&backgroundColor=030712',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: 'https://api.dicebear.com/7.x/bottts-neutral/svg?seed=Atlas&backgroundColor=030712',
        sizes: '512x512',
        type: 'image/png',
      },
    ],
  };
}
