
import React from 'react';
import { Link } from '@/lib/navigation';
import { Search, Home, ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#030712] text-center">
      <div className="max-w-xl space-y-10">
        <div className="relative">
           <h1 className="text-[12rem] font-black text-white/5 leading-none select-none">404</h1>
           <div className="absolute inset-0 flex items-center justify-center">
             <div className="w-24 h-24 bg-rose-500/10 rounded-[2.5rem] flex items-center justify-center text-rose-500">
               <Search size={48} />
             </div>
           </div>
        </div>
        
        <div className="space-y-4">
          <h2 className="text-4xl font-black text-white tracking-tighter">Node Not Found</h2>
          <p className="text-slate-400 text-lg">
            I've scanned the entire neural network but this specific entry point doesn't exist.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link 
            href="/dashboard"
            className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-xl shadow-blue-600/20"
          >
            <Home size={18} />
            Return to Core
          </Link>
          <Link 
             href="/"
             className="px-8 py-4 glass border-white/5 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-white/5 transition-all"
          >
            <ArrowLeft size={18} />
            Back to Surface
          </Link>
        </div>
      </div>
    </div>
  );
}
