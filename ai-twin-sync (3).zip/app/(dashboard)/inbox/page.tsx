
import React from 'react';
import { Mail, Search, Filter, Archive, Star, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

const EMAILS = [
  { id: '1', sender: 'Lee Wakeman', subject: 'Strategic Pivot Q4', preview: 'Atlas, I need you to review the latest board slides and...', time: '10:24 AM', label: 'Priority', unread: true },
  { id: '2', sender: 'Sarah Jenkins', subject: 'Product Sync Follow-up', preview: 'Great catch on the latency issues. Let\'s schedule a call...', time: 'Yesterday', label: 'Strategic', unread: false },
  { id: '3', sender: 'Amazon Web Services', subject: 'Invoice #8490', preview: 'Your monthly bill for AI Twin Sync Cluster Alpha is ready...', time: '2 days ago', label: 'Finance', unread: false },
];

export default function InboxPage() {
  return (
    <div className="space-y-8 h-full flex flex-col">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-white mb-1">Neural <span className="text-blue-500">Inbox</span></h1>
          <p className="text-slate-400">Atlas is screening 14 unread operational threads.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-5 py-2.5 glass border-white/5 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-white/5">
            <Archive size={16} />
            Archive All
          </button>
        </div>
      </div>

      <div className="flex flex-1 gap-6 min-h-0">
        <div className="flex-1 glass-panel rounded-[2.5rem] border-white/5 overflow-hidden flex flex-col">
          <div className="p-4 border-b border-white/5 flex items-center gap-4 bg-white/5">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
              <input 
                type="text" 
                placeholder="Search communications..." 
                className="w-full bg-transparent pl-12 pr-4 py-2 text-sm focus:outline-none"
              />
            </div>
            <button className="p-2 text-slate-500 hover:text-white"><Filter size={18} /></button>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {EMAILS.map((email) => (
              <div key={email.id} className={cn(
                "p-6 border-b border-white/5 cursor-pointer hover:bg-white/[0.02] transition-colors flex items-start gap-4",
                email.unread && "bg-blue-500/5"
              )}>
                <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center font-bold text-blue-400">
                  {email.sender.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center mb-1">
                    <h4 className={cn("text-sm", email.unread ? "font-black text-white" : "font-medium text-slate-300")}>{email.sender}</h4>
                    <span className="text-[10px] font-mono text-slate-500">{email.time}</span>
                  </div>
                  <h5 className={cn("text-sm mb-1 truncate", email.unread ? "text-blue-400" : "text-slate-200")}>{email.subject}</h5>
                  <p className="text-xs text-slate-500 line-clamp-1">{email.preview}</p>
                </div>
                <div className="flex flex-col items-end gap-2">
                   <Star size={14} className="text-slate-700 hover:text-amber-400 transition-colors" />
                   <span className="px-2 py-0.5 rounded bg-white/5 border border-white/5 text-[9px] font-black uppercase tracking-widest text-slate-500">{email.label}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="hidden xl:flex w-96 glass-panel rounded-[2.5rem] border-white/5 p-8 flex-col gap-6">
           <div className="text-center space-y-4">
              <div className="w-20 h-20 bg-blue-600/10 rounded-3xl mx-auto flex items-center justify-center text-blue-400">
                <Mail size={40} />
              </div>
              <h3 className="text-xl font-bold">Select a Thread</h3>
              <p className="text-sm text-slate-500 leading-relaxed">Select a communication thread to engage the Atlas drafting synthesizer.</p>
           </div>
           
           <div className="mt-auto p-6 bg-blue-600/10 border border-blue-500/20 rounded-2xl space-y-3">
              <div className="flex items-center gap-2 text-blue-400">
                 <Clock size={16} />
                 <span className="text-[10px] font-black uppercase tracking-widest">Atlas Insight</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed italic">
                "I've identified 3 high-stakes threads from today that require strategic drafting. Should I begin?"
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}
