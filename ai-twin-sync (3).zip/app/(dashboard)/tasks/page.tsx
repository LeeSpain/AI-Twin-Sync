
import React from 'react';
import { CheckSquare, Plus, MoreVertical, Clock, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

const COLUMNS = [
  { id: 'todo', name: 'Baseline Tasks', color: 'slate' },
  { id: 'progress', name: 'Neural Processing', color: 'blue' },
  { id: 'completed', name: 'Synchronized', color: 'emerald' },
];

const TASKS = [
  { id: '1', title: 'Review Q4 Strategy', status: 'todo', priority: 'High', time: '2h' },
  { id: '2', title: 'Approve Invoice #809', status: 'progress', priority: 'Urgent', time: '10m' },
  { id: '3', title: 'Schedule Weekly Retro', status: 'completed', priority: 'Low', time: 'Done' },
];

export default function TasksPage() {
  return (
    <div className="space-y-8 h-full flex flex-col">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-white mb-1">Task <span className="text-emerald-500">Board</span></h1>
          <p className="text-slate-400">Atlas is optimizing 15 pending objectives.</p>
        </div>
        <button className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center gap-2 transition-all">
          <Plus size={18} />
          Append Task
        </button>
      </div>

      <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-8 min-h-0">
        {COLUMNS.map(col => (
          <div key={col.id} className="flex flex-col gap-6">
            <div className="flex items-center justify-between px-2">
               <h3 className="font-black uppercase tracking-widest text-xs text-slate-500 flex items-center gap-2">
                 <div className={cn("w-1.5 h-1.5 rounded-full", col.color === 'blue' ? 'bg-blue-500' : col.color === 'emerald' ? 'bg-emerald-500' : 'bg-slate-500')} />
                 {col.name}
               </h3>
               <span className="text-[10px] font-mono text-slate-600">{TASKS.filter(t => t.status === col.id).length}</span>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto custom-scrollbar">
              {TASKS.filter(t => t.status === col.id).map(task => (
                <div key={task.id} className="glass-panel p-6 rounded-[2rem] border-white/5 hover:border-white/10 transition-all cursor-pointer group">
                  <div className="flex justify-between items-start mb-4">
                     <span className={cn(
                       "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest border",
                       task.priority === 'Urgent' ? "bg-red-500/10 text-red-400 border-red-500/20" : "bg-blue-500/10 text-blue-400 border-blue-500/20"
                     )}>
                       {task.priority}
                     </span>
                     <button className="text-slate-600 group-hover:text-white transition-colors"><MoreVertical size={14} /></button>
                  </div>
                  <h4 className="text-sm font-bold text-white mb-4 leading-tight">{task.title}</h4>
                  <div className="flex items-center justify-between pt-4 border-t border-white/5">
                     <div className="flex items-center gap-1.5 text-slate-500">
                        <Clock size={12} />
                        <span className="text-[10px] font-mono">{task.time}</span>
                     </div>
                     <div className="w-6 h-6 rounded-lg bg-white/5 flex items-center justify-center text-slate-600">
                        <CheckSquare size={12} />
                     </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
