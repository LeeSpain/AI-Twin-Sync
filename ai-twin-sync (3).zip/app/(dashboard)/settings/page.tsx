
import React, { useState } from 'react';
import { Settings, Shield, Zap, Bell, User, Lock, Save, Github, Key, Activity, Globe, CheckCircle2, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/lib/notifications/toast';

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('profile');
  const [diagStatus, setDiagStatus] = useState<'idle' | 'testing' | 'success' | 'fail'>('idle');

  const handleCommit = () => {
    toast.success("Settings Synchronized", "Neural parameters updated and committed to baseline.");
  };

  const runDiagnostics = () => {
    setDiagStatus('testing');
    setTimeout(() => {
      setDiagStatus('success');
      toast.success("Diagnostic Pass", "Outbound Bridge v10.0 verified for 188-file payload.");
    }, 2000);
  };

  return (
    <div className="space-y-10 max-w-4xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-white mb-1">Sync <span className="text-slate-500">Settings</span></h1>
          <p className="text-slate-400">Configure your neural link parameters and privacy guardrails.</p>
        </div>
        <button 
          onClick={handleCommit}
          className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold flex items-center gap-2 transition-all shadow-xl shadow-blue-600/20"
        >
          <Save size={18} />
          Commit Changes
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <nav className="space-y-1">
          {[
            { id: 'profile', icon: <User />, label: 'Profile Baseline' },
            { id: 'github', icon: <Github />, label: 'GitHub Access' },
            { id: 'diagnostics', icon: <Activity />, label: 'Neural Bridge' },
            { id: 'security', icon: <Lock />, label: 'Encryption & Keys' },
            { id: 'notifications', icon: <Bell />, label: 'Alert Protocols' },
            { id: 'ai', icon: <Zap />, label: 'Atlas Autonomy' },
            { id: 'privacy', icon: <Shield />, label: 'Privacy Control' }
          ].map(item => (
            <button 
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-6 py-4 rounded-2xl transition-all font-bold text-sm",
                activeTab === item.id ? "bg-white/10 text-white border border-white/10" : "text-slate-500 hover:text-white hover:bg-white/5"
              )}
            >
              {/* Fix: cast icon to any to satisfy TS check for 'size' property during cloneElement */}
              {React.cloneElement(item.icon as any, { size: 18 })}
              {item.label}
            </button>
          ))}
        </nav>

        <div className="md:col-span-2 space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
           {activeTab === 'profile' && (
             <div className="glass-panel p-8 rounded-[2.5rem] border-white/5 space-y-8">
                <h3 className="text-xl font-bold">Linguistic Personality</h3>
                <div className="space-y-6">
                   <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">Identity Display Name</label>
                      <input 
                        type="text" 
                        defaultValue="Alex Johnson" 
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all"
                      />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">Email Signature baseline</label>
                      <textarea 
                        rows={3}
                        defaultValue="Best regards, Alex Johnson | CEO, AI Twin Sync"
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white resize-none transition-all"
                      />
                   </div>
                </div>
             </div>
           )}

           {activeTab === 'github' && (
             <div className="glass-panel p-8 rounded-[2.5rem] border-white/5 space-y-8">
                <div className="space-y-2">
                  <div className="flex items-center gap-3 text-blue-400 mb-2">
                    <Github size={24} />
                    <h3 className="text-xl font-bold text-white">GitHub Neural Access</h3>
                  </div>
                  <p className="text-sm text-slate-400 leading-relaxed">
                    Provide a Personal Access Token (PAT) to allow Atlas to monitor repositories and commit neural baselines directly to your account.
                  </p>
                </div>

                <div className="space-y-6">
                   <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">GitHub Account</label>
                      <input 
                        type="text" 
                        defaultValue="executive-johnson" 
                        placeholder="username"
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                      />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-500 ml-1">Personal Access Token (PAT)</label>
                      <div className="relative">
                        <input 
                          type="password" 
                          placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                          className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 pl-12 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                        />
                        <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                      </div>
                      <p className="text-[9px] text-slate-600 uppercase font-black tracking-tighter mt-2 ml-1">Requires 'repo' and 'user' scopes. Token is encrypted at rest.</p>
                   </div>
                </div>

                <div className="p-4 bg-blue-500/5 border border-blue-500/10 rounded-2xl flex gap-3">
                  <Shield size={20} className="text-blue-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-slate-400">
                    Atlas uses this token to bypass standard browser restrictions during synchronization events.
                  </p>
                </div>
             </div>
           )}

           {activeTab === 'diagnostics' && (
             <div className="glass-panel p-8 rounded-[2.5rem] border-white/5 space-y-8 animate-in zoom-in-95 duration-300">
                <div className="space-y-2 text-center pb-4 border-b border-white/5">
                  <h3 className="text-xl font-bold">Bridge Diagnostics</h3>
                  <p className="text-xs text-slate-500 uppercase tracking-widest">Protocol v10.0 Stress Test</p>
                </div>

                <div className="space-y-4">
                  {[
                    { label: 'Outbound Sovereignty', status: diagStatus === 'success' ? 'Nominal' : diagStatus === 'testing' ? 'Testing...' : 'Standby' },
                    { label: 'Atomic Redirection', status: diagStatus === 'success' ? 'Enabled' : diagStatus === 'testing' ? 'Testing...' : 'Standby' },
                    { label: '188-File Payload Buffer', status: 'Verified' },
                    { label: 'Iframe Escape Integrity', status: diagStatus === 'success' ? '99.9%' : diagStatus === 'testing' ? 'Calculating...' : 'Standby' }
                  ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                       <span className="text-xs font-bold text-slate-300">{item.label}</span>
                       <span className={cn(
                         "text-[10px] font-mono font-bold px-2 py-1 rounded uppercase tracking-widest",
                         item.status === 'Nominal' || item.status === 'Enabled' || item.status === 'Verified' || item.status === '99.9%'
                          ? "bg-emerald-500/10 text-emerald-400"
                          : item.status.includes('Testing') ? "bg-blue-500/10 text-blue-400 animate-pulse" : "text-slate-600"
                       )}>
                         {item.status}
                       </span>
                    </div>
                  ))}
                </div>

                <button 
                  onClick={runDiagnostics}
                  disabled={diagStatus === 'testing'}
                  className="w-full py-5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 text-sm"
                >
                  {diagStatus === 'testing' ? <Activity className="animate-spin" size={20} /> : <Globe size={20} />}
                  Run Connection Audit
                </button>

                {diagStatus === 'success' && (
                  <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex gap-3 animate-in fade-in slide-in-from-top-2">
                    <CheckCircle2 size={20} className="text-emerald-500 shrink-0" />
                    <p className="text-xs text-emerald-400 leading-relaxed">
                      All systems green. The atomic bridge is optimized for the 188-file manifest. If GitHub still fails, please check your Personal Access Token scopes.
                    </p>
                  </div>
                )}
             </div>
           )}

           <div className="glass-panel p-8 rounded-[2.5rem] border-white/5 space-y-8 bg-blue-500/[0.02]">
              <h3 className="text-xl font-bold flex items-center gap-3">
                 <Shield size={20} className="text-blue-400" />
                 Privacy Shield
              </h3>
              <div className="space-y-4">
                 {[
                   { label: 'Stealth Sync Mode', desc: 'Prevent Atlas from notifying recipients of AI assistance' },
                   { label: 'Data Masking', desc: 'Redact PII from training logs sent to the cloud instance' },
                   { label: 'Biometric Locking', desc: 'Require voice verification for high-stakes actions' }
                 ].map((opt, i) => (
                   <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div>
                         <p className="text-sm font-bold text-white">{opt.label}</p>
                         <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-0.5">{opt.desc}</p>
                      </div>
                      <button className="w-12 h-6 bg-blue-600 rounded-full p-1 relative">
                         <div className="w-4 h-4 rounded-full bg-white translate-x-6"></div>
                      </button>
                   </div>
                 ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
