
'use client';

import React from 'react';
import ChatContainer from '@/components/atlas/chat-container';
import { Terminal, Shield, Cpu } from 'lucide-react';
import AtlasAvatar from '@/components/atlas/atlas-avatar';

export default function ChatPage() {
  return (
    <div className="h-[calc(100vh-140px)] flex flex-col">
      {/* Dynamic Status Header */}
      <div className="flex items-center justify-between mb-6 px-4 py-3 bg-white/5 border border-white/5 rounded-2xl">
        <div className="flex items-center gap-4">
          <AtlasAvatar state="idle" size="md" />
          <div>
            <h2 className="text-lg font-black tracking-tight">Atlas <span className="text-blue-400">Core</span></h2>
            <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-slate-500">
              <Shield className="w-3 h-3 text-emerald-400" />
              Sync Level: 100% (High Fidelity)
            </div>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-6">
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Neural Latency</span>
            <span className="text-xs font-mono text-blue-400">0.14ms</span>
          </div>
          <div className="w-px h-8 bg-white/10"></div>
          <div className="flex flex-col items-end">
             <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Model Engine</span>
             <span className="text-xs font-mono text-purple-400">Gemini 3 Pro</span>
          </div>
        </div>
      </div>

      {/* Main Chat Core */}
      <div className="flex-1 min-h-0 glass-panel rounded-[2.5rem] border-white/5 overflow-hidden flex flex-col shadow-2xl relative bg-[#030712]/40">
        <ChatContainer />
      </div>

      <div className="mt-4 flex items-center justify-center gap-4 text-[10px] font-mono uppercase tracking-[0.4em] text-slate-600">
        <Cpu className="w-3 h-3" />
        Encrypted P2P Neural Tunnel Active
      </div>
    </div>
  );
}
