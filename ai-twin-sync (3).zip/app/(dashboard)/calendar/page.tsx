
import React from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function CalendarPage() {
  const hours = Array.from({ length: 12 }, (_, i) => i + 8); // 8 AM to 8 PM

  return (
    <div className="space-y-8 h-full flex flex-col">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-white mb-1">Time <span className="text-purple-500">Oracle</span></h1>
          <p className="text-slate-400">Strategic schedule management for Alex Johnson.</p>
        </div>
        <div className="flex gap-3">
          <div className="flex bg-white/5 border border-white/5 rounded-xl p-1">
             <button className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white">Day</button>
             <button className="px-4 py-2 text-xs font-bold bg-purple-600 text-white rounded-lg shadow-lg">Week</button>
             <button className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white">Month</button>
          </div>
          <button className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-sm font-bold flex items-center gap-2 transition-all">
            <Plus size={18} />
            Book Slot
          </button>
        </div>
      </div>

      <div className="flex-1 glass-panel rounded-[2.5rem] border-white/5 overflow-hidden flex flex-col">
        <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/5">
           <div className="flex items-center gap-4">
              <h3 className="text-xl font-bold">October 2024</h3>
              <div className="flex gap-1">
                <button className="p-2 hover:bg-white/5 rounded-lg text-slate-500 hover:text-white"><ChevronLeft size={18} /></button>
                <button className="p-2 hover:bg-white/5 rounded-lg text-slate-500 hover:text-white"><ChevronRight size={18} /></button>
              </div>
           </div>
           <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">Deep Work Optimized</span>
           </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          <div className="grid grid-cols-8 border-b border-white/5 bg-white/5">
             <div className="p-4 border-r border-white/5"></div>
             {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
               <div key={day} className="p-4 text-center border-r border-white/5">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">{day}</span>
               </div>
             ))}
          </div>

          <div className="relative">
             {hours.map(hour => (
               <div key={hour} className="grid grid-cols-8 h-20 border-b border-white/5">
                  <div className="p-4 text-right border-r border-white/5">
                     <span className="text-[10px] font-mono text-slate-600">{hour}:00</span>
                  </div>
                  {Array.from({ length: 7 }).map((_, i) => (
                    <div key={i} className="border-r border-white/5 relative">
                       {hour === 10 && i === 0 && (
                         <div className="absolute inset-2 bg-blue-600/20 border-l-4 border-blue-600 rounded-lg p-3 z-10">
                            <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">10:00 - 12:00</p>
                            <h4 className="text-xs font-bold text-white">Product Strategy</h4>
                         </div>
                       )}
                       {hour === 14 && i === 2 && (
                         <div className="absolute inset-2 bg-purple-600/20 border-l-4 border-purple-600 rounded-lg p-3 z-10">
                            <p className="text-[10px] font-black text-purple-400 uppercase tracking-widest mb-1">14:00 - 15:30</p>
                            <h4 className="text-xs font-bold text-white">Board Sync</h4>
                         </div>
                       )}
                    </div>
                  ))}
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
}
