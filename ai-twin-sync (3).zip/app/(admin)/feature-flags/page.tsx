import React from 'react';
import { Flag, Save, RefreshCw, AlertTriangle } from 'lucide-react';
import FeatureFlagRow from '@/components/admin/feature-flag-row';

export default function FeatureFlagsPage() {
  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-white mb-1">Feature <span className="text-rose-500">Flags</span></h1>
          <p className="text-slate-400">Control platform capabilities and early-access experimental modules.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-sm font-bold shadow-lg shadow-rose-600/20 flex items-center gap-2">
            <Save size={18} />
            Commit Changes
          </button>
        </div>
      </div>

      <div className="bg-orange-500/10 border border-orange-500/20 rounded-2xl p-6 flex items-start gap-4">
        <AlertTriangle className="text-orange-500 shrink-0 mt-1" size={20} />
        <div>
           <h4 className="font-bold text-orange-500 text-sm">Experimental Previews</h4>
           <p className="text-xs text-orange-400/80 leading-relaxed mt-1">
             Enabling "BETA" features may cause neural latency or unexpected autonomous results. Ensure executive monitoring is active for these instances.
           </p>
        </div>
      </div>

      <div className="glass-panel rounded-[2.5rem] border-white/5 overflow-hidden">
        <div className="grid grid-cols-1 divide-y divide-white/5">
          <div className="px-8 py-5 bg-white/5 grid grid-cols-12 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">
             <div className="col-span-6">Module Identity</div>
             <div className="col-span-2 text-center">Global Status</div>
             <div className="col-span-2 text-center">User Override</div>
             <div className="col-span-2 text-right">Integrity</div>
          </div>
          
          {[
            { id: 'vocal', name: 'Vocal Command Protocol', desc: 'Real-time voice processing and instruction parsing', status: 'ON' },
            { id: 'inbound', name: 'Inbound Call Screening', desc: 'Automatic answering and triage of incoming vocal links', status: 'BETA' },
            { id: 'outbound', name: 'Outbound Agent Liaison', desc: 'Atlas initiating calls to schedule or confirm logistics', status: 'OFF' },
            { id: 'travel', name: 'Autonomous Logistics', desc: 'Full booking capability for flights, hotels, and ground transport', status: 'BETA' },
            { id: 'finance', name: 'Financial Authority', desc: 'Expense approval and invoice processing up to thresholds', status: 'ON' },
            { id: 'social', name: 'Social Monitoring', desc: 'Real-time intelligence gathering from social matrices', status: 'OFF' }
          ].map((feature) => (
            <FeatureFlagRow key={feature.id} {...feature} />
          ))}
        </div>
      </div>
    </div>
  );
}