import React from 'react';
import { Settings2, Zap, Shield, FileText, Save, RotateCcw } from 'lucide-react';
import AISettingsForm from '@/components/admin/ai-settings-form';

export default function AISettingsPage() {
  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-white mb-1">AI <span className="text-rose-500">Neural Engine</span></h1>
          <p className="text-slate-400">Configure global intelligence parameters and ethical guardrails.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-5 py-2.5 glass border-white/5 hover:bg-white/5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 text-slate-400">
            <RotateCcw size={16} />
            Reset Cluster
          </button>
          <button className="px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-sm font-bold shadow-lg shadow-rose-600/20 flex items-center gap-2">
            <Save size={18} />
            Deploy Configuration
          </button>
        </div>
      </div>

      <AISettingsForm />
      
      <section className="space-y-6">
        <h2 className="text-xl font-bold flex items-center gap-3">
          <FileText className="text-rose-500" />
          Neural Template Matrix
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { id: 'commander', name: 'Commander Agent', desc: 'Core orchestration and decision logic' },
            { id: 'email', name: 'Email Synthesizer', desc: 'Context-aware drafting and summarizing' },
            { id: 'calendar', name: 'Calendar Oracle', desc: 'Strategic time management and booking' },
            { id: 'voice', name: 'Voice Biometrics', desc: 'Vocal synthesis and recognition profile' },
            { id: 'summary', name: 'Strategic Briefing', desc: 'Morning and evening platform digests' }
          ].map((prompt) => (
            <div key={prompt.id} className="glass-panel p-6 rounded-[2rem] border-white/5 hover:border-rose-500/20 transition-all group flex flex-col h-full">
              <div className="flex items-center justify-between mb-4">
                 <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-500">
                   <Zap size={20} />
                 </div>
                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-600">v4.2.0</span>
              </div>
              <h3 className="font-bold text-white mb-1">{prompt.name}</h3>
              <p className="text-xs text-slate-500 leading-relaxed mb-6 flex-1">{prompt.desc}</p>
              <button className="w-full py-3 rounded-xl border border-white/5 bg-white/5 text-[10px] font-black uppercase tracking-widest text-white hover:bg-rose-600 hover:border-rose-600 transition-all">
                Modify Code
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}