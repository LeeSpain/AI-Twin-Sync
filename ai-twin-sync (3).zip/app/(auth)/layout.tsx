
import React from 'react';
import { Link } from '@/lib/navigation';
import { Bot } from 'lucide-react';

// AI Twin Sync - Auth Layout
export default function AuthLayout({
  children,
}: {
  children?: React.ReactNode;
}) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#030712] relative overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-600/5 blur-[150px] rounded-full -z-10 animate-pulse"></div>
      <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-purple-600/5 blur-[150px] rounded-full -z-10 animate-pulse"></div>

      <div className="w-full max-w-md space-y-8 relative z-10">
        <div className="flex flex-col items-center text-center space-y-4">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-xl shadow-blue-600/20 group-hover:rotate-6 transition-transform">
              <Bot className="w-7 h-7 text-white" />
            </div>
            <span className="text-3xl font-black tracking-tighter">
              AI Twin <span className="gradient-text">Sync</span>
            </span>
          </Link>
          <div className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-[0.2em] text-blue-400">
            Secure Neural Link v4.0
          </div>
        </div>

        <div className="glass-panel p-8 md:p-10 rounded-[2.5rem] shadow-2xl border-white/5">
          {children}
        </div>

        <div className="text-center text-xs text-muted-foreground uppercase tracking-widest font-mono">
          Engineered for high-performance leadership
        </div>
      </div>
    </div>
  );
}
