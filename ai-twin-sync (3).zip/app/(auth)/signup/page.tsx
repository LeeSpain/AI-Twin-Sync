
import React from 'react';
import { Link } from '@/lib/navigation';
import SignupForm from '@/components/auth/signup-form';
import { ArrowLeft } from 'lucide-react';

export default function SignupPage() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight text-white">Baseline Profile</h1>
        <p className="text-muted-foreground">Register your identity to begin neural synchronization.</p>
      </div>

      <SignupForm />

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-white/10"></span>
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-[#030712] px-2 text-muted-foreground">Already linked?</span>
        </div>
      </div>

      <Link 
        href="/login" 
        className="block w-full text-center py-4 rounded-2xl border border-white/10 text-white font-bold hover:bg-white/5 transition-all"
      >
        Access Existing Instance
      </Link>

      <Link href="/" className="flex items-center justify-center gap-2 text-xs text-muted-foreground hover:text-white transition-colors">
        <ArrowLeft className="w-3 h-3" />
        Return to Surface
      </Link>
    </div>
  );
}
