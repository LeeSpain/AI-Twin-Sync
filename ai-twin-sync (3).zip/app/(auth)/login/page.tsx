
import React from 'react';
import { Link } from '@/lib/navigation';
import LoginForm from '@/components/auth/login-form';
import { ArrowLeft } from 'lucide-react';

export default function LoginPage() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight text-white">Engage Link</h1>
        <p className="text-muted-foreground">Re-establish connection with your Atlas instance.</p>
      </div>

      <LoginForm />

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t border-white/10"></span>
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-[#030712] px-2 text-muted-foreground">New to Atlas?</span>
        </div>
      </div>

      <Link 
        href="/signup" 
        className="block w-full text-center py-4 rounded-2xl border border-white/10 text-white font-bold hover:bg-white/5 transition-all"
      >
        Initialize New Profile
      </Link>

      <Link href="/" className="flex items-center justify-center gap-2 text-xs text-muted-foreground hover:text-white transition-colors">
        <ArrowLeft className="w-3 h-3" />
        Return to Surface
      </Link>
    </div>
  );
}
