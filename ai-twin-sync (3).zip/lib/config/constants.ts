
export const APP_NAME = 'AI Twin Sync';
export const AI_NAME = 'Atlas';
export const DEFAULT_MODEL = 'gemini-3-pro-preview';
export const FAST_MODEL = 'gemini-3-flash-preview';

export const ROUTES = {
  HOME: '/',
  DASHBOARD: '/dashboard',
  CHAT: '/chat',
  ONBOARDING: '/onboarding',
  ADMIN: '/admin',
  LOGIN: '/login',
  SIGNUP: '/signup'
};

export const SYNC_THRESHOLDS = {
  HIGH_AGENCY: 50,
  STRICT_OVERSIGHT: 99,
  DEFAULT: 85
};

export const API_ENDPOINTS = {
  ATLAS_CHAT: '/api/atlas/chat',
  ATLAS_PROCESS: '/api/atlas/process',
  DASHBOARD_STATS: '/api/dashboard/stats',
  MEMORY: '/api/atlas/memory'
};
