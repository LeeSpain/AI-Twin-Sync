import { NextRequest, NextResponse } from 'next/server';
import { logger } from './logger';

export const logRequest = async (req: NextRequest, handler: () => Promise<NextResponse>) => {
  const start = Date.now();
  const { method, nextUrl: { pathname } } = req;

  try {
    const response = await handler();
    const duration = Date.now() - start;
    logger.info(`${method} ${pathname} ${response.status} - ${duration}ms`);
    return response;
  } catch (err: any) {
    const duration = Date.now() - start;
    logger.error(`${method} ${pathname} FAILED - ${duration}ms`, err);
    throw err;
  }
};
