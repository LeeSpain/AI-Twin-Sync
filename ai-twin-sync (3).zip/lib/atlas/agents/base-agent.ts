
import { AgentContext, AgentResponse } from "@/types/agents";
import { GoogleGenAI } from "@google/genai";

export abstract class BaseAgent {
  protected ai: GoogleGenAI;
  
  constructor(
    protected userId: string,
    protected context: AgentContext
  ) {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  abstract execute(message: string, intent: any): Promise<AgentResponse>;

  protected async logAction(description: string, metadata?: any) {
    console.log(`[Agent Action] ${description}`, metadata);
    // In production, persist to supabase
  }

  protected getModel(type: 'fast' | 'pro' = 'pro') {
    return type === 'pro' ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
  }
}
