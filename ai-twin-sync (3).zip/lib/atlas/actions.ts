import { createClient } from '@/lib/supabase/server';
import { Database } from '@/types/database';

/**
 * Creates a new AI action draft for user approval.
 */
export async function createAtlasAction(userId: string, type: string, description: string, data: any) {
  const supabase = createClient();
  
  const { data: action, error } = await supabase
    .from('ai_actions')
    .insert({
      user_id: userId,
      action_type: type,
      description,
      status: 'pending',
      input_data: data,
      requires_approval: true,
      confidence_score: 0.95
    })
    .select()
    .single();

  if (error) throw error;
  return action;
}

/**
 * Finalizes and executes an approved action.
 */
export async function executeApprovedAction(actionId: string) {
  const supabase = createClient();
  
  // 1. Fetch action
  const { data: action, error: fetchError } = await supabase
    .from('ai_actions')
    .select('*')
    .eq('id', actionId)
    .single();

  if (fetchError || !action) throw new Error("Action not found");

  // 2. Logic for specific action types (Mocks)
  console.log(`Executing Atlas Action: ${action.action_type}`, action.input_data);
  
  // 3. Update status
  const { error: updateError } = await supabase
    .from('ai_actions')
    .update({ 
      status: 'executed',
      executed_at: new Date().toISOString()
    })
    .eq('id', actionId);

  if (updateError) throw updateError;
  return { success: true };
}