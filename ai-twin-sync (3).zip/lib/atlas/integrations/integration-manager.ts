
import { GmailConnector } from "./gmail-connector";

export class IntegrationManager {
  static getGmail(userId: string) {
    return new GmailConnector(userId);
  }

  static async syncAll(userId: string) {
    console.log(`Syncing all nodes for ${userId}`);
  }
}
