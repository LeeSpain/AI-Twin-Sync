
import { GoogleGenAI, Type } from "@google/genai";

export class TextAnalyzer {
  static async extractActionItems(text: string) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Extract tasks from: "${text}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              task: { type: Type.STRING },
              priority: { type: Type.STRING, enum: ['high', 'medium', 'low'] },
              deadline: { type: Type.STRING }
            }
          }
        }
      }
    });
    return JSON.parse(response.text);
  }
}
