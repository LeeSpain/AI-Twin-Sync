
/**
 * Triggers a browser download for a specific file content.
 * This is the most reliable way to bypass iframe connection errors 
 * when the user needs to move data from the sandbox to a local environment.
 */
export function downloadFile(filename: string, content: string, mimeType: string = 'application/json') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  
  // Clean up
  setTimeout(() => {
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, 100);
}
