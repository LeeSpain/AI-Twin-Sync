
export interface FAQItem {
  question: string;
  answer: string;
}

export const FAQS: FAQItem[] = [
  {
    question: 'How does Atlas learn my communication style?',
    answer: 'During the 4-week "Shadow Mode", Atlas analyzes your outbound emails and Slack messages to map your linguistic patterns, tone, and decision logic without sending anything itself.'
  },
  {
    question: 'Is my data secure?',
    answer: 'Absolutely. AI Twin Sync utilizes end-to-end encryption. Your neural data is stored on a private instance that only you (and your admin) can access.'
  },
  {
    question: 'Can Atlas actually take phone calls?',
    answer: 'Yes. Using Gemini 2.5 Flash Native Audio, Atlas can answer calls, screen participants, and handle routine scheduling or information gathering using your biometric voice profile.'
  },
  {
    question: 'What happens if Atlas makes a mistake?',
    answer: 'You define the "Autonomy Threshold". High-stakes actions always require your 20-second "Undo Window" or explicit approval before execution.'
  },
  {
    question: 'Can I manage multiple companies?',
    answer: 'Yes, Atlas is designed for multi-org leaders. It maintains separate context windows for each organization to prevent data bleed.'
  }
];
