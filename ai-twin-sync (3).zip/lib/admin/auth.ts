import { createClient } from '@/lib/supabase/server';

/**
 * Validates if the current session belongs to a Super Admin.
 */
export async function checkAdminAccess() {
  const supabase = createClient();
  const { data: { session } } = await supabase.auth.getSession();
  
  if (!session) return false;
  
  const role = session.user.user_metadata?.role;
  return role === 'admin';
}

/**
 * High-level guard for Admin Route Handlers.
 */
export async function requireAdmin() {
  const isAdmin = await checkAdminAccess();
  if (!isAdmin) {
    throw new Error('UNAUTHORIZED_ACCESS_ATTEMPT');
  }
  return true;
}