
import { GoogleGenAI, GenerateContentResponse, GenerateContentParameters } from "@google/genai";

/**
 * AI Twin Sync - Gemini Client Utility
 * Standardized for Gemini 3 Pro operations.
 */

const MODEL_PRO = 'gemini-3-pro-preview';
const MODEL_FLASH = 'gemini-3-flash-preview';

/**
 * Initialize and execute a chat completion.
 */
export const generateChatCompletion = async (params: GenerateContentParameters, speed: 'pro' | 'flash' = 'pro'): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: speed === 'pro' ? MODEL_PRO : MODEL_FLASH,
      ...params,
      config: {
        ...params.config,
        thinkingConfig: speed === 'pro' ? { thinkingBudget: 32768 } : undefined
      }
    });
    return response.text || "";
  } catch (error) {
    console.error("Gemini Completion Error:", error);
    throw error;
  }
};

/**
 * Initialize and execute a streaming chat completion.
 */
export const generateChatStream = async (params: GenerateContentParameters, speed: 'pro' | 'flash' = 'pro') => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    return await ai.models.generateContentStream({
      model: speed === 'pro' ? MODEL_PRO : MODEL_FLASH,
      ...params,
      config: {
        ...params.config,
        thinkingConfig: speed === 'pro' ? { thinkingBudget: 32768 } : undefined
      }
    });
  } catch (error) {
    console.error("Gemini Streaming Error:", error);
    throw error;
  }
};
