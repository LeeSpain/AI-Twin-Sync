
import { createBrowserClient } from '@supabase/ssr';
import type { Database } from '@/types/database';

/**
 * Browser-side Supabase Client
 * 
 * Safely initializes the client. Handles missing or placeholder 
 * environment variables by returning a mock client.
 */
export const createClient = () => {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  const isPlaceholder = url?.includes('your-project-id.supabase.co') || !url?.startsWith('http');

  if (!url || !key || isPlaceholder) {
    console.warn("Supabase credentials missing or invalid. Operating in Neural Simulation Mode.");
    
    return {
      auth: {
        getSession: async () => ({ data: { session: null }, error: null }),
        getUser: async () => ({ data: { user: null }, error: null }),
        onAuthStateChange: () => ({ 
          data: { subscription: { unsubscribe: () => {} } } 
        }),
        signInWithPassword: async () => ({ 
          data: { user: null, session: null }, 
          error: new Error('Supabase not configured') 
        }),
        signUp: async () => ({ 
          data: { user: null, session: null }, 
          error: new Error('Supabase not configured') 
        }),
        signOut: async () => ({ error: null }),
        signInWithOAuth: async () => ({ data: null, error: new Error('Supabase not configured') }),
      },
      from: () => ({
        select: () => ({
          eq: () => ({
            single: async () => ({ data: null, error: null }),
            order: () => ({
              limit: async () => ({ data: [], error: null }),
            }),
          }),
          order: () => ({
            limit: async () => ({ data: [], error: null }),
          }),
        }),
        insert: () => ({
          select: () => ({
            single: async () => ({ data: null, error: null }),
          }),
        }),
        upsert: () => ({
          select: () => ({
            single: async () => ({ data: null, error: null }),
          }),
        }),
        update: () => ({
          eq: () => ({
            select: () => ({
              single: async () => ({ data: null, error: null }),
            }),
          }),
        }),
      }),
    } as any;
  }

  return createBrowserClient<Database>(url, key);
};
