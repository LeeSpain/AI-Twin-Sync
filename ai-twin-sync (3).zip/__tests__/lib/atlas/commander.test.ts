import { describe, it, expect, vi } from 'vitest';
import { Commander } from '@/lib/atlas/commander';
import { IntentType } from '@/types/agents';

describe('Commander Agent', () => {
  it('correctly initializes', () => {
    const commander = new Commander();
    expect(commander).toBeDefined();
  });

  // Additional logic tests would mock the Gemini response
  // and verify routing to EmailAgent/CalendarAgent
});
