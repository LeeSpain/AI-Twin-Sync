import { describe, it, expect, vi } from 'vitest';
import { POST } from '@/app/api/atlas/chat/route';
import { NextRequest } from 'next/server';

describe('Atlas Chat API', () => {
  it('should reject unauthorized requests', async () => {
    const req = new NextRequest('http://localhost:3000/api/atlas/chat', {
      method: 'POST',
      body: JSON.stringify({ message: 'test', history: [] }),
    });
    
    // Response should be handled by middleware/logic
    // This is a placeholder for real integration testing
  });
});
