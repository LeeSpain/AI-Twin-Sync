import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatsCardProps {
  label: string;
  value: string;
  trend: string;
  icon: React.ReactNode;
  color: 'blue' | 'purple' | 'emerald' | 'amber';
}

export default function StatsCard({ label, value, trend, icon, color }: StatsCardProps) {
  const isPositive = trend.startsWith('+') || trend.includes('%');
  
  const colorMap = {
    blue: "text-blue-400 bg-blue-400/10",
    purple: "text-purple-400 bg-purple-400/10",
    emerald: "text-emerald-400 bg-emerald-400/10",
    amber: "text-amber-400 bg-amber-400/10",
  };

  return (
    <div className="glass-panel p-6 rounded-3xl border-white/5 hover:border-white/10 transition-all group relative overflow-hidden">
      <div className="absolute -top-10 -right-10 w-32 h-32 bg-gradient-to-br from-blue-600/10 to-transparent blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
      
      <div className="flex items-center justify-between mb-4">
        <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center", colorMap[color])}>
          {icon}
        </div>
        <div className={cn(
          "flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
          isPositive ? "bg-emerald-400/10 text-emerald-400" : "bg-red-400/10 text-red-400"
        )}>
          {isPositive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
          {trend}
        </div>
      </div>

      <div className="space-y-1">
        <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">{label}</p>
        <h4 className="text-3xl font-black text-white tracking-tighter">{value}</h4>
      </div>
    </div>
  );
}