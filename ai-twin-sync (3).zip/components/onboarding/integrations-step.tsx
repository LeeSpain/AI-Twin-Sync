
import React from 'react';
import AtlasQuestion from './atlas-question';
import IntegrationCard from './integration-card';
import { Mail, Calendar, MessageCircle, Database, Github, LayoutGrid } from 'lucide-react';

export default function IntegrationsStep() {
  const integrations = [
    { id: 'gmail', name: 'Gmail', icon: <Mail />, provider: 'google' },
    { id: 'google_calendar', name: 'Calendar', icon: <Calendar />, provider: 'google' },
    { id: 'github', name: 'GitHub', icon: <Github />, provider: 'github' },
    { id: 'slack', name: 'Slack', icon: <MessageCircle />, provider: 'slack' },
    { id: 'outlook', name: 'Outlook', icon: <Mail />, provider: 'microsoft' },
    { id: 'custom', name: 'Custom API', icon: <Database />, provider: 'custom' },
  ];

  return (
    <div className="space-y-12">
      <AtlasQuestion 
        question="Connect your operational tools. I'll need these to manage your communications, schedule, and code repositories." 
        hint="All authentication happens through secure OAuth tunnels. I never see your passwords."
      />

      <div className="pl-24 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-1000">
        {integrations.map((item) => (
          <IntegrationCard key={item.id} {...item} />
        ))}
      </div>
    </div>
  );
}
