
import React from 'react';
import AtlasQuestion from './atlas-question';
import { Bot, Zap, ShieldCheck, ArrowRight, Download } from 'lucide-react';
import { Link } from '@/lib/navigation';

export default function CompleteStep() {
  return (
    <div className="space-y-12 text-center">
      <div className="relative w-40 h-40 mx-auto mb-8">
        <div className="absolute inset-0 bg-blue-600/20 blur-[60px] rounded-full animate-pulse"></div>
        <div className="relative w-full h-full bg-gradient-to-br from-blue-600 to-purple-600 rounded-[3rem] flex items-center justify-center shadow-2xl shadow-blue-600/40 rotate-6 group hover:rotate-0 transition-transform duration-700">
          <Bot size={80} className="text-white" />
        </div>
        <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-xl border-4 border-[#030712] animate-bounce">
          <ShieldCheck size={24} className="text-white" />
        </div>
      </div>

      <div className="space-y-4 max-w-2xl mx-auto">
        <h2 className="text-5xl font-black tracking-tighter text-white leading-none">
          Synchronization <span className="gradient-text">Absolute</span>
        </h2>
        <p className="text-xl text-slate-400 font-light leading-relaxed">
          The link is established. I have mapped your organizational footprint and operational style. 
          Atlas Core is now active.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto pt-8">
        {[
          { label: 'Latency', value: '0.14ms', icon: <Zap size={14} /> },
          { label: 'Fidelity', value: '99.9%', icon: <ShieldCheck size={14} /> },
          { label: 'Uptime', value: '100%', icon: <Bot size={14} /> }
        ].map(stat => (
          <div key={stat.label} className="glass-panel p-6 rounded-[2rem] border-white/5 text-center space-y-2">
            <div className="text-blue-400 flex justify-center">{stat.icon}</div>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-600">{stat.label}</p>
            <p className="text-2xl font-black text-white">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-12">
        <Link
          href="/dashboard"
          className="px-12 py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-[2rem] font-black uppercase tracking-[0.2em] shadow-2xl shadow-blue-600/30 transition-all flex items-center gap-3 active:scale-95 text-sm"
        >
          Engage Dashboard
          <ArrowRight size={20} />
        </Link>
        <button className="px-8 py-5 glass border border-white/10 text-white rounded-[2rem] font-bold text-sm transition-all flex items-center gap-2 hover:bg-white/5">
          <Download size={18} />
          Mobile Link
        </button>
      </div>
    </div>
  );
}
