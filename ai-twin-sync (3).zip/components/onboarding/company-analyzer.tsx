import React, { useState } from 'react';
import { Search, Loader2, Check, Globe } from 'lucide-react';

interface CompanyAnalyzerProps {
  onAdd: (company: any) => void;
}

export default function CompanyAnalyzer({ onAdd }: CompanyAnalyzerProps) {
  const [url, setUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!url.trim()) return;
    setIsAnalyzing(true);
    setError(null);

    try {
      const response = await fetch('/api/onboarding/analyze-website', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });

      if (!response.ok) throw new Error('Failed to analyze website');
      
      const data = await response.json();
      onAdd({ ...data, url });
      setUrl('');
    } catch (err: any) {
      setError('Neural scan failed. Please check the URL and retry.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="relative group max-w-2xl">
        <div className="absolute inset-y-0 left-6 flex items-center text-slate-500">
          <Globe size={18} />
        </div>
        <input
          type="url"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://yourcompany.com"
          className="w-full bg-white/5 border border-white/10 rounded-2xl py-5 pl-16 pr-40 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all placeholder:text-slate-700"
        />
        <button
          onClick={handleAnalyze}
          disabled={isAnalyzing || !url}
          className="absolute right-3 top-3 px-6 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-30 text-white rounded-xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg shadow-blue-600/20 flex items-center gap-2"
        >
          {isAnalyzing ? (
            <Loader2 size={14} className="animate-spin" />
          ) : (
            <Search size={14} />
          )}
          {isAnalyzing ? 'Scanning...' : 'Analyze'}
        </button>
      </div>
      {error && <p className="text-xs text-red-400 font-bold ml-6 uppercase tracking-widest">{error}</p>}
      {isAnalyzing && (
        <div className="flex items-center gap-3 ml-6 text-[9px] font-mono text-blue-400 uppercase tracking-widest animate-pulse">
          <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
          Atlas is parsing linguistic patterns and industry context...
        </div>
      )}
    </div>
  );
}