
import React from 'react';
import { AITwin } from '../types';

interface TwinCardProps {
  twin: AITwin;
  onSelect: (twin: AITwin) => void;
}

const TwinCard: React.FC<TwinCardProps> = ({ twin, onSelect }) => {
  return (
    <div 
      className="glass group hover:border-blue-500/50 transition-all cursor-pointer rounded-2xl p-6 relative overflow-hidden flex flex-col gap-4"
      onClick={() => onSelect(twin)}
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 blur-3xl -mr-10 -mt-10 group-hover:bg-blue-600/20 transition-colors"></div>
      
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-xl overflow-hidden border border-white/10 ring-2 ring-blue-500/20">
          <img src={twin.avatar} alt={twin.name} className="w-full h-full object-cover" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">{twin.name}</h3>
          <p className="text-sm text-gray-400">Sync Level: {twin.syncLevel}%</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {twin.traits.slice(0, 3).map((trait, idx) => (
          <span key={idx} className="text-[10px] uppercase font-bold tracking-wider px-2 py-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
            {trait}
          </span>
        ))}
      </div>

      <p className="text-sm text-gray-300 line-clamp-2 leading-relaxed italic">
        "{twin.personality.split('.')[0]}."
      </p>

      <div className="mt-auto flex items-center justify-between pt-4 border-t border-white/5">
        <span className="text-[10px] text-gray-500 uppercase">Last active: {twin.lastActive}</span>
        <button className="text-xs font-bold text-blue-400 group-hover:underline">Engage →</button>
      </div>
    </div>
  );
};

export default TwinCard;
