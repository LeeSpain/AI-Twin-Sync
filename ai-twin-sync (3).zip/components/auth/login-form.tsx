import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { createClient } from '@/lib/supabase/client';
import { Loader2, AlertCircle, Chrome } from 'lucide-react';

const loginSchema = z.object({
  email: z.string().email('Enter a valid identity email'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function LoginForm() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const supabase = createClient();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginFormValues) => {
    setIsLoading(true);
    setError(null);

    try {
      const { error } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      });

      if (error) throw error;
      
      // Redirect handled by Next.js middleware
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      });
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {error && (
          <div className="p-3 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            {error}
          </div>
        )}

        <div className="space-y-1">
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest ml-1">Identity Email</label>
          <input
            {...register('email')}
            type="email"
            placeholder="name@company.com"
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-white placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
          />
          {errors.email && <p className="text-[10px] text-destructive ml-1">{errors.email.message}</p>}
        </div>

        <div className="space-y-1">
          <div className="flex justify-between items-center ml-1">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Access Key</label>
            <button type="button" className="text-[10px] text-blue-400 hover:text-blue-300 transition-colors uppercase font-bold tracking-tighter">Lost Key?</button>
          </div>
          <input
            {...register('password')}
            type="password"
            placeholder="••••••••"
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-white placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
          />
          {errors.password && <p className="text-[10px] text-destructive ml-1">{errors.password.message}</p>}
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-2xl font-black shadow-xl shadow-blue-600/20 transition-all flex items-center justify-center gap-2 mt-2"
        >
          {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Synchronize'}
        </button>
      </form>

      <button
        onClick={handleGoogleLogin}
        className="w-full py-4 bg-white text-black hover:bg-gray-100 rounded-2xl font-bold transition-all flex items-center justify-center gap-3"
      >
        <Chrome className="w-5 h-5" />
        Continue with Google
      </button>
    </div>
  );
}