
import React from 'react';
import { LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  details: string[];
  // Fix: Allow extra props from spread in MarketingPage to satisfy strict TS check
  id?: string;
  key?: React.Key;
}

export default function FeatureCard({ icon: Icon, title, description, details }: FeatureCardProps) {
  return (
    <motion.div 
      whileHover={{ y: -8 }}
      className="glass p-8 rounded-[2.5rem] border-white/5 hover:border-blue-500/30 transition-all group flex flex-col h-full"
    >
      <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center text-blue-500 mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all duration-500">
        <Icon size={28} />
      </div>
      
      <h3 className="text-2xl font-bold text-white mb-4 tracking-tight">{title}</h3>
      <p className="text-slate-400 leading-relaxed mb-6 flex-1">
        {description}
      </p>

      <ul className="space-y-3 pt-6 border-t border-white/5">
        {details.map((detail, i) => (
          <li key={i} className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-widest">
            <div className="w-1 h-1 rounded-full bg-blue-500"></div>
            {detail}
          </li>
        ))}
      </ul>
    </motion.div>
  );
}
