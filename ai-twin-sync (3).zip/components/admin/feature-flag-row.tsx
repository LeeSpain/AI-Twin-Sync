
import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { Zap, ShieldCheck, AlertCircle } from 'lucide-react';

interface FeatureFlagRowProps {
  name: string;
  desc: string;
  status: string;
  // Fix: Allow extra props from spread in FeatureFlagsPage to satisfy strict TS check
  id?: string;
  key?: React.Key;
}

export default function FeatureFlagRow({ name, desc, status: initialStatus }: FeatureFlagRowProps) {
  const [status, setStatus] = useState(initialStatus);
  const [allowOverride, setAllowOverride] = useState(true);

  return (
    <div className="px-8 py-8 grid grid-cols-12 items-center hover:bg-white/[0.02] transition-colors group">
      <div className="col-span-6 space-y-1">
        <h4 className="font-bold text-white group-hover:text-rose-500 transition-colors">{name}</h4>
        <p className="text-xs text-slate-500 leading-relaxed pr-8">{desc}</p>
      </div>

      <div className="col-span-2 flex justify-center">
        <div className="flex bg-slate-900 p-1 rounded-xl border border-white/5 gap-1">
          {['ON', 'BETA', 'OFF'].map((s) => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={cn(
                "px-3 py-1.5 rounded-lg text-[9px] font-black tracking-widest transition-all",
                status === s 
                  ? s === 'ON' ? "bg-emerald-500 text-white" : s === 'BETA' ? "bg-orange-500 text-white" : "bg-rose-500 text-white"
                  : "text-slate-500 hover:text-white"
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="col-span-2 flex justify-center">
        <button 
          onClick={() => setAllowOverride(!allowOverride)}
          className={cn(
            "w-12 h-6 rounded-full p-1 transition-colors relative",
            allowOverride ? "bg-rose-500" : "bg-slate-800"
          )}
        >
          <div className={cn(
            "w-4 h-4 rounded-full bg-white transition-transform shadow-sm",
            allowOverride ? "translate-x-6" : "translate-x-0"
          )}></div>
        </button>
      </div>

      <div className="col-span-2 flex justify-end gap-3 text-slate-600">
         <div className="flex items-center gap-1.5">
            {status === 'ON' ? <ShieldCheck size={14} className="text-emerald-500/50" /> : <AlertCircle size={14} className="text-rose-500/50" />}
            <span className="text-[10px] font-mono">STABLE</span>
         </div>
      </div>
    </div>
  );
}
