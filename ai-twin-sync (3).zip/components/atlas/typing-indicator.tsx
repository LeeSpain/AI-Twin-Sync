import React from 'react';
import { Terminal } from 'lucide-react';

export default function TypingIndicator() {
  return (
    <div className="flex flex-col gap-2 max-w-[80%] self-start animate-in fade-in duration-300">
      <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-blue-400">
        <Terminal size={10} />
        Atlas is thinking
      </div>
      
      <div className="glass-panel border-white/10 p-5 rounded-[2rem] rounded-tl-none shadow-sm flex items-center gap-3">
        <div className="flex gap-1.5">
          <div className="w-1.5 h-1.5 bg-blue-500/50 rounded-full animate-[bounce_1s_infinite]"></div>
          <div className="w-1.5 h-1.5 bg-blue-500/50 rounded-full animate-[bounce_1s_infinite_200ms]"></div>
          <div className="w-1.5 h-1.5 bg-blue-500/50 rounded-full animate-[bounce_1s_infinite_400ms]"></div>
        </div>
        <span className="text-xs font-mono text-slate-500 uppercase tracking-tighter">Processing Neural Baseline...</span>
      </div>
    </div>
  );
}