
import React from 'react';
import { cn } from '@/lib/utils';

interface AtlasStatusProps {
  status: 'ready' | 'thinking' | 'offline' | 'syncing';
}

export default function AtlasStatus({ status }: AtlasStatusProps) {
  const config = {
    ready: { color: 'bg-emerald-500', text: 'Protocol Ready' },
    thinking: { color: 'bg-blue-500 animate-pulse', text: 'Processing Neural Baseline' },
    offline: { color: 'bg-rose-500', text: 'Link Severed' },
    syncing: { color: 'bg-amber-500 animate-pulse', text: 'Synchronizing Nodes' }
  };

  const current = config[status];

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
      <div className={cn("w-1.5 h-1.5 rounded-full", current.color)} />
      <span className="text-[9px] font-black uppercase tracking-widest text-slate-500">
        {current.text}
      </span>
    </div>
  );
}
