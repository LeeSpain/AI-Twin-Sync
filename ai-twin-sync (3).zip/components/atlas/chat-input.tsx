import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Command } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ChatInputProps {
  onSend: (text: string) => void;
  disabled?: boolean;
}

export default function ChatInput({ onSend, disabled }: ChatInputProps) {
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  }, [input]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || disabled) return;
    onSend(input);
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative group">
      <div className="absolute -inset-2 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-[3rem] blur-xl opacity-0 group-focus-within:opacity-100 transition-all duration-700 -z-10"></div>
      
      <div className="relative glass-panel rounded-[2rem] border-white/10 focus-within:border-blue-500/30 transition-all overflow-hidden flex flex-col bg-[#030712]/80 shadow-2xl">
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Issue a direct instruction or ask a question..."
          rows={1}
          disabled={disabled}
          className="w-full bg-transparent px-8 py-6 pr-32 text-slate-100 placeholder:text-slate-600 focus:outline-none resize-none max-h-40 min-h-[72px] text-lg scrollbar-none transition-all"
        />

        <div className="absolute right-4 bottom-4 flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsRecording(!isRecording)}
            className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center transition-all active:scale-90",
              isRecording 
                ? "bg-red-500 text-white animate-pulse" 
                : "bg-white/5 text-slate-400 hover:text-white hover:bg-white/10"
            )}
          >
            {isRecording ? <MicOff size={22} /> : <Mic size={22} />}
          </button>

          <button
            type="submit"
            disabled={!input.trim() || disabled}
            className="w-12 h-12 bg-blue-600 hover:bg-blue-500 disabled:opacity-30 disabled:grayscale text-white rounded-2xl flex items-center justify-center transition-all shadow-lg shadow-blue-600/20 active:scale-90"
          >
            <Send size={22} />
          </button>
        </div>

        <div className="absolute left-8 bottom-2 flex items-center gap-4 text-[9px] font-mono uppercase tracking-[0.2em] text-slate-600 pointer-events-none">
          <div className="flex items-center gap-1.5">
            <Command size={10} />
            <span>Enter to Send</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-1 h-1 rounded-full bg-slate-700"></span>
            <span>Shift + Enter for New Line</span>
          </div>
        </div>
      </div>
    </form>
  );
}